### Environmental and Ecological Statistics with R ###
### Copyright Song S. Qian
### R scripts
###
###

#base <- "c:/users/song/Dropbox/teaching/book"
## for Mac
#base <- "/users/song/dropbox/teaching/book"
## for pubuntu -- directory name case sensitive
base <- "/home/pubuntu/song/Dropbox/Teaching/book"
dataDIR <- paste(base, "data", sep="/")
plotDIR <- paste(base, "psfigs", sep="/")
setwd(base)
setWindowTitle(paste("-",getwd()))

require(arm)
require(lattice)
# source("C:/users/song/dropbox/util.R")
## for Mac
#source("/users/song/dropbox/util.R")
## for pubuntu
source("/home/pubuntu/song/Dropbox/util.R")
### Data sets ###
##### Everglades reference sites
wca2tp <- read.csv(paste(dataDIR, "WCA2TP.csv", sep="/"), header=T)
wca2tp$RESULT <- 1000*wca2tp$RESULT
wca2tp$TP <- wca2tp$RESULT
TP.reference <- wca2tp[wca2tp$Type=="R",]
TP.reference$SITE <- as.vector( TP.reference$SITE)
TP.reference$Month <- ordered(months(as.Date(TP.reference$Date, "%m/%d/%y"), T),
  levels=c("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"))

##### North American Database
nadb <- read.csv(paste(dataDIR, "nadb.csv", sep="/"), header=T)

##### Lake trout ####
laketrout <- read.csv(paste(dataDIR,"laketrout2.csv", sep="/"), header=T)
laketrout$size<- "small"
laketrout$size[laketrout$length>60/2.54] <- "large"

laketrout$large<- 0
laketrout$large[laketrout$length>60/2.54] <- 1
## dividing by 2.54 converts 60 cm to inches
## single predictor
laketrout$length <- laketrout$length*2.54
laketrout$len.c <- laketrout$length-mean(laketrout$length, na.rm=T)
laketrout <- laketrout[laketrout$pcb>exp(-2)&laketrout$length>0,]

##### PM2.5 data #####
pmdata<-read.table(paste (dataDIR, "PM-RAW-DATA.txt", sep="/"),header=TRUE)

pmdata$rain<-pmdata$Precip > 0
pmdata$sin.date<-sin(2*pi*pmdata$date/365)
pmdata$log.wind<-log(pmdata$AvgWind)
pmdata$z.log.wind<-as.vector(scale(pmdata$log.wind))
pmdata$z.temp<-as.vector(scale(pmdata$AvgTemp))
pmdata$log.value<-log(pmdata$value)
pmdata$group1<-rep(c(1,2),1096/2)
pmdata$group2<-c(rep(1:3,365),1)
pmdata$Dates <-  as.Date("2003-01-01") + pmdata$date-1
pmdata$Weekday <- weekdays(pmdata$Dates, abbreviate=T)
pmdata$Month <- ordered(months(pmdata$Dates, T), levels=month.abb)

## Cover

postscript(file=paste(plotDIR,"cover.eps", sep="/"),
           height=3.75, width=4.75, horizontal=F)
trellis.par.temp <- trellis.par.get()
trellis.par.temp$add.text$cex=0.5 ## change strip text font size
trellis.par.temp$par.xlab.text$cex=0.75 ## xlab font size
trellis.par.temp$par.ylab.text$cex=0.75

obj1 <- xyplot(log.value~AvgTemp, panel=function(x,y,...){
  panel.grid()
  panel.xyplot(x,y, col=grey(0.65), cex=0.25, ...)
  panel.loess(x,y,span=1, degree=1,col=1,...)
},    scales=list(x=list(cex=0.75, tck=0.2), y=list(cex=0.75, tck=0.2)),
               par.settings=trellis.par.temp,
       data=pmdata, xlab="", ylab="Log PM2.5")

obj2 <- xyplot(log.value~AvgTemp|Month, panel=function(x,y,...){
  panel.grid()
  panel.xyplot(x,y, col=grey(0.65), cex=0.25, ...)
  panel.loess(x,y,span=1, degree=1,col=1,...)
  }, layout=c(12, 1),
       scales=list(y=list(tck=0.2),
         x=list(relation="free", cex=0.3,tck=0.2,
           alternating=c(1,2))),
       ## x-axis relation and font size
  par.settings=trellis.par.temp,
  data=pmdata, xlab="Average Daily Temperature (F)", ylab="Log PM2.5")

print(obj1, position=c(1/4, 0.3, 3/4, 1), more=T)
print(obj2, position=c(0, 0, 1,0.45), more=F)

dev.off()

#### Willamette River Data

willamette.data <- read.csv(paste(dataDIR, "willamette.csv", sep="/"), header=T)

willamette.data$Diuron <- "Below MDL"
willamette.data$Diuron[willamette.data$P49300>=7.08] <- "High"
willamette.data$Diuron[willamette.data$P49300<7.08 & willamette.data$P49300>=0.83] <- "Medium"
willamette.data$Diuron[willamette.data$P49300<0.83 & willamette.data$P49300>0.02] <- "Low"
willamette.data$Diuron <- ordered(willamette.data$Diuron, levels=c("Below MDL","Low","Medium","High"))
willamette.data$Diuron[is.na(willamette.data$P49300)] <- NA

## arsenic in drinking water

arsenic <- read.csv(paste (dataDIR, "arsenic.csv", sep="/"),header=TRUE)
arsenic$Gender<- "Female"
arsenic$Gender[arsenic$gender==1]<- "Male"

arsenic$Type<- "Bladder"
arsenic$Type[arsenic$type==1]<- "Lung"

##################
### Chapter 1  ###
##################
## no script

##################
### Chapter 2  ###
##################
##
4+8*9
a <- 4+8*9
hi <- "hello, world"
3>4
3<5
Logic <- 3<5
mode(hi)
(3<4) + (3>4)
TP <- c(8.91,  4.76, 10.30,  2.32, 12.47,  4.49,  3.11,  9.61,  6.35,
        5.84,  3.30, 12.38,  8.99,  7.79,  7.58,  6.70,  8.13,  5.47,
        5.27,  3.52)
violation <- TP >10
mean(violation)
sum(TP)
length(TP)

sum(TP)/length(TP)

my.mean <- function(x){
  total <- sum(x)
  n <- length(x)
  total/n
}
my.mean(TP)
mean(TP)
example(mean)
my.mean <- function(x)
  return(mean(x, na.rm=T))

library(Rcmdr)
qnorm(c(.9), mean=2, sd=0.75, lower.tail=TRUE)

set.seed(123)
Norm1 <- as.data.frame(matrix(rnorm(10*10, mean=2, sd=0.75),
                              ncol=10))
rownames(Norm1) <- paste("sample", 1:10, sep="")
colnames(Norm1) <- paste("obs", 1:10, sep="")
Norm1$violations <- with(Norm1,
     (obs1>3) + (obs2>3) + (obs3>3) + (obs4>3) + (obs5>3) +
     (obs6>3) + (obs7>3) + (obs8>3) + (obs9>3) + (obs10>3))
Norm1$impaired <- with(Norm1, as.numeric(violations>1))
numSummary(Norm1[,"impaired"],
     statistics=c("mean", "sd", "quantiles"))

for (i in 1:10000) {
    violation[i] <- sum( rnorm(10, 2, 0.75)>3 ) > 1
}
print(mean(violation))

Norm.data <- matrix(rnorm(10*10000, 2, 0.75), ncol=10)
mean(apply(X=Norm.data, MARGIN=1, FUN=function(x)
           return(sum(x>3)>1)))

Norm2 <- as.data.frame(matrix(rnorm(10000*10, mean=2, sd=1),
                              ncol=10))
rownames(Norm2) <- paste("sample", 1:10000, sep="")
colnames(Norm2) <- paste("obs", 1:10, sep="")
Norm2$violations <- with(Norm2,
     (obs1>3) + (obs2>3) + (obs3>3) + (obs4>3) + (obs5>3) +
     (obs6>3) + (obs7>3) + (obs8>3) + (obs9>3) + (obs10>3))
Norm2$comply <- with(Norm2, as.numeric(violations<2))
numSummary(Norm2[,"comply"],
     statistics=c("mean", "sd", "quantiles"))

Norm3 <- as.data.frame(matrix(rnorm(10000*100, mean=2, sd=0.75),
                              ncol=100))
rownames(Norm3) <- paste("sample", 1:10000, sep="")
colnames(Norm3) <- paste("obs", 1:100, sep="")
Norm3$violations <- apply(X=Norm3, MARGIN=1, FUN=function(x){
                          return(sum(x>3))})
Norm3$impaired <- with(Norm3, as.numeric(violations>10))
numSummary(Norm3[,"impaired"],
     statistics=c("mean", "sd", "quantiles"))

Norm4 <- as.data.frame(matrix(rnorm(10000*100, mean=2, sd=1),
                              ncol=100))
rownames(Norm4) <- paste("sample", 1:10000, sep="")
colnames(Norm4) <- paste("obs", 1:100, sep="")
Norm4$violations <- apply(X=Norm4, MARGIN=1, FUN=function(x){
                          return(sum(x>3))})
Norm4$comply <- with(Norm4, as.numeric(violations <=10))
numSummary(Norm4[,"comply"],
     statistics=c("mean", "sd", "quantiles"))

##################
### Chapter 3  ###
##################
## figure \ref{fig:stdnorm} (3.1)

postscript(file=paste(plotDIR, "normal1.eps", sep="/"), 
           height=1.5, width=2.5, horizontal=F)
par(mar=c(2.5,2.5,.5,1), mgp=c(1.25, 0.25, 0), tck=-0.02, las=1)
plot(seq(-3,3,,100), dnorm(seq(-3,3,,100)), type="l",
     xlab="Y", ylab="", axes=F)
#polygon(c(-1, seq(-1, 1.3,,50), 1.3), c(0, dnorm(seq(-1, 1.3,,50)), 0),
#col=gray(.65))
polygon(c(-3, seq(-3, qnorm(0.25),,50), qnorm(0.25)),
        c(0, dnorm(seq(-3, qnorm(0.25),,50)), 0), col=gray(.45))
polygon(c(2, seq(2, 3,,50), 3), c(0, dnorm(seq(2, 3,,50)), 0),
        col=gray(.8))
text(-2, 0.2, "0.25", cex=0.75)
axis(1, at=c(-3,-2, qnorm(0.25),0, 1,2,3), cex=0.75,
     label=c("-3", "-2","y", "0", "1", "2", "3"))
axis(1, at=-1, label="")
axis(2, cex=0.75)
box()
dev.off()

dnorm(0, 0, 1)
pnorm(0.5, 0, 1)
1-pnorm(0.5,0,1)
qnorm(0.25, 0, 1)
qnorm(0.05, 0, 1)
qnorm(0.95, 0, 1)

## Figure 3.2
postscript(file=paste(plotDIR,"referCHANCE.eps", sep="/"),
           height=2, width=3.5, horizontal=F)
par(mar=c(2.5,2.5,.5,1), mgp=c(1.5, 0.5, 0), las=1, tck=-0.02)
hist(log(TP.reference$RESULT), axes=F, prob=T, dens=-1,
     xlab="TP (ppb)", ylab="Density", main="")
lines(seq(0, log(100),,100),
      dnorm(seq(0, log(100),,100),
            mean(log(TP.reference$RESULT)),
            sd(log(TP.reference$RESULT))))
axis(1, at=log(c(1, 5, 10, 20, 50)), label=c("1", "5","10","20","50"))
axis(2)
box()
dev.off()

c(mean(log(TP.reference$RESULT)), sd(log(TP.reference$RESULT)))

quantile((TP.reference$RESULT),
         prob=c(0.05, 0.1, 0.25, 0.5, 0.75, 0.9,0.92, 0.95))
qlnorm(c(0.05, 0.1, 0.25, 0.5, 0.75, 0.9,0.92, 0.95),
       mean(log(TP.reference$RESULT)), sd(log(TP.reference$RESULT)))
1-plnorm(15, mean(log(TP.reference$RESULT)), sd(log(TP.reference$RESULT)))
mean((TP.reference$RESULT)>15)

y <- rnorm(100)
n <- length(y)
yq <- ((1:n) - 0.5)/n
zq <- qnorm(yq, mean=0, sd=1)
yq <- ((1:n) - 0.5)/n
zq <- qnorm(yq, mean=0, sd=1)
plot(zq, sort(y), xlab="Standard Normal Quantile", ylab="Data")
abline(mean(y), sd(y))

## Figure \ref{fig:evergBoxSL} 3.3
Evg.box <- bwplot((RESULT) ~ SITE, data=TP.reference,
                  xlab="Reference Sites", ylab="TP (ppb)")  
tpref.median <- oneway((RESULT) ~ SITE, data=TP.reference,
                       location=mean, spread=1)
par(mar=c(2.5,2.5,.5,1), mgp=c(1.5, 0.5, 0))
Evg.Sl  <-
  xyplot(sqrt(abs(residuals(tpref.median)))~jitter(fitted.values(tpref.median),
                                                   factor=.5), 
                                        #        aspect=0.75,
         panel=function(x,y){
           panel.xyplot(x,y, col=gray(0.4))
           srmads <- sqrt(tapply(abs(residuals(tpref.median)),
                                 TP.reference$SITE, median))
           oo <- order(tpref.median$location)
           panel.lines(tpref.median$location[oo],srmads[oo])
         },
#        sub = list("Everglades Data",cex=.8),
         xlab="Jittered Mean TP",
         ylab="Sqrt Abs Residuals")

postscript(file=paste(plotDIR, "evergBoxSL.eps", sep="/"),
           height=2, width=5, horizontal=F)
print(Evg.box, position = c(0, 0, 0.5, 1.0), more = T)
print(Evg.Sl , position = c(0.5, 0, 1, 1.0), more = F)

dev.off()

xmin, ymin, xmax, ymax


postscript(file=paste(plotDIR,"evergSLlog.eps", sep="/"),
           height=3, width=3, horizontal=F)
tpref.median <- oneway(log(RESULT) ~ SITE, data=TP.reference,
                       location=mean, spread=1)
par(mar=c(2.5,2.5,.5,1), mgp=c(1.5, 0.5, 0))
xyplot(sqrt(abs(residuals(tpref.median)))~jitter(fitted.values(tpref.median),
                                                 factor=.5),
       aspect=0.75,
       panel=function(x,y){
         panel.xyplot(x,y)
         srmads <- sqrt(tapply(abs(residuals(tpref.median)),
                               TP.reference$SITE, median))
         oo <- order(tpref.median$location)
         panel.lines(tpref.median$location[oo],srmads[oo])
       },
#      sub = list("Everglades Data",cex=.8),
       xlab="Jittered Mean log TP",
       ylab="Square Root Absolute Residual")
dev.off()

### Figure \ref{fig:evergHists} 3.4

postscript(file=paste(plotDIR,"evergHist.eps", sep="/"),
           height=2, width=5, horizontal=F)
par(mfrow=c(1,2), mar=c(2.5,2.5,.5,1), mgp=c(1.5, 0.5, 0))
hist(log(TP.reference$RESULT), dens=-1, xlab="TP (ppb)",
     ylab="", main="", nclass=20)
hist(log(TP.reference$RESULT), dens=-1, xlab="TP (ppb)",
     ylab="", main="", nclass=10)
dev.off()

### Figure \ref{fig:qplot1} 3.5
TP.example<- c(0.21, 0.35, 0.50, 0.64, 0.79,0.90, 1.00, 1.01, 1.12, 5.66)
postscript(file=paste(plotDIR,"evergQplot.eps", sep="/"),
           height=2, width=3, horizontal=F)
par(mar=c(2.5,2.5,.5,1), mgp=c(1.5, 0.5, 0))
qqmath(~TP.example, distribution=qunif, xlab="f", ylab="TP (ppb)")
dev.off()

## Figure \ref{fig:clevelandBox} 3.6
data <-
  c(0.9, 1.6, 2.26305, 2.55052, 2.61059, 2.69284, 2.78511, 2.80955,
    2.94647, 2.96043, 3.05728, 3.15748, 3.18033, 3.20021,
    3.20156, 3.24435, 3.33231, 3.34176, 3.3762, 3.39578, 3.4925,
    3.55195, 3.56207, 3.65149, 3.72746, 3.73338, 3.73869,
    3.80469, 3.85224, 3.91386, 3.93034, 4.02351, 4.03947,
    4.05481, 4.10111, 4.26249, 4.28782, 4.37586, 4.48811,
    4.6001, 4.65677, 4.66167, 4.73211, 4.80803, 4.9812, 5.17246,
    5.3156, 5.35086, 5.36848, 5.48167, 5.68, 5.98848, 6.2, 7.1,
    7.4)

## explaining the box plot
uq <- quantile(data,.75)
lq <- quantile(data,.25)
r <- 1.5*(uq-lq)
h <- c(lq-r,1.6,lq,uq,6.2,uq+r)
writing <- c("lower quartile - 1.5 r",
             "lower adjacent value",
             "lower quartile",
             "upper quartile",
             "upper adjacent value",
             "upper quartile + 1.5 r")

n <- length(data)

postscript(file=paste(plotDIR, "explainBox.eps", sep="/"),
           width=4.75, height=2.25, horizontal=F)
par(mfrow=c(1,2), mar=c(2.5,2.5,.25,0.125), mgp=c(1.5, 0.5, 0))
            #layout(matrix(c(1,2), nrow=1), width=c(1,1.5))
boxplot(data, rep(NA, length(data)), rep(NA, length(data)), ylab = "Data")
usr <- par("usr")
x <- usr[1] + (usr[2] - usr[1]) * 1/3
at <- c(0.9, 1.6, 3.2, 3.8, 4.65, 6.2, 7.2)
arrows(rep(x * 1.15, 7), at, rep(x, 7), at, length=0.075)
mtext("Main Title",1,1,cex=.8)
text(rep(x * 1.2, 7), at, adj = 0, cex=0.7,
     labels = c("outside value", "lower adjacent value",
       "lower quartile", "median", "upper quartile",
       "upper adjacent value", "outside values"))

plot(((1:n)-0.5)/n, data, xlab="f-value", ylab="Data")
abline(h = h, lwd =2, col = gray(0.85))
text(rep(0,3), h[4:6], writing[4:6], adj=0, cex=0.75)
text(rep(1,3), h[1:3], writing[1:3], adj=1, cex=0.75)
points(((1:n)-0.5)/n, data)

dev.off()

## Figure \ref{fig:addVmlt} 3.7
### normal Q-Q plot for additive and multiplicative shifts
x.data <- rnorm(100)
y.data <- rnorm(100, 2)
postscript(file=paste(plotDIR,"additive.eps", sep="/"),
           height=4, width=3.5, horizontal=F)
layout(matrix(c(1,3,2,3), nrow=2), heights=c(1,2), respect=T)
par(mar=c(2.5,2.5,.5,0.5), mgp=c(1.5, 0.5, 0))
hist(x.data, xlim=range(c(x.data,y.data)), xlab="x", ylab="", main="", prob=T)
curve(dnorm(x), add=T, from=-3, to=3)
hist(y.data, xlim=range(c(x.data,y.data)), xlab="y", ylab="", main="", prob=T)
curve(dnorm(x, mean=2), add=T, from=-1, to=5)
qqplot(x.data, y.data, xlim=range(c(x.data,y.data)),
       ylim=range(c(x.data,y.data)), xlab="x", ylab="y")
abline(0,1, col=gray(0.5))
abline(2,1, col=gray(0.5))
dev.off()

x.data2 <- exp(rnorm(100))
y.data2 <- exp(rnorm(100, 1))

postscript(file=paste(plotDIR, "multiplicative.eps", sep="/"),
           height=4, width=3.5, horizontal=F)
layout(matrix(c(1,3,2,3), nrow=2), heights=c(1,2), respect=T)
par(mar=c(2.5,2.5,.5,0.5), mgp=c(1.5, 0.5, 0))
hist(x.data2, xlim=range(c(x.data2,y.data2)),
     xlab="x", ylab="", main="", prob=T, nclass=10)
curve(dlnorm(x), add=T, from=exp(-3), to=exp(3))
hist(y.data2, xlim=range(c(x.data2,y.data2)),
     xlab="y", ylab="", main="", prob=T, nclass=10)
curve(dlnorm(x, mean=1), add=T, from=exp(-2), to=exp(4))
qqplot(x.data2, y.data2, xlim=range(c(x.data2,y.data2)),
       ylim=range(c(x.data2,y.data2)), xlab="x", ylab="y")
abline(0,1, col=gray(0.5))
dev.off()

### Figure 3.7
postscript(file=paste(plotDIR, "addVmult.eps", sep="/"),
           height=3.75, width=4.75, horizontal=F)
layout(rbind(c(1,2,0,4,5), c(3,3,0,6,6)), widths=c(1,1,lcm(0.5), 1,1),
       heights=c(1,2), respect=T)
par(mar=c(2.5,2.5,.5,0.5), mgp=c(1.5, 0.5, 0))

hist(x.data, xlim=range(c(x.data,y.data)), xlab="x", ylab="", main="", prob=T)
curve(dnorm(x), add=T, from=-3, to=3)
hist(y.data, xlim=range(c(x.data,y.data)), xlab="y", ylab="", main="", prob=T)
curve(dnorm(x, mean=2), add=T, from=-1, to=5)
qqplot(x.data, y.data, xlim=range(c(x.data,y.data)),
       ylim=range(c(x.data,y.data)),xlab="x", ylab="y")
abline(0,1, col=gray(0.5))
abline(2,1, col=gray(0.5))

hist(x.data2, xlim=range(c(x.data2,y.data2)),
     xlab="x", ylab="", main="", prob=T, nclass=10)
curve(dlnorm(x), add=T, from=exp(-3), to=exp(3))
hist(y.data2, xlim=range(c(x.data2,y.data2)),
     xlab="y", ylab="", main="", prob=T, nclass=10)
curve(dlnorm(x, mean=1), add=T, from=exp(-2), to=exp(4))
qqplot(x.data2, y.data2, xlim=range(c(x.data2,y.data2)),
       ylim=range(c(x.data2,y.data2)), xlab="x", ylab="y")
abline(0,1, col=gray(0.5))
dev.off()

## Figure \ref{fig:cars.test} 3.8
## Car.test.frame in package rpart
library(rpart)
names(car.test.frame)
postscript(file=paste(plotDIR, "carsTest.eps", sep="/"),
           width=4.75, height=2, horizontal=F)
par(mfrow=c(1,2), mar=c(2.5,2.5,.5,0.5), mgp=c(1.5, 0.5, 0))
plot(Mileage ~ Weight, data=car.test.frame,
     xlab="Weight (lb)", ylab="Mileage (mpg)")
abline(lsfit(car.test.frame$Weight, car.test.frame$Mileage))

plot(Mileage ~ Weight, data=car.test.frame,
     xlab="Weight (lb)", ylab="Mileage (mpg)")
abline(lsfit(car.test.frame$Weight, car.test.frame$Mileage),
       col=gray(0.5), lty=2)
cars.lo <- loess(Mileage ~ Weight, data = car.test.frame)
oo <- order(cars.lo$x)
lines(cars.lo$x[oo], cars.lo$fitted[oo])
dev.off()

## Figure \ref{fig:airquality} 3.9
## Car.test.frame in package rpart
library(rpart)
panel.hist = function(x, col.hist="grey", ...)
  {
    usr <- par("usr"); on.exit(par(usr))
    par(usr = c(usr[1:2], 0, 1.5) )
    h <- hist(x, plot = FALSE)
    breaks <- h$breaks; nB <- length(breaks)
    y <- h$counts; y <- y/max(y)
    rect(breaks[-nB], 0, breaks[-1],y, col=col.hist)
  }

postscript(file=paste(plotDIR, "airquality.eps", sep="/"),
           height=4.5, width=4.5, horizontal=F)
pairs(Ozone~Solar.R+Wind+Temp, data=airquality,
      panel=function(x, y, ...){
        points(x, y,  ...)
        panel.smooth(x, y, col.smooth=1, ...)
      }, col=gray(0.5), cex=0.5, diag.panel=panel.hist)
dev.off()

### Figure \ref{fig:irisPairs} 3.10
### the iris data
Snames <- dimnames(iris3)[[3]]
iris.df <- rbind(iris3[,,1],iris3[,,2],iris3[,,3])
iris.df <- as.data.frame(iris.df)
iris.df$Species <- factor(rep(Snames,rep(50,3)))
#pairs(iris.df[1:4],main = "Anderson�s Iris Data",
#pch = c("<", "+", ">")[unclass(iris$Species)],
#col = c(gray(0.25),gray(0.5),gray(0.25))[unclass(iris$Species)]) 

postscript(file=paste(plotDIR, "irisPairs.eps", sep="/"),
           height=4.5, width=4.5, horizontal=F)
pairs(iris.df[1:4],main = "The Iris Data",
      pch = c("<", "+", ">")[unclass(iris$Species)],
      col = c("#BFBFBF", "#808080", "#404040")[unclass(iris$Species)])
dev.off()

### Figure \ref{fig:piecewise} 3.11
postscript(file=paste(plotDIR,"nadbplot.eps", sep="/"),
           width=4.75, height=1.75, horizontal=F)
par(mfrow=c(1,2), mar=c(2.5,2.5,.5,0.5), mgp=c(1.5, 0.5, 0))
plot(TPOut ~ PLI, data=nadb,
     xlab="P Loading", ylab="P Concentration", cex=0.5)
plot(TPOut ~ PLI, data=nadb,
     xlab="P Loading", ylab="P Concentration", log="x", axes=F, cex=0.5)
axis(1, at=c(0.01, 1, 100), label=c("0.01", "1", "100"))
axis(2)
box()
dev.off()

### Figure \ref{fig:nadbpowers} 3.12
## power transformation
powerT <- function(y, lambda1=c(-1,-1/2,-1/4), lambda2 = c(1/4, 1/2, 1), layout1=2){
  nt <- length(lambda1)+length(lambda2)+1
  transformed <- cbind(outer(y,lambda1,"^"),log(y),(outer(y,lambda2,"^")))
  y.power <- data.frame(transformed=c(transformed),
                        lambda = factor(rep(round(c(lambda1,0,lambda2), 2),
                          rep(length(y),nt))))
  ans <- qqmath(~transformed | lambda,
                data=y.power,
                prepanel = prepanel.qqmathline,
                panel = function(x, ...) {
                  panel.grid(h = 0)
                  panel.qqmath(x, col=gray(0.5))
                  panel.qqmathline(x, distribution = qnorm)
                }, aspect=1, scale = list(y = "free"),
                layout=c(layout1,ceiling(nt/layout1)),
                xlab = "Unit Normal Quantile",
                ylab = "y")
  ans
}

postscript(file=paste(plotDIR, "nadbpowers.eps", sep="/"),
           width= 4., height=5, horizontal=F)
powerT(y=nadb$PLI)
dev.off()

### conditional plot
### Figure \ref{fig:pm2.5-1} 3.13
trellis.device(postscript, file=paste(plotDIR, "pm25plot1.eps", sep="/"),
               height=2, width=3, horizontal=F)
trellis.par.temp <- trellis.par.get()
trellis.par.temp$add.text$cex=0.5 ## change strip text font size
trellis.par.temp$par.xlab.text$cex=0.75 ## xlab font size
trellis.par.temp$par.ylab.text$cex=0.75
xyplot(log.value~AvgTemp, panel=function(x,y,...){
  panel.grid()
  panel.xyplot(x,y, col=grey(0.65), cex=0.5, ...)
  panel.loess(x,y,span=1, degree=1,col=1,...)
}, scales=list(x=list(cex=0.75), y=list(cex=0.75)),
       par.settings=trellis.par.temp,
       data=pmdata, xlab="Average Daily Temperature (F)", ylab="Log PM2.5")
dev.off()

## Figure \ref{fig:pm2.5-2}, 3.14
postscript(file=paste(plotDIR,"pm25coplot2.eps", sep="/"),
           height=1.25, width=4.75, horizontal=F)
trellis.par.temp <- trellis.par.get()
trellis.par.temp$add.text$cex=0.5 ## change strip text font size
trellis.par.temp$par.xlab.text$cex=0.75 ## xlab font size
trellis.par.temp$par.ylab.text$cex=0.75
xyplot(log.value~AvgTemp|Month, panel=function(x,y,...){
  panel.grid()
  panel.xyplot(x,y, col=grey(0.65), cex=0.5, ...)
  panel.loess(x,y,span=1, degree=1,col=1,...)
  }, layout=c(12, 1),
       scales=list(x=list(relation="free", cex=0.4,
           alternating=c(1,2))),
       ## x-axis relation and font size
  par.settings=trellis.par.temp,
  data=pmdata, xlab="Average Daily Temperature (F)", ylab="Log PM2.5")
dev.off()

## the air quality data

### Figure \ref{fig:airQcop1}
## traditional coplot
coplot(sqrt(Ozone) ~ Solar.R|Wind*Temp , data=airquality,
       given.values=list(co.intervals(airquality$Wind, 3, 0.25),
         co.intervals(airquality$Temp, 3, 0.25)),
       panel=function(x, y, ...)
       panel.smooth(x, y, span=1, ...),
       ylab="Log Ozone",
       xlab=c("Solar Radiation", "Wind","Temperature"))

Wind_Speed <- equal.count(airquality$Wind, 3, 0.25)
Temperature <- equal.count(airquality$Temp, 3, 0.25)
Solar_R <- equal.count(airquality$Solar.R, 3, 0.25)


postscript(file=paste(plotDIR, "airQcoplot1.eps", sep="/"),
           width=3.75, height=4, horizontal=F)
trellis.par.set(theme = canonical.theme("postscript", col=FALSE))
trellis.par.set(list(layout.widths=list(left.padding=0, right.padding=0,
                       ylab.axis.padding=0, axis.right=0, key.ylab.padding=0)))
print(
xyplot(sqrt(Ozone) ~ Solar.R|Wind_Speed*Temperature,
       data=airquality,
       panel=function(x,y,...){
#            panel.loess(x, y, span=1, degree=1, ...)
            panel.grid()
            panel.lmline(x, y, col="grey",...)
            panel.xyplot(x, y, col=1, cex=0.5, ...)
       },
       ylab=list(label="Sqrt Ozone", cex=0.6),
       xlab=list(label="Solar Radiation", cex=0.6),
       scales=list(x=list(alternating=c(1, 2, 1))),
#       between=list(y=1),
       par.strip.text=list(cex=0.4), aspect=1,
       par.settings=list(axis.text=list(cex=0.4)))
)
dev.off()

postscript(file=paste(plotDIR, "airQcoplot2.eps", sep="/"),
           width=3.75, height=4, horizontal=F)
trellis.par.set(theme = canonical.theme("postscript", col=FALSE))
trellis.par.set(list(layout.widths=list(left.padding=0, right.padding=0,
                       ylab.axis.padding=0, axis.right=0, key.ylab.padding=0)))
print(
      xyplot(sqrt(Ozone) ~ Wind|Solar_R*Temperature,
             data=airquality,
             panel=function(x,y,...){
#            panel.loess(x, y, span=1, degree=1, ...)
               panel.grid()
               panel.lmline(x, y, col="grey",...)
               panel.xyplot(x, y, col=1, cex=0.5, ...)
             },
             ylab=list(label="Sqrt Ozone", cex=0.6),
             xlab=list(label="Wind Speed", cex=0.6),
             scales=list(x=list(alternating=c(1, 2, 1))),
                                        #       between=list(y=1),
             par.strip.text=list(cex=0.4), aspect=1,
             par.settings=list(axis.text=list(cex=0.4)))
      )
dev.off()

postscript(file=paste(plotDIR, "airQcoplot3.eps", sep="/"),
           width=3.75, height=4, horizontal=F)
trellis.par.set(theme = canonical.theme("postscript", col=FALSE))
trellis.par.set(list(layout.widths=list(left.padding=0, right.padding=0,
                       ylab.axis.padding=0, axis.right=0, key.ylab.padding=0)))
print(
xyplot(sqrt(Ozone) ~ Temp|Wind_Speed*Solar_R,
       data=airquality,
       panel=function(x,y,...){
#            panel.loess(x, y, span=1, degree=1, ...)
            panel.grid()
            panel.lmline(x, y, col="grey",...)
            panel.xyplot(x, y, col=1, cex=0.5, ...)
       },
       ylab=list(label="Sqrt Ozone", cex=0.6),
       xlab=list(label="Temperature", cex=0.6),
       scales=list(x=list(alternating=c(1, 2, 1))),
#       between=list(y=1),
       par.strip.text=list(cex=0.4), aspect=1,
       par.settings=list(axis.text=list(cex=0.4)))
)
dev.off()

################
## Chapter 4  ##
################

 n.sims <- 1000
    n.size <- 30
    inside <- 0
    for (i in 1:n.sims){  ## looping through n.sims iterations
        y <- rnorm(n.size, mean=2.05, sd=0.34)
            ## random samples from N(2.05, 0.34)
        se <- sd(y)/sqrt(n.size)
        int.95 <- mean(y) + qt(c(.025, .975), n.size-1)*se
        inside <- inside + sum(int.95[1]<2.05 & int.95[2]>2.05)
        }
    inside/n.sims  ## fraction of times true mean inside int.95

 n.sims <- 1000
    n.size <- 30
    inside <- 0
    for (i in 1:n.sims){  ## looping through n.sims iterations
        y <- runif(n.size, 1.05, 3.05)
            ## random samples from N(2.05, 0.34)
        se <- sd(y)/sqrt(n.size)
        int.95 <- mean(y) + qt(c(.025, .975), n.size-1)*se
        inside <- inside + sum(int.95[1]<2.05 & int.95[2]>2.05)
        }
    inside/n.sims  ## fraction of times true mean inside int.95

table(TP.reference$Year, TP.reference$Month)

histogram(~log(RESULT) | SITE, data=TP.reference)

postscript(file=paste(plotDIR,"EvergQQs.eps", sep="/"),
           width=4, height=3.5, horizontal=F)
trellis.par.set(theme = canonical.theme("postscript", col=FALSE))
trellis.par.set(list(layout.widths=list(left.padding=0, right.padding=0,
                       ylab.axis.padding=0, axis.right=0, key.ylab.padding=0)))
print(
qqmath(~log(RESULT) | factor(Year),
  panel=function(x, ...){
    panel.grid()
    panel.qqmathline(x, ...)
    panel.qqmath(x, ...)
    }, data=TP.reference,
    subset=SITE!="E5"&SITE!="F5",
    par.strip.text=list(cex=0.5),
    xlab="Unit Normal Quantile",
    ylab="Log TP Concentration (ppb)")
)
dev.off()

qqmath(~log(RESULT) | SITE,
  panel=function(x, ...){
    panel.qqmathline(x, ...)
    panel.qqmath(x, ...)
    }, data=TP.reference,
    subset=SITE!="E5"&SITE!="F5")


qqmath(~log(RESULT) | Month,
  panel=function(x, ...){
    panel.qqmathline(x, ...)
    panel.qqmath(x, ...)
    }, data=TP.reference)

## precipitation
EvergPrecip <- read.table(paste(dataDIR, "EvergPrecip.txt", sep="/"),
                          header=F)
EvergPrecip2 <- read.table(paste(dataDIR, "EvergladesP.txt", sep="/"),
                           header=T)

EvergPrecip2$ANN2 <- apply(EvergPrecip2[,2:13], 1, sum)
EvergPrecip2$Msd <- apply(EvergPrecip2[,2:13], 1, sd)

Y.lim <- c(0.99, 1.1)*range(c(EvergPrecip2$ANN2+2*EvergPrecip2$Msd),
                            c(EvergPrecip2$ANN2-2*EvergPrecip2$Msd))
postscript(file=paste(plotDIR, "EvergPrecip.eps", sep="/"),
           width=3.75, height=2.5, horizontal=F)
par(mar=c(2.5,2.5,0.5,0.25), mgp=c(1.5, 0.5, 0))
plot(EvergPrecip2$ANN2/12 ~ EvergPrecip2$YEAR, type="n",
     xlab="Year", ylab="Annual Precipitation (in)", ylim= Y.lim, xlim=c(1990,2003)) 
segments(x0= EvergPrecip2$YEAR, x1=EvergPrecip2$YEAR,
         y0=EvergPrecip2$ANN2-2*EvergPrecip2$Msd,
         y1=EvergPrecip2$ANN2+2*EvergPrecip2$Msd)
segments(x0= EvergPrecip2$YEAR, x1=EvergPrecip2$YEAR,
         y0=EvergPrecip2$ANN2-EvergPrecip2$Msd,
         y1=EvergPrecip2$ANN2+EvergPrecip2$Msd, lwd=3)
points(EvergPrecip2$YEAR, EvergPrecip2$ANN2)
segments(x0=c(1993.5, 1999.5), x1=c(1993.5, 1999.5),
         y0=rep(Y.lim[1], 2), y1=rep(Y.lim[2], 2), lwd=2, col="grey")
segments(x0=rep(1993.5, 2), x1=rep(1999.5, 2),
         y0=c(Y.lim[1], Y.lim[2]), y1=c(Y.lim[1], Y.lim[2]), lwd=2, col="grey")
abline(h=mean(EvergPrecip2$ANN2), col=gray(0.5) )
dev.off()

by(TP.reference$Month, TP.reference$Year, table)

table(TP.reference$Year)

TP.impacted <- wca2tp[wca2tp$Type=="I",]
subI <- (TP.impacted$SITE=="E4"|TP.impacted$SITE=="F4")&TP.impacted$Year==1994
subS <- TP.reference$Year==1994&TP.reference$SITE!="E5"&TP.reference$SITE!="F5"
two.sample <- data.frame(TP = c(TP.impacted$RESULT[subI],
                           TP.reference$RESULT[subS]),
                         Type=c(rep("I", sum(subI)), rep("R", sum(subS))))
qq(Type~TP, data=two.sample)
qqmath(~log(RESULT)|SITE, data=TP.impacted)

x<-log(TP.impacted$RESULT[subI])
y<-log(TP.reference$RESULT[subS])
t.test(x, y, alternative="greater", var.equal=T)

y.bar <- mean(log(TP.reference$RESULT[subS]))
sd(log(TP.reference$RESULT[subS]))
n <- sum(subS)
se <- sd(log(TP.reference$RESULT[subS]))/sqrt(n)
int.50 <- y.bar + qt(c(0.25, 0.75), n-1)*se
int.95 <- y.bar + qt(c(.025, .975), n-1)*se

n.sims <- 1000
n.size <- 30
inside <- 0
for (i in 1:n.sims){  ## looping through 5000 iterations
  y <- rnorm(n.size, mean=2.05, sd=0.34)
  ## random samples from N(2.05, 0.34)
  se <- sd(y)/sqrt(n.size)
  int.95 <- mean(y) + qt(c(.025, .975), n.size-1)*se
  inside <- inside + sum(int.95[1]<2.05 & int.95[2]>2.05)
}
inside/n.sims  ## fraction of times true mean inside int.95


n.sims <- 10000
n.size <- 30
inside <- 0
for (i in 1:n.sims){  ## looping through 5000 iterations
  y <- runif(n.size, 1, 3)
  ## random samples from uniform (1,3) with a mean of 2
  se <- sd(y)/sqrt(n.size)
  int.95 <- mean(y) + qt(c(.025, .975), n.size-1)*se
  inside <- inside + sum(int.95[1]<2 & int.95[2]>2)
}
inside/n.sims  ## fraction of times true mean inside int.95

                                        #
                                        # Simulation of central limit theorem
                                        #

## Two probability distributions
two.prob<- function(mux=1, vx=1, alpha=2.5, gamma=0.5){
  par(mfrow=c(2,1))
  plot(seq(0,20,,100), dlnorm(seq(0,20,,100), mux, sqrt(vx)), type="l", xlab="Log Normal X", ylab="")
  usr <- par("usr")
  abline(v=exp(mux+vx/2),col=5)
  s2 <- (exp(vx-1))*exp(2*mux+vx)
  mn <- exp(mux+vx/2)
  text.x <- usr[1] + 0.75*(usr[2]-usr[1])
  text.y <- usr[3] + 0.5*(usr[4]-usr[3])
  text(x=text.x, y=text.y, bquote(paste(mu," = ", .(round(mn, digit=2)), ", ", sigma," = ", .(round(sqrt(s2), digit=2)))))
  plot(seq(0,20,,100), dgamma(seq(0,20,,100), alpha, gamma), type="l", xlab="Gamma X", ylab="")
  abline(v=alpha/gamma, col=5)
  s2 <- alpha/gamma^2
  mn <- alpha/gamma
  usr <- par("usr")
  text.x <- usr[1] + 0.75*(usr[2]-usr[1])
  text.y <- usr[3] + 0.5*(usr[4]-usr[3])
  text(x=text.x, y=text.y, bquote(paste(mu," = ", .(round(mn, digit=2)), ", ", sigma," = ", .(round(sqrt(s2), digit=2)))))
  invisible()
}

                                        #c(x1, x2, y1, y2)
two.prob()

## simulation for illustrating the central limit theorem
central.sim <- function(mux=1.5, vx=2, alpha=2.5, gamma=0.5, n=c(10, 50, 100)){
  X.ln <- X.gm <- numeric()
  
  par(mfcol=c(2,3), mar=c(2.5,.75,2.5,0.25), mgp=c(1.5, 0.5, 0))
  for (k in n){
    for (i in 1:10000){
      X.ln[i] <- mean(rlnorm(k, mux, sqrt(vx)))
      X.gm[i] <- mean(rgamma(k, alpha, gamma))
    }
    hist(X.ln, prob=T, xlim=c(0,20), ylim=c(0, 0.7),
         main=paste("N = ", k, sep=""), xlab="Log-Normal X", ylab="", axes=F)
    axis(1)
    lines(seq(0,20,,1000), dlnorm(seq(0,20,,1000), mux, sqrt(vx)))
    abline(v=exp(mux+vx/2), col="grey")
    s2 <- (exp(vx-1))*exp(2*mux+vx)
    mn <- exp(mux+vx/2)
    usr <- par("usr")
    text.x <- usr[1] + 0.65*(usr[2]-usr[1])
    text.y <- usr[3] + 0.5*(usr[4]-usr[3])
    text(x=text.x, y=text.y,
         bquote(paste(hat(mu)," = ", .(round(mean(X.ln), digit=2)), ", ",
                      hat(sigma)," = ", .(round(sd(X.ln), digit=2)))),
         cex=0.85)
    text.y <- usr[3] + 0.25*(usr[4]-usr[3])
    text(x=text.x, y=text.y,
         bquote(paste(mu," = ", .(round(mn, digit=2)), ", ",
                      sigma," = ", .(round(sqrt(s2/k), digit=2)))),
         cex=0.85)
    hist(X.gm, prob=T, nclass=20, xlim=c(0,20), main=paste("N = ", k, sep=""),
         xlab="Gamma X", ylab="", ylim=c(0, 1.2), axes=F)
    axis(1)
    lines(seq(0,20,,100), dgamma(seq(0, 20,,100), alpha, gamma))
    abline(v=alpha/gamma, col="grey")
    s2 <- alpha/gamma^2
    mn <- alpha/gamma
        usr <- par("usr")
    text.x <- usr[1] + 0.65*(usr[2]-usr[1])
    text.y <- usr[3] + 0.5*(usr[4]-usr[3])
    text(x=text.x, y=text.y,
         bquote(paste(hat(mu)," = ", .(round(mean(X.gm), digit=2)), ", ",
                      hat(sigma)," = ", .(round(sd(X.gm), digit=2)))),
         cex=0.85)
    text.y <- usr[3] + 0.25*(usr[4]-usr[3])
    text(x=text.x, y=text.y, bquote(paste(mu," = ", .(round(mn, digit=2)), ", ",
                     sigma," = ", .(round(sqrt(s2/k), digit=2)))), cex=0.85)
  }
}

postscript(file=paste(plotDIR, "cltSims.eps", sep="/"),
           width=4.75, height=3, horizontal=F)
central.sim(mux=1, vx=1, n=c(5, 20, 100))
dev.off()

## uncertainty of sigma
n.sims <- 1000
subS <- TP.reference$Year==1994&TP.reference$SITE!="E5"&TP.reference$SITE!="F5"
y.bar <- mean(log(TP.reference$RESULT[subS]))
n <- sum(subS)
se <- sd(log(TP.reference$RESULT[subS]))
X <- rchisq (n.sims, df=n-1)
sigma.chi2 <- se * sqrt((n-1)/X)
postscript(file="sigmaChi2.eps", width=3, height=2, horizontal=F)
par(mar=c(2.5,.75,2.5,0.25), mgp=c(1.5, 0.5, 0))
hist(sigma.chi2, axes=F, xlab=expression(hat(sigma)), main="")
axis(1, cex=0.5)
abline(v=se, lwd=3, col="grey")
dev.off()

sample.mean <- rnorm(n.sims, y.bar, sigma.chi2/sqrt(n))
q.75 <- qnorm(0.75, sample.mean, sigma.chi2)

postscript(file=paste(plotDIR, "q75.eps", sep="/"),
           width=3, height=2, horizontal=F)
par(mar=c(2.5,.75,2.5,0.25), mgp=c(1.5, 0.5, 0))
hist(exp(q.75), axes=F, xlab="0.75 Quantile Distribution", main="")
axis(1)
dev.off()

## bootstraping
x <- c(94, 38, 23, 197, 99, 16, 141)
boot.theta <- numeric()
B <- 10000
for (i in 1:B){
  boot.sample <- sample(x, size=length(x), T)
  boot.theta[i] <- mean(boot.sample)
}
sd(boot.theta)

require(bootstrap)


y <- log(TP.reference$RESULT[subS])
results <- bootstrap(y, 2000, quantile, prob=0.75)
CI.t <- c( mean(results $ thetastar) - qt(0.975, 29),
          mean(results $ thetastar) + qt(0.975, 29))
CI.t
                                        #[1] 0.1997 4.2902

CI.percent <- quantile(results$thetastar, prob=c(0.025, 0.975))


bca.results <- bcanon(y,2000,theta=quantile, prob=0.75, alpha=c(0.025, 0.975))
bca.results$confpoints

### t and normal ###
postscript(file=paste(plotDIR, "normalT.eps", sep="/"),
           height=2, width=2.5, horizontal=F)
par(mar=c(2.5,.75,2.5,0.25), mgp=c(1.5, 0.5, 0))
plot(seq(-3,3,,100), dnorm(seq(-3,3,,100)), type="l",
     col="gray", axes=F, xlab="",ylab="")
curve(dt(x, 3),add=T)
axis(1)
box()
dev.off()

### rejection region ###
postscript(file=paste(plotDIR, "rejectR1.eps", sep="/"),
           height=3.75, width=4.5, horizontal=F)
par(mfrow=c(2,1),mar=c(2,0,0,0), mgp=c(1.5, 0.5, 0))
## the null
plot(seq(-3,3,,100), dnorm(seq(-3,3,,100)), type="l",
     xlab="", ylab="", axes=F, xlim=c(-3,6))
polygon(c(1.75, seq(1.75, 3,,50), 3), c(0, dnorm(seq(1.75, 3,,50)), 0),
        col=gray(.8))
polygon(c(2.25, seq(2.25, 3,,50), 3), c(0, dnorm(seq(2.25, 3,,50)), 0),
        density=20, angle=45)
text(1.9, dnorm(1.9)/2, expression(alpha))
text(2.25, dnorm(0)/1.8, expression(t[obs]), adj=c(0,1))
segments(x0=2.25, x1=2.25, y0=0, y1=dnorm(0)/2.1)
text(2.75, dnorm(2.5)*4.2, expression(p-value), adj=c(0,0))
text(6, dnorm(0)*(2/3), expression(H[0]), adj=1)
arrows(x0=2.5, y0=dnorm(2.5)/2, x1=2.75, y1=dnorm(2.5)*4, length=0.1,
       angle=25, code=1)
abline(v=1.75)
axis(1, at=seq(-2,6,2)[-3], label=rep("", 4))
axis(1, at=c(1.75), label=expression(t[cutoff]))
axis(1, at=c(0), label=expression(mu[0]))
## the alternative
plot(seq(0,6,,100), dnorm(seq(0,6,,100), mean=3), type="l",
     xlab="", ylab="", axes=F, xlim=c(-3,6))
#polygon(c(-1, seq(-1, 1.3,,50), 1.3), c(0, dnorm(seq(-1, 1.3,,50)), 0),
#col=gray(.65))
axis(1, at=c(3), label=expression(mu[a]))
axis(1, at=seq(-2,6,2)[-3], label=rep("", 4))
abline(v=1.75)
#polygon(c(1.75, seq(1.75, 6,,50), 6), c(0, dnorm(seq(1.75, 6,,50),3 ), 0),
#density=20, angle=45)
polygon(c(0, seq(0, 1.75,,50), 1.75), c(0, dnorm(seq(0, 1.75,,50),3 ), 0),
        density=15, angle=-45)
text(3, dnorm(0)/2, expression(1-beta))
text(3, dnorm(0)/4, "(power)")
text(1, dnorm(1.75, 3)/2, expression(beta))
text(-2, dnorm(0)*(2/3), expression(H[a]), adj=0)
dev.off()

### two-sided p-value and alpha
postscript(file=paste(plotDIR, "rejectR2.eps", sep="/"),
           height=2., width=4.5, horizontal=F)
par(mar=c(2,0,0,0), mgp=c(1.5, 0.5, 0))
## the null
plot(seq(-3,3,,100), dnorm(seq(-3,3,,100)), type="l",
     xlab="", ylab="", axes=F)
polygon(c(1.75, seq(1.75, 3,,50), 3), c(0, dnorm(seq(1.75, 3,,50)), 0),
        col=gray(.8))
polygon(c(-3, seq(-3, -1.75,,50), -1.75), c(0, dnorm(seq(-3, -1.75,,50)), 0),
        col=gray(.8))
polygon(c(2.25, seq(2.25, 3,,50), 3), c(0, dnorm(seq(2.25, 3,,50)), 0),
        density=20, angle=45)
polygon(c(-3, seq(-3,-2.25,,50), -2.25), c(0, dnorm(seq(-3, -2.25,,50)), 0),
        density=20, angle=-45)

text(3, dnorm(2.5)*4.2, expression(p-value/2), adj=c(1,0), cex=0.75)
text(-3, dnorm(2.5)*4.2, expression(p-value/2), adj=c(0,0), cex=0.75)

arrows(x0=2.5, y0=dnorm(2.5)/2, x1=2.75, y1=dnorm(2.5)*4, length=0.1,
       angle=25, code=1)
arrows(x0=-2.5, y0=dnorm(2.5)/2, x1=-2.75, y1=dnorm(2.5)*4, length=0.1,
       angle=25, code=1)

axis(1, at=c(1.75), label=expression(t[cutoff]))
axis(1, at=c(2.25), label=expression(t[obs]))
axis(1, at=c(-1.75), label=expression(-t[cutoff]))
axis(1, at=c(-2.25), label=expression(-t[obs]))
axis(1, at=c(0), label=expression(mu[0]))
text( 1.8, dnorm(1.9)/2.2, expression(alpha/2), adj=c(0, 0.5), cex=0.75)
text(-1.8, dnorm(1.9)/2.2, expression(alpha/2), adj=c(1, 0.5), cex=0.75)
axis(1, at=c(-3,3), label=c("", ""))
dev.off()


postscript(file="power2.ps", height=4, width=4.5, horizontal=F)
par(mfrow=c(2,2), mar=c(1.5, .25, 0.5, 0.), mgp=c(1.5, 0.5, 0))
z <- qnorm(1-0.05/2)
plot(seq(7, 17,,100), dnorm(seq(7,17,,100), 10, 2/sqrt(10)), type="l",
     xlab="", ylab="", ylim=c(0, 1.1), axes=F)
lines(seq(7, 17,,100), dnorm(seq(7,17,,100), 12, 2/sqrt(10)), type="l",
      col=gray(0.5))
abline(v=10+z*2/sqrt(10), lty=5, col=gray(0.5))
text(10, dnorm(10,10, 2/sqrt(10)), expression(H[0]), adj=c(0.5,0))
text(12, dnorm(12,12, 2/sqrt(10)), expression(H[a]), adj=c(0.5,0))
text(13, 0.6, expression(n==10), adj=c(0,0.5))
text(13, 0.5, expression(sigma==2), adj=c(0,0.5))
text(13, 0.4, expression(alpha==0.05), adj=c(0,0.5))
text(13, 0.75, paste("Power = ",
                     round(1-pnorm(10+z*2/sqrt(10), 12, 2/sqrt(10)), digit=3),
                     sep=""), adj=c(0,0.5))
axis(1)

plot(seq(7, 17,,100), dnorm(seq(7,17,,100), 10, 3/sqrt(10)), type="l",
     xlab="", ylab="", ylim=c(0, 1.1), axes=F)
lines(seq(7, 17,,100), dnorm(seq(7,17,,100), 12, 3/sqrt(10)), type="l",
      col=gray(0.5))
abline(v=10+z*3/sqrt(10), lty=5, col=gray(0.5))
#abline(v=5:10, col=1:6)
text(10, dnorm(10, 10, 3/sqrt(10)), expression(H[0]), adj=c(0.5,0))
text(12, dnorm(12, 12, 3/sqrt(10)), expression(H[a]), adj=c(0.5,0))
text(12.75, 0.6, expression(n==10), adj=c(0,0.5))
text(12.75, 0.5, expression(sigma==3), adj=c(0,0.5))
text(12.75, 0.4, expression(alpha==0.05), adj=c(0,0.5))
text(12.75, 0.75,
     paste("Power = ", round(1-pnorm(10+z*3/sqrt(10), 12, 4/sqrt(10)), digit=3),
           sep=""), adj=c(0,0.5))
axis(1)

plot(seq(7, 17,,100), dnorm(seq(7,17,,100), 10, 2/sqrt(20)), type="l",
     xlab="", ylab="", ylim=c(0, 1.1), axes=F)
lines(seq(7, 17,,100), dnorm(seq(7,17,,100), 12, 2/sqrt(20)), type="l",
      col=gray(0.5))
abline(v=10+z*2/sqrt(20), lty=5, col=gray(0.5))
text(10, dnorm(10, 10, 2/sqrt(20)), expression(H[0]), adj=c(0.5,0))
text(12, dnorm(12, 12, 2/sqrt(20)), expression(H[a]), adj=c(0.5,0))
text(12.75, 0.6, expression(n==20), adj=c(0,0.5))
text(12.75, 0.5, expression(sigma==2), adj=c(0,0.5))
text(12.75, 0.4, expression(alpha==0.05), adj=c(0,0.5))
text(12.75, 0.75, paste("Power = ",
                        round(1-pnorm(10+z*2/sqrt(20), 12, 2/sqrt(20)), digit=3),
                        sep=""), adj=c(0,0.5))
axis(1)

z <- qnorm(1-0.1/2)
plot(seq(7, 17,,100), dnorm(seq(7,17,,100), 10, 3/sqrt(10)), type="l",
     xlab="", ylab="", ylim=c(0, 1), axes=F)
lines(seq(7, 17,,100), dnorm(seq(7,17,,100), 12, 3/sqrt(10)), type="l",
      col=gray(0.5))
abline(v=10+z*3/sqrt(10), lty=5, col=gray(0.5))
text(10, dnorm(10, 10, 3/sqrt(10)), expression(H[0]), adj=c(0.5, 0))
text(12, dnorm(12, 12, 3/sqrt(10)), expression(H[a]), adj=c(0.5, 0))
text(12.75, 0.6, expression(n==10), adj=c(0,0.5))
text(12.75, 0.5, expression(sigma==3), adj=c(0,0.5))
text(12.75, 0.4, expression(alpha==0.1), adj=c(0,0.5))
text(12.75, 0.75, paste("Power = ",
                        round(1-pnorm(10+z*3/sqrt(10), 12, 4/sqrt(10)), digit=3),
                        sep=""), adj=c(0,0.5))
axis(1)
dev.off()

#### 303(d) listing power ####
sample.size <- 10:50
reject <- qbinom(1-0.05, size=sample.size, prob=0.1) + 1
decision.table <- data.frame(n=sample.size, reject=reject,
                             typeI = 1-pbinom(reject-1, sample.size, 0.1),
                             power=1-pbinom(reject-1,
                               size=sample.size, prob=0.25))
postscript(file="cwa303d.eps", width=4.5, height=2, horizontal=F)
par(mfrow=c(1,2),mar=c(3, 3, 0.25, 0.25), mgp=c(1.5, 0.5, 0))
plot(typeI ~ n,data=decision.table, type="l", ylim=c(0,0.1),
     xlab="Sample Size", ylab=expression(alpha))
plot(power~n, data=decision.table, type="l",
     xlab="Sample Size", ylab=expression(1-beta))
dev.off()

### linear models ####
##Chapter 5

subI <- (TP.impacted$SITE=="E4"|TP.impacted$SITE=="F4")&TP.impacted$Year==1994
subR <- TP.reference$Year==1994&TP.reference$SITE!="E5"&TP.reference$SITE!="F5"
two.sample <- data.frame(TP=c(TP.impacted$RESULT[subI], TP.reference$RESULT[subR]),
                         Type=c(rep("I", sum(subI)), rep("R", sum(subR))))
t.test(log(TP) ~ Type, data=two.sample, var.equal=T)
two.sample <- data.frame(y = 1000*c(TP.impacted$RESULT[subI],
                           TP.reference$RESULT[subR]),
                         x = c(rep(1, sum(subI)),rep(0, sum(subR))))
 t2lm <- lm(log(y) ~ x, data=two.sample)
 summary(t2lm)

two.sample2 <- data.frame(y = c(TP.impacted$RESULT[subI],
                            TP.reference$RESULT[subR]),
                          Imp=c(rep(1, sum(subI)), rep(0, sum(subR))),
                          Ref=c(rep(0, sum(subI)), rep(1, sum(subR))))

t2lm2 <- lm(log(y) ~ Imp+Ref-1, data=two.sample2)
summary(t2lm2)

Everg.aov <- aov(log(RESULT) ~ factor(Year), data=TP.reference)
postscript(file=paste(plotDIR, "aovResids1.eps", sep="/"),
           width=2.5, height=2.5, horizontal=F)
qqmath(~resid(Everg.aov),
       panel = function(x,...) {
          panel.grid()
          panel.qqmath(x,...)
          panel.qqmathline(x,...)
       }, ylab="Residuals", xlab="Unit Normal Quantile"
)
dev.off()

postscript(file=paste(plotDIR, "aovResids2.eps", sep="/"),
           width=3, height=2.5, horizontal=F)
xyplot(sqrt(abs(resid(Everg.aov)))~fitted(Everg.aov),
       panel=function(x,y,...){
         panel.grid()
         panel.xyplot(x, y,...)
         panel.loess(x, y, span=1, col="grey",...)
       }, ylab="Sqrt. Abs. Residualt", xlab="Fitted")
dev.off()

postscript(file=paste(plotDIR, "aovResids3.eps", sep="/"),
           width=3, height=2.5, horizontal=F)
xyplot(resid(Everg.aov)~fitted(Everg.aov),
       panel=function(x,y,...){
         panel.grid()
         panel.xyplot(x, y,...)
         panel.abline(0, 0)
                    #        panel.loess(x, y, span=1, col="grey",...)
       }, ylab="Residualt", xlab="Fitted")
dev.off()

Everg.aov <- aov((RESULT)^-0.75 ~ factor(Year), data=TP.reference)
postscript(file=paste(plotDIR, "aovResids4.eps", sep="/"),
           width=2.5, height=2.5, horizontal=F)
qqmath(~resid(Everg.aov),
       panel = function(x,...) {
         panel.grid()
         panel.qqmath(x,...)
         panel.qqmathline(x,...)
       }, ylab="Residuals", xlab="Unit Normal Quantile"
       )
dev.off()

anova.data <- data.frame(y=TP.reference$TP,
                         x2=ifelse(TP.reference$Year==1995, 1, 0),
                         x3=ifelse(TP.reference$Year==1996, 1, 0),
                         x4=ifelse(TP.reference$Year==1997, 1, 0),
                         x5=ifelse(TP.reference$Year==1998, 1, 0),
                         x6=ifelse(TP.reference$Year==1999, 1, 0))
anova.lm <- lm(log(y) ~ x2+x3+x4+x5+x6, data=anova.data)
summary(anova.lm)

anova.lm <- lm(log(TP) ~ factor(Year), data=TP.reference)
summary(anova.lm)

anova.lm <- lm(log(TP) ~ factor(Year)-1, data=TP.reference)
summary(anova.lm)

anova.lm <- lm((TP)^0.25 ~ factor(Year), data=TP.reference)
summary(anova.lm)

powerT(TP.reference$TP)

### ANOVA and multiple comparisons ###
# Ellison et al 1996
mangrove.sponge <- read.table(paste(dataDIR, "completespongedata.txt", sep="/"),
                              header=T)

postscript(file=paste(plotDIR, "mangroveData1.eps", sep="/"),
           width=4, height=3, horizontal=F)
par(mar=c(3,3,0.5,0.5), mgp=c(1.5,0.5,0))
plot(RootGrowthRate ~ Treatment, data=mangrove.sponge,
     xlab="Treatment", ylab="Root Growth Rate (mm/day)", cex.axis=0.75)
dev.off()

trellis.device(postscript, file=paste(plotDIR, "mangroveData2.eps", sep="/"),
               width=4, height=4, horizontal=F)
trellis.par.temp <- trellis.par.get()
trellis.par.temp$add.text$cex=0.5 ## change strip text font size
trellis.par.temp$par.xlab.text$cex=0.75 ## xlab font size
trellis.par.temp$par.ylab.text$cex=0.75
trellis.par.set(theme = canonical.theme("postscript", col=FALSE),
                trellis.par.temp)
qqmath(~RootGrowthRate|Treatment, data=mangrove.sponge,
       panel=function(x, ...){
         panel.qqmath(x, ...)
         panel.qqmathline(x, ...)
         panel.grid()
       }, xlab="Unit Norma Quantile", ylab="Root Growth Rate (mm/day)")
dev.off()
mangrove.lm <- lm(RootGrowthRate ~ Treatment, data=mangrove.sponge)
summary.aov(mangrove.lm)
mangrove.lm2 <- lm(RootGrowthRate ~ Treatment*Location, data=mangrove.sponge)
summary.aov(mangrove.lm2)

lm.plots(mangrove.lm)
mangrove.aov <- aov(RootGrowthRate ~ Treatment, data=mangrove.sponge)
mangrove.multcomp <- TukeyHSD(mangrove.aov)

plot.TukeyHSD(TukeyHSD(mangrove.aov))

library(multcomp)
q2<-glht(mangrove.aov, linfct=mcp(Treatment="Tukey"))
summary(q2)
postscript(file="mangroveHSD.eps", width=4, height=3, horizontal=F)
par(mar=c(3, 10, 3, 1), mgp=c(1.5,0.5,0))
plot(q2)
dev.off()

contr <- rbind("F - C" = c(-1, 1, 0, 0),
                 "H - C" = c(-1, 0, 1, 0),
                 "T - C" = c(-1, 0, 0, 1),
                 "S - F" = c(0, -1, 1/2, 1/2),
                 "S - C" = c(-1, 0, 1/2, 1/2))
q3 <-  glht(mangrove.aov, linfct = mcp(Treatment = contr))

plot(q3)

summary(q3, test=adjusted(type=c("none")))

contr2 <- rbind(  "S - F" = c(0, -1, 1/2, 1/2),
                 "S - C" = c(-1, 0, 1/2, 1/2))
q4 <-  glht(mangrove.aov, linfct = mcp(Treatment = contr2))

plot(q4)

summary(q4, test=adjusted(type=c("none")))


mangrove.aov2 <- aov(RootGrowthRate ~ Treatment*Location, data=mangrove.sponge)
q4 <-  glht(mangrove.aov2, linfct = mcp(Treatment = contr))
summary(q4, p.adjust.methods="none")

q5 <- glht(mangrove.aov2, linfct=mcp(Treatment="Tukey"))
summary(q5, p.adjust.methods="none")

p.adjust(0.0033, method="bon", 15)

require(agricolae)
LSD.test,

HSD.test,

pairwise.t.test(mangrove.sponge$RootGrowthRate,
                mangrove.sponge$Treatment, "none")


## removing the two potential outliers
mangrove2 <- mangrove.sponge[-c(14, 39),]
mangrove.aov2 <- aov(RootGrowthRate ~ Treatment*Location, data=mangrove2)
q4 <-  glht(mangrove.aov2, linfct = mcp(Treatment = contr))
summary(q4, test=adjusted(type=c("none")))
pairwise.t.test(mangrove2$RootGrowthRate, mangrove2$Treatment, "none")

contr2 <- rbind(
                "S - F" = c(0, -1, 1/2, 1/2),
                "Trt - C" = c(-1, 1/3, 1/3, 1/3))
q6 <-  glht(mangrove.aov, linfct = mcp(Treatment = contr2))
summary(q6, test=adjusted(type="none"))

t.test(RootGrowthRate ~ Treatment, data=mangrove.sponge,
       subset= Treatment == "Foam"|Treatment=="Control", var.equal=T)

##

#> table(mangrove.sponge$Treatment)
#
#  Control      Foam Haliclona   Tedania
#       21        20        17        14

pooled.sd <- 0.462
contr.sd <- 0.462*sqrt(1/21+1/20)
delta <- 0.59150 - 0.23714

t.st <- delta/(contr.sd)

p.value <- 2*(1-pt(t.st, 20+21-2))

##########  linear regression  ###########
library(RODBC)
con <- odbcConnectExcel(paste(dataDIR, "chinook.xls", sep="/"))
#sqlTables(con)
chinook <- sqlFetch(con, "NEWCHINOOK")
odbcCloseAll() # close the connection

#con <- odbcConnectExcel(paste(dataDIR, "laketrout2.xls", sep="/"))
#sqlTables(con)
#laketrout <- sqlFetch(con, "LAKETROUT")
#odbcCloseAll() # close the connection

con <- odbcConnectExcel(paste(dataDIR, "newCrypto.xls", sep="/"))
#sqlTables(con)
crypto <- sqlFetch(con, "newCrypto")
odbcCloseAll() # close the connection

## PCB in fish

### 1, Lake trout
## 60 cm is a threshold,
##


laketrout <- laketrout[laketrout$pcb>exp(-2)&laketrout$length>0,]
lake.lm1 <- lm(log(pcb) ~ I(year-1974), data=laketrout)
display(lake.lm1, 4)

lm1.coef<-coef(lake.lm1)
postscript(paste(plotDIR, "PCBlm1Pred.eps", sep="/"),
           width=4, height=2.5, horizontal=F)
par(mar=c(3,3,0.25,0.25), mgp=c(1.5,.5,0))
plot(pcb ~ year, data=laketrout,
     ylab="PCB (mg/kg)", xlab="Year", cex=0.5, col=grey(0.5))
curve(exp( lm1.coef[1] + lm1.coef[2]*(x-1974) +0.87^2/2), add=T, lwd=2)
curve(qlnorm(0.025, lm1.coef[1] + lm1.coef[2]*(x-1974), 0.87 ), add=T, lty=2)
curve(qlnorm(0.975, lm1.coef[1] + lm1.coef[2]*(x-1974), 0.87 ), add=T, lty=2)
dev.off()

lake.lm2 <- lm(log(pcb) ~ length+I(year-1974), data=laketrout)
display(lake.lm2, 3)

lake.lm3 <- lm(log(pcb) ~ len.c+I(year-1974), data=laketrout)
display(lake.lm3, 3)
lm3.coef<-coef(lake.lm3)
postscript(file=paste(plotDIR, "PCBlm2Pred.eps", sep="/"),
           width=4, height=2.5, horizontal=F)
par(mar=c(3,3,0.25,0.25), mgp=c(1.5,.5,0))
plot(pcb ~ year, data=laketrout,
     ylab="PCB (mg/kg)", xlab="Year", cex=0.5, col=grey(0.5))
curve(exp( lm3.coef[1] + lm3.coef[2]*0 + lm3.coef[3]*(x-1974) +0.543^2/2),
      add=T, lwd=2)
curve(exp( lm3.coef[1] + lm3.coef[2]*(-2.6)+lm3.coef[3]*(x-1974) +0.543^2/2),
      add=T, lty=2, lwd=2)
curve(exp( lm3.coef[1] + lm3.coef[2]*(3.4) + lm3.coef[3]*(x-1974) +0.543^2/2),
      add=T, lty="13", lwd=2)
legend(x=1990, y=40, legend=c("large fish","average fish","small fish"),
       lty=c(3, 1, 2), lwd=rep(2, 3), cex=0.75, bty="n")
dev.off()

mn.length <- mean(laketrout$length, na.rm=T)
lake.lm6 <- lm(log(pcb) ~ len.c+I(year-1974), data=laketrout)
summary(lake.lm6)

lake.lm7 <- lm(log(pcb) ~ len.c*I(year-1974), data=laketrout)
display(lake.lm7, 4)

lake.lm8 <- lm(log(pcb) ~ I(year-1974)*len.c + I(len.c^2), data=laketrout)
display(lake.lm8, 4)

lake.lm9 <- lm(log(pcb) ~ I(year-1974) + len.c * factor(size), data=laketrout)
display(lake.lm9, 4)


lake.lm9 <- lm(log(pcb) ~ I(year-1974) + len.c * factor(size)-1-len.c,
               data=laketrout)
display(lake.lm9, 4)

lake.lm10 <- lm(log(pcb) ~ I(year-1974)*factor(size) + len.c * factor(size),
                data=laketrout)
display(lake.lm10, 4)

lake.lm11 <- lm(log(pcb) ~ len.c + factor(size), data=laketrout)
display(lake.lm11, 4)

lake.lm12 <- lm(log(pcb) ~ len.c * factor(size), data=laketrout)
display(lake.lm12, 4)

## plots
## data
##library(lattice)

postscript(file=paste(plotDIR, "PCByear.eps", sep="/"),
           height=3, width=4.5, horizontal=F, family="Times")
#pdf(file=paste(plotDIR, "PCByear.pdf", sep="/"), height=3, width=4.5)
xyplot(log(pcb)~year, data=laketrout,
    panel=function(x,y,...){
        panel.xyplot(x, y, ...)
        panel.lmline(x,y,...)}, subset=pcb>exp(-2)&length>0,
        xlab="Year",ylab="Log PCB")
dev.off()

postscript(file=paste(plotDIR, "PCBlength.eps", sep="/"),
           height=3, width=4.5, horizontal=F)
#pdf(file=paste(plotDIR, "PCBlength.pdf", sep="/"), height=3, width=4.5)
xyplot(log(pcb)~length, data=laketrout,
    panel=function(x,y,...){
        panel.xyplot(x, y, col=grey(0.5), ...)
        panel.lmline(x,y,...)
        panel.loess(x, y, span=3/4, lty=2, ...)}
        , subset=pcb>exp(-2)&length>0, xlab="Length (in)", ylab="Log PCB")
dev.off()

postscript(file=paste(plotDIR, "lengthYear.eps",sep="/"),
           height=3, width=4.5, horizontal=F)
xyplot(I(length)~year, data=laketrout, subset=pcb>exp(-2)&length>0,
       ylab="Length (cm)", xlab="Year")
dev.off()
## residuals

postscript(file=paste(plotDIR, "PCBresidQQN.eps", sep="/"),
           height=3, width=4.5, horizontal=F)
qqmath(~resid(lake.lm7),
            panel = function(x,...) {
              panel.grid()
              panel.qqmath(x,...)
              panel.qqmathline(x,...)
            }, ylab="Residuals", xlab="Standard Normal Quantile"
       )
dev.off()
## checking whether residuals are normally distributed

postscript(file=paste(plotDIR, "PCBresid2.eps", sep="/"),
           height=3, width=4.5, horizontal=F)
xyplot(resid(lake.lm7)~fitted(lake.lm7),
       panel=function(x,y,...){
         panel.grid()
         panel.xyplot(x, y, col=grey(0.5),cex=0.5, ...)
         panel.abline(0, 0, lty=2)
         panel.loess(x, y, span=1, ...)
       }, ylab="Residuals", xlab="Fitted")
dev.off()
## checking for patterns in residuals (independence)
postscript(file=paste(plotDIR, "PCBresid3.eps", sep="/"),
           height=3, width=4.5, horizontal=F)
xyplot(resid(lake.lm9)~fitted(lake.lm9),
       panel=function(x,y,...){
         panel.grid()
         panel.xyplot(x, y, col=grey(0.5),cex=0.5, ...)
         panel.abline(0, 0, lty=2)
         panel.loess(x, y, span=1, ...)
        }, ylab="Residuals", xlab="Fitted")
dev.off()


postscript(file=paste(pltoDIR,"PCBresidSL.eps", sep="/"),
           height=3, width=4.5, horizontal=F)
xyplot(sqrt(abs(resid(lake.lm7)))~fitted(lake.lm7),
       panel=function(x,y,...){
         panel.grid()
         panel.xyplot(x, y, col=grey(0.5), cex=0.5, ...)
         panel.loess(x, y, span=1,...)
       }, ylab="Sqrt. Abs. Residualt", xlab="Fitted")
## checking whether the residuals have a constant variance
dev.off()

postscript(file=paste(plotDIR, "PCBresidfitted.eps", sep="/"),
           height=3, width=4.5, horizontal=F)
xyplot(fitted(lake.lm7)~(fitted(lake.lm7)+resid(lake.lm7)),
       panel = function(x, y,...) {
         panel.xyplot(x, y, cex=0.5, ...)
         panel.abline(0,1, col="red",...)
         panel.loess(x,y, span=1.0,col="green",...)
         panel.grid()
       },ylab="Fitted",xlab="Observed")
## checking whether the predicted is in greement with the observed
dev.off()

postscript(file="PCBcook.eps", height=3, width=4.5, horizontal=F)
xyplot(cooks.distance(lake.lm7) ~ fitted(lake.lm7),
    panel=function(x,y,...){
      panel.xyplot(x,y,...)
      panel.grid()},
    ylab="Cook's Distance", xlab="Fitted")
## checking for influential data points
dev.off()

postscript(file="PCBdiag.eps", width=5, height=6, horizontal=F)
lm.plots(lake.lm7)
dev.off()

rfs(lake.lm1, aspect=1)

postscript(file="PCBrfs.eps", height=3, width=4.75, horizontal=F)
trellis.par.temp <- trellis.par.get()
trellis.par.temp$add.text$cex=0.75 ## change strip text font size
trellis.par.temp$par.xlab.text$cex=0.75 ## xlab font size
trellis.par.temp$par.ylab.text$cex=0.75
trellis.par.set(trellis.par.temp)
rfs(lake.lm7, aspect=1)
dev.off()

windows()
lm.plots(lake.lm1)
windows()

lm.plots(lake.lm7)

        lake.lm0 <- lm(pcb ~ I(year-1974) + len.c, data=laketrout)
        postscript(file="pcbBoxCox.eps", height=3, width=3.5, horizontal=F)
        par(mgp=c(1.5,0.5,0), mar=c(3,3,0.25,0.25), cex=0.75)
        boxcox(lake.lm0)
        dev.off()

require(alr3)
bctrans(pcb ~ year + length, data=laketrout)

## the meaning of interaction
postscript(file=paste(plotDIR, "interaction.eps", sep="/"), width=4.5, height=4, horizontal=F)
par(mar=c(4,4,0.25,0.25))
pred.lm1<-predict(lake.lm7,newdata=data.frame(year=1974:2000,len.c=rep(-2.6,2000-1974+1)),type="response")
pred.lm2<-predict(lake.lm7,newdata=data.frame(year=1974:2000,len.c=rep(0,2000-1974+1)),type="response")
pred.lm3<-predict(lake.lm7,newdata=data.frame(year=1974:2000,len.c=rep(9,2000-1974+1)),type="response")
pred.lm4<-predict(lake.lm1,newdata=data.frame(year=1974:2000),type="response")

plot(c(1974,2000),range((laketrout$pcb), na.rm=T),type="n", xlab="Year", ylab="PCB")
points(jitter(laketrout$year), laketrout$pcb, col="gray")
lines(1974:2000,exp(pred.lm1),col="green", lwd=2)
lines(1974:2000,exp(pred.lm2),col="red", lwd=2)
lines(1974:2000,exp(pred.lm3),col="blue", lwd=2)
lines(1974:2000,exp(pred.lm4),col="black", lwd=2)
dev.off()
##### idea for a manuscript: statistical report on the importance of interaction
#####      causal inference using data that were not sampled at random
#####        including covariates, interpretation, and other statistical issues.
#####

## simulations
n.sims<-1000
sim.results <- sim(lake.lm1, n.sims=1000)
predict.PCB07 <- exp(sim.results$beta[,1] +
                     sim.results$beta[,2]*(2007-1974) +
                     0.5* sim.results$sigma)

predict.PCB00 <- exp(sim.results$beta[,1] +
                     sim.results$beta[,2]*(2000-1974) +
                     0.5 * sim.results$sigma)
percentages <- 1-predict.PCB07/predict.PCB00
postscript(file="pcbreduction.eps", width=3, height=2.5, horizontal=F)
par(mar=c(4,3,1,0.5), mgp=c(1.5,0.5,0))
hist(percentages*100, xlab="Predicted % PCB reduction", ylab="", prob=T, main="")
dev.off()


sim.2 <- sim(lake.lm7, 1000)
predict2.PCB07 <- exp(sim.2$beta[,1] +
                      sim.2$beta[,3]*(2007-1974) +
                      0.5* sim.2$sigma)

predict2.PCB00 <- exp(sim.2$beta[,1] +
                      sim.2$beta[,3]*(2000-1974) +
                      0.5 * sim.2$sigma)
percentages2 <- 1-predict2.PCB07/predict2.PCB00
postscript(file="pcbreduction2.eps", width=3, height=2.5, horizontal=F)
par(mar=c(4,3,1,0.5), mgp=c(1.5,0.5,0))
hist(percentages2*100, xlab="Predicted % PCB reduction", ylab="", prob=T, main="")
dev.off()

#### Two Way ANOVA ####
attach(mangrove.sponge)
mangrove.sponge$Control <- as.numeric(Treatment=="Control")
mangrove.sponge$Foam <- as.numeric(Treatment=="Foam")
mangrove.sponge$PurpleS <- as.numeric(Treatment=="Haliclona")
mangrove.sponge$RedS <- as.numeric(Treatment=="Tedania")
detach()
mangrove.lmDM <- lm(RootGrowthRate ~ Foam+PurpleS+RedS, data=mangrove.sponge)
display(mangrove.lmDM, 4)

attach(mangrove.sponge)
mangrove.sponge$bbs <- as.numeric(Location=="bbs")
mangrove.sponge$etb <- as.numeric(Location=="etb")
mangrove.sponge$lcn <- as.numeric(Location=="lcn")
mangrove.sponge$lcs <- as.numeric(Location=="lcs")
detach()
mangrove.lmDM2 <- lm(RootGrowthRate ~ Foam+PurpleS+RedS +
                                      etb+lcn+lcs , data=mangrove.sponge)
display(mangrove.lmDM2, 4)

mangrove.lm2w <- lm(RootGrowthRate ~ Treatment+Location, data=mangrove.sponge)


#### cross-validation ####


B <- 500
pred.resid <- numeric()
pred.bias <- numeric()
for (i in 1:B){
    smpl <- unique(sample(dim(laketrout)[1], dim(laketrout)[1], replace=T))
    asmpl <- seq(1,dim(laketrout)[1])[-smpl]
    lm.temp <- lm(log(pcb) ~ I(year-1974) + len.c * factor(size), data=laketrout[smpl,])
    pred.temp <- predict(lm.temp, new=laketrout[asmpl,], type="response")
    pred.resid [i] <- sd(log(laketrout[asmpl,"pcb"]) - pred.temp)
    pred.bias[i] <- mean(log(laketrout[asmpl,"pcb"]) - pred.temp)
}

postscript("c:/users/song/teaching/env210/fall2007/notes/PCBxvalid.eps", width=4.5, height=2.5, horizontal=F)
par(mfrow=c(1,2), mar=c(3,1.5,0.25,0.25), mgp=c(1.5,.5,0))
hist(pred.bias, main="", xlab="Prediction Bias")
abline(v=0, col="red", lwd=3)
hist(pred.resid, main="", xlab="Prediction Standard Deviation")
abline(v=sd(lake.lm9$residuals), col="red", lwd=3)
dev.off()

## nonlinear regression

# the PCB in fish example

lake.lm7 <- lm(log(pcb) ~ len.c*I(year-1974), data=laketrout)
display(lake.lm7, 4)

#laketrout <- laketrout[!is.na(laketrout$length),]
#lake.nlm1 <- nls(lnpcb ~ beta0 + beta1*(year-1974) + beta2*len.c + delta*pmax(0, len.c-lth),
#start=list(beta0=1.6, beta1= - 0.08, beta2=0.07, delta=0.01, lth=0), data=laketrout, algorithm="port",
#na.action=na.omit)



#hockey <- function(x,alpha1,beta1,delta,brk,eps=diff(range(x))/100) {
#
#       ## alpha1 is the intercept of the left line segment
#       ## beta1 is the slope of the left line segment
#       ## beta2 is the slope of the right line segment
#       ## brk is location of the break point
#       ## 2*eps is the length of the connecting quadratic piece
#
#       ## reference: Bacon & Watts "Estimating the Transition Between
#       ## Two Intersecting Straight Lines", Biometrika, 1971
#
#        beta2 <- beta1 + delta
#        x1 <- brk-eps
#        x2 <- brk+eps
#        b <- (x2*beta1-x1*beta2)/(x2-x1)
#        cc <- (beta2-b)/(2*x2)
#        a <- alpha1+beta1*x1-b*x1-cc*x1^2
#        alpha2 <- - beta2*x2 +(a + b*x2 + cc*x2^2)
#
#        lebrk <- (x <= brk-eps)
#        gebrk <- (x >= brk+eps)
#        eqbrk <- (x > brk-eps & x < brk+eps)
#
#        result <- rep(0,length(x))
#        result[lebrk] <- alpha1 + beta1*x[lebrk]
#        result[eqbrk] <- a + b*x[eqbrk] + cc*x[eqbrk]^2
#        result[gebrk] <- alpha2 + beta2*x[gebrk]
#        result
#}


lake.nlm1 <- nls(log(pcb) ~  hockey(len.c, beta0, beta1, delta, theta),
start=list(beta0=1.6, beta1=0.07, delta=0.03, theta=0), data=laketrout,
na.action=na.omit)
summary(lake.nlm1)

lake.nlm1 <- nls(log(pcb) ~  hockey(length, beta0, beta1, delta, theta),
start=list(beta0=.6, beta1=0.07, delta=0.03, theta=60), data=laketrout,
na.action=na.omit)
summary(lake.nlm1)
lake1.coef<-coef(lake.nlm1)

lake1.sim <- sim.nls (lake.nlm1, 1000)
betas <- lake1.sim$beta

logPCB.mean  <- betas[,1] +
    (betas[,2] + betas[,3]*(60>betas[,4]))*(60-betas[,4])
pred.PCB<-exp(rnorm(1000, logPCB.mean, lake1.sim$sigma))
pred.log.95CI  <- quantile(log(pred.PCB), prob=c(0.025, 0.975))
theta <- quantile(lake1.sim$beta[,4], prob=c(0.025, 0.975))

postscript(paste(base, "lake1sim.eps", sep="/"), height=3.5, width=4.75, horizontal=F)
par(mar=c(3,3,1,1), mgp=c(1.5,.5,0))
plot(log(pcb)~length, data=laketrout, xlab="Length (cm)",ylab="log PCB", type="n")
for (i in 1:100)
curve(hockey(x, betas[i,1], betas[i,2], betas[i,3], betas[i,4]), col=grey(0.6) , add=T)
curve(hockey(x, lake1.coef[1], lake1.coef[2], lake1.coef[3], lake1.coef[4]),lwd=3, add=T)
points(laketrout$length, log(laketrout$pcb), col=grey(0.4), cex=0.5)
segments(x0=60, x1=60, y0=pred.log.95CI[1], y1=pred.log.95CI[2])
segments(y0=-1.5, y1=-1.5, x0=theta[1], x1=theta[2], col=grey(0.5))
dev.off()


hist(pred.PCB)


lake.nlm2 <- nls(log(pcb) ~  beta1*(year-1974) + hockey(length, beta0, beta2, delta, theta),
start=list(beta0=.6, beta1= - 0.08, beta2=0.07, delta=0.03, theta=60), data=laketrout,
na.action=na.omit)
summary(lake.nlm2)

lake2.coef<- coef(lake.nlm2)
postscript(paste(base, "lake2sim.eps", sep="/"), height=3.5, width=4.75, horizontal=F)
#pdf(paste(base, "lake2sim.pdf", sep="/"), height=3.5, width=4.75)
par(mar=c(3,3,1,1), mgp=c(1.5,.5,0))
plot(log(pcb)~length, data=laketrout, xlab="Length (cm)",ylab="log PCB", type="n")
curve(lake2.coef[2]*(0)+hockey(x, lake2.coef[1], lake2.coef[3], lake2.coef[4], lake2.coef[5]), col=1 , add=T)
points(laketrout$length[laketrout$year<1984], log(laketrout$pcb[laketrout$year<1984]), col=1, cex=0.5)
curve(lake2.coef[2]*(10)+hockey(x, lake2.coef[1], lake2.coef[3], lake2.coef[4], lake2.coef[5]), col=2 , add=T)
points(laketrout$length[laketrout$year>=1984&laketrout$year<1994],
       log(laketrout$pcb[laketrout$year>=1984&laketrout$year<1994]), col=2, cex=0.5)
curve(lake2.coef[2]*(20)+hockey(x, lake2.coef[1], lake2.coef[3], lake2.coef[4], lake2.coef[5]), col=3 , add=T)
points(laketrout$length[laketrout$year>=1994],
       log(laketrout$pcb[laketrout$year>=1994]), col=3, cex=0.5)
curve(lake2.coef[2]*(30)+hockey(x, lake2.coef[1], lake2.coef[3], lake2.coef[4], lake2.coef[5]), col=4 , add=T)
legend(x=30, y=3.5, col=1:4, legend=seq(1974,2004, 10), lty=1, cex=0.5)
dev.off()

postscript(paste(base, "lake2bw.eps", sep="/"), height=3.5, width=4.75, horizontal=F)
#pdf(paste(base, "lake2sim.pdf", sep="/"), height=3.5, width=4.75)
par(mar=c(3,3,1,1), mgp=c(1.5,.5,0))
plot(log(pcb)~length, data=laketrout, xlab="Length (cm)",ylab="log PCB", type="n")
curve(lake2.coef[2]*(0)+hockey(x, lake2.coef[1], lake2.coef[3], lake2.coef[4], lake2.coef[5]),
      col=1, lty=1, add=T, lwd=2)
points(laketrout$length[laketrout$year<1984], log(laketrout$pcb[laketrout$year<1984]),
      col=1, pch="1", cex=0.5)
curve(lake2.coef[2]*(10)+hockey(x, lake2.coef[1], lake2.coef[3], lake2.coef[4], lake2.coef[5]),
      col=grey(0.5), lty=2, add=T, lwd=2)
points(laketrout$length[laketrout$year>=1984&laketrout$year<1994],
       log(laketrout$pcb[laketrout$year>=1984&laketrout$year<1994]),
       col=grey(0.5), pch="2", cex=0.5)
curve(lake2.coef[2]*(20)+hockey(x, lake2.coef[1], lake2.coef[3], lake2.coef[4], lake2.coef[5]),
       col=1, lty=3, add=T, lwd=2)
points(laketrout$length[laketrout$year>=1994],
       log(laketrout$pcb[laketrout$year>=1994]),
       col=1, pch="3", cex=0.5)
curve(lake2.coef[2]*(30)+hockey(x, lake2.coef[1], lake2.coef[3], lake2.coef[4], lake2.coef[5]),
       col=1, lty=4, add=T, lwd=2)
legend(x=30, y=3.5, col=c(1, grey(0.5), 1, 1), legend=seq(1974,2004, 10), lty=1:4, pch=c(1:3, ""), cex=0.5)
dev.off()


### Stow et al 2004-- 4 alternative models
pcb.exp <- nls(log(pcb) ~ log(pcb0*exp(-k*(year-1974))), data=laketrout, start=list(pcb0=10, k=0.08))
nlm.coef <- coef(pcb.exp)

postscript(file="pcbnls1.eps", width=4.25, height=3, horizontal=F)
par(mar=c(3,3,1,1), mgp=c(1.5,0.5,0))
plot(pcb~year, data=laketrout, col="gray", xlab="Year", ylab="PCB (mg/kg)", cex=0.5)
curve(nlm.coef[1]*exp(-nlm.coef[2]*(x-1974)), lwd=2, add=T)
dev.off()

obj1 <- xyplot(fitted(pcb.exp)~(fitted(pcb.exp)+resid(pcb.exp)),
            panel = function(x, y,...) {
                panel.xyplot(x, y,...)
                panel.abline(0,1,col="gray",...)
                panel.loess(x,y, span=1.0,...)
                panel.grid()
            },ylab="Fitted",xlab="Observed")
## checking whether the predicted is in greement with the observed
postscript(file="pcbnlsDiag1.eps", height=3.5, width=4, horizontal=F)
obj1
dev.off()

obj2 <- qqmath(~resid(pcb.exp),
            panel = function(x,...) {
                panel.grid()
                panel.qqmath(x,...)
                panel.qqmathline(x,...)
            }, ylab="Residuals", xlab="Standard Normal Quantile",
#            scales=list(y=list(alternating=2)),
)
postscript(file="pcbnlsDiag2.eps", height=3.5, width=4, horizontal=F)
obj2
dev.off()
## checking whether residuals are normally distributed

obj3 <- xyplot(resid(pcb.exp)~fitted(pcb.exp), panel=function(x,y,...){
        panel.grid()
        panel.xyplot(x, y,...)
        panel.abline(0, 0)
        panel.loess(x, y, span=1, col="gray",...)
        }, ylab="Residuals", xlab="Fitted")
## checking for patterns in residuals (independence)
postscript(file="pcbnlsDiag3.eps", height=3.5, width=4, horizontal=F)
obj3
dev.off()

obj4 <- xyplot(sqrt(abs(resid(pcb.exp)))~fitted(pcb.exp), panel=function(x,y,...){
        panel.grid()
        panel.xyplot(x, y,...)
        panel.loess(x, y, span=1, col="gray",...)
        }, ylab="Sqrt. Abs. Residuals", xlab="Fitted"
#        scales=list(y=list(alternating=2)),
)
## checking whether the residuals have a constant variance
postscript(file="pcbnlsDiag4.eps", height=3.5, width=4, horizontal=F)
obj4
dev.off()

postscript(file="pcbnlsDiag.eps", height=5, width=5, horizontal=F)
    print(obj1, position = c(0.0, 0.0, 0.55, 0.55), more = T)
    print(obj2, position = c(0.45, 0.0, 1.0, 0.55), more = T)
    print(obj3, position = c(0.0, 0.45, 0.55, 1), more = T)
    print(obj4, position = c(0.45, 0.45, 1.0, 1), more = F)
dev.off()

postscript(file="pcbnlsDiag5.eps", height=3.5, width=4, horizontal=F)
hist(resid(pcb.exp), xlab="Residuals", main="", mgp=c(3,1.5,0))
dev.off()

## alternative 2
pcb.exp2 <- nls(log(pcb) ~ log(pcb0*exp(-k*(year-1974))+pcba), data=laketrout, start=list(pcb0=10, k=0.08, pcba=1))
nlm.coef2 <- coef(pcb.exp2)

## alternative 3
pcb.exp3 <- nls(log(pcb) ~ log(pcb01*exp(-k1*(year-1974))+pcb02*exp(-k2*(year-1974))),
                data=laketrout, start=list(pcb01=10, pcb02=2, k1=0.24, k2=0.00002),
                algorithm="port", lower = rep(0, 4))
nlm.coef3 <- coef(pcb.exp3)

## alternative 4
mixedorder <- function(x, b0, k, theta){
    LP1 <- LP2 <- 0
    if(theta==1){
        LP1 <- log(b0) - k*x
    } else {
        LP2 <- log(b0^(1-theta) - k*x*(1-theta))/(1-theta)
    }
    return( LP1 + LP2)
    }
pcb.exp4 <- nls(log(pcb) ~ mixedorder(x=year-1974, pcb0, k, phi), data=laketrout, start=list(pcb0=10, k=0.0024, phi=3.5))
nlm.coef4 <- coef(pcb.exp4)

postscript(file="pcbnls2.eps", width=4.25, height=3, horizontal=F)
par(mar=c(3,3,1,1), mgp=c(1.5,0.5,0))
plot(pcb~year, data=laketrout, col=grey(0.5), xlab="Year", ylab="PCB (mg/kg)", cex=0.5)
curve(nlm.coef [1]*exp(-nlm.coef[2]*(x-1974)), lwd=2, add=T, lty=1)
curve(nlm.coef2[1]*exp(-nlm.coef2[2]*(x-1974))+nlm.coef2[3], lwd=2, add=T, lty=2)
curve(nlm.coef3[1]*exp(-nlm.coef3[3]*(x-1974))+nlm.coef3[2]*exp(-nlm.coef3[4]*(x-1974)), lwd=2, add=T, lty=3)
curve((nlm.coef4[1]^(1-nlm.coef4[3]) - nlm.coef4[2]*(x-1974)*(1-nlm.coef4[3]))^(1/(1-nlm.coef4[3])), lwd=2, add=T, lty=4)
legend (x=1995, y=40, legend=1:4, lty=1:4, lwd=2, cex=0.5, bty="n")
dev.off()


exp1.sim <- sim.nls (pcb.exp, 1000)
betas <- exp1.sim$beta
pred.00<-betas[,1]*exp(-betas[,2]*(2000-1974))
pred.07<-betas[,1]*exp(-betas[,2]*(2007-1974))
percent1 <- 1-pred.07/pred.00
precent1 <- percent1[!is.na(percent1)]

exp2.sim <- sim.nls (pcb.exp2, 1000)
betas <- exp2.sim$beta
pred.00<-betas[,1]*exp(-betas[,2]*(2000-1974))+betas[,3]
pred.07<-betas[,1]*exp(-betas[,2]*(2007-1974))+betas[,3]
percent2 <- 1-pred.07/pred.00
precent2 <- percent2[!is.na(percent2)]

exp3.sim <- sim.nls (pcb.exp3, 1000)
betas <- exp3.sim$beta
pred.00<-betas[,1]*exp(-ifelse(betas[,3]<0, 0, betas[,3])*(2000-1974))+betas[,2]*exp(-ifelse(betas[,4]<0, 0, betas[,4])*(2000-1974))
pred.07<-betas[,1]*exp(-ifelse(betas[,3]<0, 0, betas[,3])*(2007-1974))+betas[,2]*exp(-ifelse(betas[,4]<0, 0, betas[,4])*(2007-1974))
percent3 <- 1-pred.07/pred.00
precent3 <- percent3[!is.na(percent3)]

mixedorder2 <- function(x, b0, k, theta){
    ifelse(theta==1, exp(log(b0) - k*x), exp(log(b0^(1-theta) - k*x*(1-theta))/(1-theta)))
    }

exp4.sim <- sim.nls (pcb.exp4, 1000)
betas <- exp4.sim$beta
pred.00<-mixedorder2 (2000, betas[,1], betas[,2], betas[,3])
pred.07<-mixedorder2 (2007, betas[,1], betas[,2], betas[,3])
percent4 <- 1-pred.07/pred.00
precent4 <- percent4[!is.nan(percent4)]

postscript(file="pcb00to07.eps", width=4, height=2.5, horizontal=F)
par(mar=c(3,3,1,1), mgp=c(1.5,0.5,0))
plot(y=c(1-0.25, 4+0.25), x=c(0,0.5)*100, type="n", xlab="% change, 2000 to 2007", ylab="Models", axes=F)
segments(y0=1:4, y1=1:4, x0=100*c(quantile(percent1, prob=0.025, na.rm=T), quantile(percent2, prob=0.025, na.rm=T),
                              quantile(percent3, prob=0.025, na.rm=T), quantile(percent4, prob=0.025, na.rm=T)),
                         x1=100*c(quantile(percent1, prob=0.975, na.rm=T), quantile(percent2, prob=0.975, na.rm=T),
                              quantile(percent3, prob=0.975, na.rm=T), quantile(percent4, prob=0.975, na.rm=T)))
segments(y0=1:4, y1=1:4, x0=100*c(quantile(percent1, prob=0.25, na.rm=T), quantile(percent2, prob=0.25, na.rm=T),
                              quantile(percent3, prob=0.25, na.rm=T), quantile(percent4, prob=0.25, na.rm=T)),
                         x1=100*c(quantile(percent1, prob=0.75, na.rm=T), quantile(percent2, prob=0.75, na.rm=T),
                              quantile(percent3, prob=0.75, na.rm=T), quantile(percent4, prob=0.75, na.rm=T)),
                         lwd=2.5)
points(y=1:4, x=100*c(quantile(percent1, prob=0.5, na.rm=T), quantile(percent2, prob=0.5, na.rm=T),
                              quantile(percent3, prob=0.5, na.rm=T), quantile(percent4, prob=0.5, na.rm=T)))
abline(v=25)
axis(1)
axis(2, at=1:4)
box()
dev.off()
## piecewise linear model
  beta1 <- 0.75
  beta2 <- 2.5
  eps <- 5
  alpha1 <- 2
        x1 <- -eps
        x2 <- +eps
        b <- (x2*beta1-x1*beta2)/(x2-x1)
        cc <- (beta2-b)/(2*x2)
        a <- alpha1+beta1*x1-b*x1-cc*x1^2
        alpha2 <- - beta2*x2 +(a + b*x2 + cc*x2^2)

postscript(file="hockeystick.eps", height=3.5, width=4, horizontal=F)
plot(y=c(2.5*(35-20)+2, 0.75*(5-20)+2), x=c(35, 5), type="n", xlab="x", ylab="y")
segments(x0=c(5, 25), x1=c(15, 35), y0=c(0.75*(5-20)+2, 2.5*(25-20)+2), y1=c(0.75*(15-20)+2, 2.5*(35-20)+2))
lines(seq(15,25,,100), a + b*(seq(15,25,,100)-20) + cc*(seq(15,25,,100)-20)^2)
points(x=c(15, 25), y=c(0.75*(15-20)+2, 2.5*(25-20)+2))
segments(x0=c(15, 25), x1=c(20, 20), y0=c(0.75*(15-20)+2, 2.5*(25-20)+2), y1=c(2, 2), lty=4)
dev.off()

#### Smoothing ####

postscript(file="smoother1.eps", width=3.5, height=3, horizontal=F)
par(mfrow=c(1,2), mar=c(3,3,1,1), mgp=c(1.5,0.5,0), las=1)
X<-sort(c(35, seq(30, 90, 5)))
Y<-numeric()
for (i in 1:length(X)){
    Y[i]=mean(log(laketrout$pcb[laketrout$length>X[i]-5 & laketrout$length<X[i]+5]), na.rm=T)
}
plot(log(pcb)~length,data=laketrout, type="n", xlab="Fish Length (cm)", ylab="Log PCB")
points(log(pcb)~length,data=laketrout, col="gray", cex=0.5)
polygon(x=c(40, 40, 50, 50), y=c(-2, 4, 4, -2), col="gray", border=NA)# abline(v=c(40, 50))
#abline(v=c(30, 60, 70, 80, 90), col="gray")
points(log(pcb)~length,data=laketrout, subset=length>40 & length < 50, cex=0.5)
#points(x=35, y=mean(log(laketrout$pcb[laketrout$length>30 & laketrout$length < 40]), na.rm=T), pch=16, cex=1.5, col=grey(0.5))
points(x=45, y=mean(log(laketrout$pcb[laketrout$length>40 & laketrout$length < 50]), na.rm=T), pch=16, cex=1.5)
lines(X, Y)
for (i in 1:length(X)){
    Y[i]=mean(log(laketrout$pcb[laketrout$length>X[i]-10 & laketrout$length<X[i]+10]), na.rm=T)
}
lines(X, Y, lty=5)
box()

plot(log(pcb)~length,data=laketrout, type="n", xlab="Fish Length (cm)", ylab="Log PCB")
points(log(pcb)~length,data=laketrout, col="gray", cex=0.5)
polygon(x=c(40, 40, 50, 50), y=c(-2, 4, 4, -2), col="gray", border=NA)# abline(v=c(40, 50))
for (i in 1:length(X)){
    Y[i]=mean(log(laketrout$pcb[laketrout$length>X[i]-10 & laketrout$length<X[i]+10]), na.rm=T)
}
dev.off()

## loess example

pcb.data <- laketrout[!is.na(laketrout$length)&laketrout$pcb>0,]
oo <- order(pcb.data$length)
pcb.data <- pcb.data[oo,]
## at length=60 the 255th number in length
## n = 646, the upper bound is 255+646*0.25 = 417 or 68.5cm
##
x.range <- c(60-9, 60+9)
pcb.subset <- pcb.data[170:291,]
local.lm <- lm(log(pcb) ~ length, data=pcb.subset)
pcb.loess <- loess.smooth (y=log(pcb.data$pcb), x=pcb.data$length, data=pcb.data, degree=1, span=0.5)

postscript(file="smoother2.eps", width=3.5, height=3, horizontal=F)
par(mar=c(3,3,1,1), mgp=c(1.5,0.5,0), las=1)
plot(log(pcb.data$pcb)~pcb.data$length, xlab="Fish Length (cm)", ylab="Log PCB", type="n")
points(log(pcb.data$pcb)~pcb.data$length, col=grey(0.5), cex=0.5)
polygon(x=x.range[c(1,1,2,2)], y=c(-2, 4, 4, -2), col="gray", border=NA)
lines(pcb.loess$y~pcb.loess$x, lwd=2)
curve(coef(local.lm)[1] + coef(local.lm)[2]*x, add=T, xlim=x.range)
abline(v=60)
points(log(pcb)~length,data=laketrout, subset=length>x.range[1] & length < x.range[2], cex=0.25, col=grey(0.3))
#points(x=35, y=mean(log(laketrout$pcb[laketrout$length>30 & laketrout$length < 40]), na.rm=T), pch=16, cex=1.5, col=grey(0.5))
points(x=60, y=predict(local.lm, new=data.frame(length=60)), pch=16, cex=1.25)
dev.off()

#######################
### additive models ###
#######################
postscript(file="lmgraph1.eps", height=2.25, width=4.5, horizontal=F)
par(mfrow=c(1,2), mgp=c(1.5,0.5,0), mar=c(3,3,1,1))
plot(c(0,2), c(-3, 1), type="l", xlab=expression(x[1]), ylab=expression(beta[0]+beta[1]*x[1]))
abline(h=seq(-3,1,0.1), v=seq(0,2,0.1), col="gray")
plot(c(0,4), c(0, -3), type="l", xlab=expression(x[2]), ylab=expression(beta[2]*x[2]))
abline(v=seq(0,4,0.1), h=seq(-3,0,0.1), col="gray")
dev.off()

postscript(file="lmgraph2.eps", height=2.25, width=4.5, horizontal=F)
par(mfrow=c(1,2), mgp=c(1.5,0.5,0), mar=c(3,3,1,1))
plot(c(0,2), c(-3, 1), type="l", xlab=expression(x[1]), ylab=expression(beta[0]+beta[1]*x[1]))
abline(h=seq(-3,1,0.1), v=seq(0,2,0.1), col="gray")
plot(log(seq(0.1,100,,100)), log(seq(0.1,100,,100)), type="l", xlab=expression(x[2]), ylab=expression(beta[2]*log(x[2])), axes=F)
axis(2)
axis(1, at=log(c(0.1,1,10,50,100)), labels=c("0.1","1","10","50","100"))
abline(v=log(c(seq(0.1,1,0.1), seq(1,10,1), seq(10,100,10))), h=seq(-3,6,0.25), col="gray")
box()
dev.off()

postscript(file="lmgraph3.eps", height=2.25, width=4.5, horizontal=F)
par(mfrow=c(1,2), mgp=c(1.5,0.5,0), mar=c(3,3,1,1))
plot(c(0,2), c(-3, 1), type="l", xlab=expression(x[1]), ylab=expression(beta[0]+beta[1]*x[1]))
abline(h=seq(-3,1,0.1), v=seq(0,2,0.1), col="gray")
plot((seq(0.1,100,,100)), log(seq(0.1,100,,100)), type="l", xlab=expression(x[2]), ylab=expression(beta[2]*log(x[2])), axes=F)
axis(2)
axis(1)
abline(v= seq(10,100,10), h=seq(-3,6,0.25), col="gray")
box()
dev.off()

## using PCB in fish
require(gam)
pcbGamlo <- gam(log(pcb) ~ lo(length, span=0.75, degree=1)+lo(year, span=0.75), data=laketrout)

 plot(pcbGamlo, se=T, rug=T, resid=F, scale=0, pch=1, cex=0.25)
 plot(pcbGamlo, select=2, se=T, rug=T, resid=F, scale=0, pch=1, cex=0.25,ylab="s(Year)", xlab="Year")
detach(package:gam)

require(mgcv)
pcbGam1 <- gam(log(pcb) ~ s(length)+s(year, fx=T, k=4), data=laketrout)
summary(pcbGam1)

 postscript("pcbGam1.eps", height=2.25, width=4.5, horizontal=F)
 par(mfrow=c(1,2), mar=c(3,3,1,0.5), mgp=c(1.5,0.5,0))
 plot(pcbGam1, select=1, se=T, rug=T, resid=F, scale=0, pch=1, cex=0.25,ylab="s(Length)", xlab="Length")
 plot(pcbGam1, select=2, se=T, rug=T, resid=F, scale=0, pch=1, cex=0.25,ylab="s(Year)", xlab="Year")
 dev.off()
detach(package:mgcv)

require(gam)
pcbGam2 <- gam(log(pcb)~s(length) + s(year), data=laketrout)
pcbGam3 <- gam(log(pcb)~s(length) + s(year, 8), data=laketrout)
pcbGam4 <- gam(log(pcb)~s(length) + s(year, 2), data=laketrout)

 postscript("pcbGam2.eps", height=2, width=5, horizontal=F)
 par(mfrow=c(1,3), mar=c(3,3,1,0.25), mgp=c(1.5,0.5,0))
 plot.gam(pcbGam4, se=T, rug=T, ask=T, ylab="s(year, df=2)", xlab="Year")
 plot.gam(pcbGam2, se=T, rug=T, ask=T, ylab="s(year, df=4)", xlab="Year")
 plot.gam(pcbGam3, se=T, rug=T, ask=T, ylab="s(year, df=8)", xlab="Year")
dev.off()

nadb <- read.csv(paste(dataDIR, "nadb.csv", sep="/"), header=T)
nadb$logPLI <- log10(nadb$PLI)
nadb$logTPIn<- log10(nadb$TPIn)
nadb$logTPOut<- log10(nadb$TPOut+1)
nadb$logHLR <- log10(nadb$HLR+1)
postscript(paste(plotDIR, "nadbGAM1.eps", sep="/"), height=5, width=5, horizontal=F)
par(mar=c(2,2,1,1))
pairs(nadb[,1:5])
dev.off()


postscript(paste(plotDIR, "nadbGAM2.eps", sep="/"), height=3.5, width=5.5, horizontal=F)
par(mgp=c(1.5,0.5,0), mar=c(3,3,1,1))
plot(TPOut ~ PLI, data=nadb, log="x", axes=F, xlab="Input TP Loading", ylab="Output TP Concentration")
axis(1, at = c(0.01, 0.1,1, 10, 100, 1000), labels=c("0.01","0.1","1","10","100","1000"))
axis(2)
box()
dev.off()

postscript(paste(plotDIR, "nadbGAM3.eps", sep="/"), height=3.5, width=5.5, horizontal=F)
par(mgp=c(1.5,0.5,0), mar=c(3,3,1,1))
plot(TPOut ~ PLI, data=nadb, log="xy", axes=F, xlab="Input TP Loading", ylab="Output TP Concentration")
axis(1, at = c(0.01, 0.1,1, 10, 100, 1000), labels=c("0.01","0.1","1","10","100","1000"))
axis(2)
box()
dev.off()

coplot(logTPOut ~ logTPIn|logHLR, data=nadb, given.v=co.intervals(nadb$logHLR, 4, 0.25), rows=1, panel=panel.smooth)
coplot(logTPOut ~ logHLR|logTPIn, data=nadb, given.v=co.intervals(nadb$logTPIn, 4, 0.25), rows=1, panel=panel.smooth)

require(mgcv)

nadbGam1 <- gam(logTPOut ~ s(logPLI)+s(logTPIn)+s(logHLR), data=nadb)
postscript(paste(plotDIR, "nadbGam4.eps", sep="/"), height=2, width=5, horizontal=F)
par(mfrow=c(1,3), mar=c(3,3,0.5,0.25), mgp=c(1.5,0.5,0))
plot(nadbGam1, select=1, se=T, rug=T, resid=T, scale=0, pch=16, cex=0.25)
plot(nadbGam1, select=2, se=T, rug=T, resid=T, scale=0, pch=16, cex=0.25)
plot(nadbGam1, select=3, se=T, rug=T, resid=T, scale=0, pch=16, cex=0.25)
dev.off()


nadbGam1.5 <- gam(logTPOut ~ s(logPLI, fx=T, k=4)+s(logTPIn, fx=T, k=4)+s(logHLR, fx=T, k=4), data=nadb)
summary(nadbGam1.5)

postscript(paste(plotDIR, "nadbGam4_5.eps", sep="/"), height=2, width=5, horizontal=F)
par(mfrow=c(1,3), mar=c(3,3,0.5,0.25), mgp=c(1.5,0.5,0))
plot(nadbGam1.5, select=1, se=T, rug=T, resid=T, scale=0, pch=16, cex=0.25)
plot(nadbGam1.5, select=2, se=T, rug=T, resid=T, scale=0, pch=16, cex=0.25)
plot(nadbGam1.5, select=3, se=T, rug=T, resid=T, scale=0, pch=16, cex=0.25)
dev.off()


#postscript(paste(plotDIR, "nadbGam4.eps", sep="/"), height=3, width=5, horizontal=F)
par(mfrow=c(1,2), mar=c(3,3,1,1), mgp=c(1.5,0.5,0), pty="s")
plot(nadbGam1.5, select=1, se=T, rug=T, resid=T, scale=0, pch=1)
plot(nadbGam1.5, select=2, se=T, rug=T, resid=T, scale=0, pch=1)
dev.off()

nadbGam2 <- gam(log(TPOut) ~ s(log(PLI))+s(log(TPIn)), data=nadb, subset=TPOut>0)

par(mfrow=c(1,2), mar=c(3,3,1,1), mgp=c(1.5,0.5,0))
plot(nadbGam2, select=1, se=T, rug=T, resid=T)
plot(nadbGam2, select=2, se=T, rug=T, resid=T)

nadbGam3 <- gam(logTPOut ~ s(var1=logTPIn, var2=logHLR), data=nadb)
summary(nadbGam3)

postscript(paste(plotDIR, "nadbGam5.eps", sep="/"), height=3.5, width=3.5, horizontal=F)
par(mar=c(4,4,3,1), pty="s")
plot(nadbGam3, select=1, resid=T, mgp=c(1.5,0.5,0), pch=1, cex=0.5, se=F)
dev.off()
postscript(paste(plotDIR, "nadbGam6.eps", sep="/"), height=3.5, width=3.5, horizontal=F)
par(mar=c(0.5,0.5,0.5,0.5), pty="s")
plot(nadbGam3, select=1, rug=T, resid=T, pers=T)
dev.off()

nadbGam4 <- gam(logTPOut ~ s(logPLI), data=nadb)
summary(nadbGam4)


postscript(paste(plotDIR, "nadbGam7.eps", sep="/"), height=2.5, width=3, horizontal=F)
par(mar=c(4,4,1,1))
plot(nadbGam4, select=1, resid=T, mgp=c(1.5,0.5,0), pch=1, cex=0.5, se=T)
dev.off()

#### CART -- using USGS pesticides data from Anderson et al 1996

## Diuron -- 49300: R.62 & P49300
postscript(file="diuronQplot.eps", width=4, height=4.5, horizontal=F)
par(mgp=c(1.5,0.5,0))
plot(((1:94)-0.5)/94, sort(willamette.data$P49300), log="y", xlab="Quantile",
    ylab=expression(paste("Diuron ","(",mu, "g/L)", sep="")))
abline(h=c(0.83, 7.08), lty=2)
text(x=c(0.2,0.2), y=c(1.15, 9), c("0.83","7.08"))
dev.off()

postscript(file="diurondata.eps", width=5, height=3.5, horizontal=F)
dotplot(Month ~ jitter(log(P49300)) | Class, data=willamette.data, xlab="Log Diuron")
dev.off()

require(rpart)

## regression model
diuron.rpart <- rpart(log(P49300) ~ NH4+NO2+TKN+N2.3+TOTP+SRP+BOD+ECOL+FECAL+wtemp+bpres+flow+cond+pH+SSC+SSF+
    Longitude+Latitude+Size+LU.Ag+LU.For+LU.Resid+LU.Other+NumCrops+Month, data=willamette.data)
 plot(diuron.rpart, margin=0.1)
 text(diuron.rpart, pretty=T, use.n=T)


## a note on the differences

set.seed(12345)
diuron.rpart <- rpart(log(P49300) ~ NH4+NO2+TKN+N2.3+TOTP+SRP+BOD+ECOL+FECAL+
#    wtemp+bpres+flow+cond+pH+SSC+SSF+
    Longitude+Latitude+Size+LU.Ag+LU.For+LU.Resid+LU.Other+NumCrops+Month,
    data=willamette.data, control=rpart.control(minsplit=4,cp=0.005))
postscript(file="diuronCART1.eps", height=7, width=5, horizontal=F)
 plot(diuron.rpart, margin=0.1)
 text(diuron.rpart, cex=0.5)
dev.off()

 printcp (diuron.rpart)
# summary(diuron.rpart)
postscript(file="diuronCARTcp.eps", width=5, height=3.75, horizontal=F)
par(mgp=c(1.5, 0.5, 0))

plotcp(diuron.rpart)
dev.off()

diuron.rpart.prune <- prune(diuron.rpart, cp=0.05)
postscript(file=paste(base, "diuronCARTprune.eps", sep="/"), height=8, width=6, horizontal=F)
nf <- layout(matrix(c(1,2), nrow=2, ncol=1), 1, c(2,1))
# layout.show(nf)
par(mar=c(0,4,1,2))
plot(diuron.rpart.prune, compress=F, branch=0.4, margin=0.1)
text(diuron.rpart.prune, pretty=T, cex=0.55, use.n=T)
title(main="log diuron Concentration")
par(mar=c(0.5,4,0.5,2))
boxplot(split(predict(diuron.rpart.prune)+resid(diuron.rpart.prune),
    round(predict(diuron.rpart.prune), digits=4)),
        ylab="Diuron Concentrations",
        xlab=" ", axes=F, ylim=log(c(0.01, 50)))
axis(2, at=log(c(0.01, 0.1, 1, 10, 50)), labels=c("0.01","0.1","1","10","50"), las=1)
box()
dev.off()

diuron.rpart.prune2 <- prune(diuron.rpart, cp=0.08)
postscript(file=paste(base, "diuronCARTprune2.eps", sep="/"), height=8, width=6, horizontal=F)
nf <- layout(matrix(c(1,2), nrow=2, ncol=1), 1, c(2,1))
# layout.show(nf)
par(mar=c(0,4,1,2))
plot(diuron.rpart.prune2, compress=F, branch=0.4, margin=0.1)
text(diuron.rpart.prune2, pretty=T, cex=0.55, use.n=T)
title(main="log diuron Concentration")
par(mar=c(0.5,4,0.5,2))
boxplot(split(predict(diuron.rpart.prune2)+resid(diuron.rpart.prune2),
    round(predict(diuron.rpart.prune2), digits=4)),
        ylab="Diuron Concentrations",
        xlab=" ", axes=F, ylim=log(c(0.01, 50)))
axis(2, at=log(c(0.01, 0.1, 1, 10, 50)), labels=c("0.01","0.1","1","10","50"), las=1)
box()
dev.off()



## classification model


set.seed(12345)
diuron.rpart2 <- rpart(Diuron ~ NH4+NO2+TKN+N2.3+TOTP+SRP+BOD+ECOL+FECAL+
#    wtemp+bpres+flow+cond+pH+SSC+SSF+
    Longitude+Latitude+Size+LU.Ag+LU.For+LU.Resid+LU.Other+NumCrops+Month,
    data=willamette.data, method="class", parms=list(prior=rep(1/4, 4), split="information"),
    control=rpart.control(minsplit=4,cp=0.005))

postscript(file="diuronCART2.eps", height=7, width=5, horizontal=F)
plot(diuron.rpart2, margin=0.1)
text(diuron.rpart2, cex=0.55)
dev.off()
#title(main="log diuron Concentration")

postscript(file="diuronCART2cp.eps", width=5, height=3.75, horizontal=F)
par(mgp=c(1.5, 0.5, 0))
plotcp(diuron.rpart2)
dev.off()
### the above is the version used in Qian and Anderson (1999)

## dsicuss the use of prior, the use of different split method, and other issues
## design a series of possible models

# 1. using default ## infor and data frequencies
set.seed(123456)
diuron.rpart3 <- rpart(Diuron ~ NH4+NO2+TKN+N2.3+TOTP+SRP+BOD+ECOL+FECAL+
#    wtemp+bpres+flow+cond+pH+SSC+SSF+
    Longitude+Latitude+Size+LU.Ag+LU.For+LU.Resid+LU.Other+NumCrops+Month,
    data=willamette.data, method="class",
    control=rpart.control(minsplit=4,cp=0.000001))#, parms=list(prior=rep(1/4, 4), split="gini"))
plotcp(diuron.rpart3)
diuron.rpart3.prune <- prune(diuron.rpart3, cp=0.06)
 plot(diuron.rpart3.prune, margin=0.1)
 text(diuron.rpart3.prune, pretty=T, use.n=T)
# 2. default -- changing split method to gini:  gini and data frequencies
set.seed(123456)
diuron.rpart4 <- rpart(Diuron ~ NH4+NO2+TKN+N2.3+TOTP+SRP+BOD+ECOL+FECAL+
#    wtemp+bpres+flow+cond+pH+SSC+SSF+
    Longitude+Latitude+Size+LU.Ag+LU.For+LU.Resid+LU.Other+NumCrops+Month,
    data=willamette.data, method="class",
    control=rpart.control(minsplit=4,cp=0.000001), parms=list(split="gini"))
plotcp(diuron.rpart4)
printcp(diuron.rpart4)
diuron.rpart4.prune <- prune(diuron.rpart4, cp=0.06)
 plot(diuron.rpart4.prune, margin=0.1)
 text(diuron.rpart4.prune, pretty=T, use.n=T)

# use equal prior and gini:
set.seed(123456)
diuron.rpart5 <- rpart(Diuron ~ NH4+NO2+TKN+N2.3+TOTP+SRP+BOD+ECOL+FECAL+
#    wtemp+bpres+flow+cond+pH+SSC+SSF+
    Longitude+Latitude+Size+LU.Ag+LU.For+LU.Resid+LU.Other+NumCrops+Month,
    data=willamette.data, method="class",
    control=rpart.control(minsplit=4,cp=0.000001), parms=list(prior=rep(1/4, 4), split="gini"))
plotcp(diuron.rpart5)
printcp(diuron.rpart5)
diuron.rpart5.prune <- prune(diuron.rpart5, cp=0.05)
 plot(diuron.rpart5.prune, margin=0.1)
 text(diuron.rpart5.prune, pretty=T, use.n=T)

## used first
diuron.rpart2.prune <- prune(diuron.rpart2, cp=0.06)
postscript(file="diuronCART2prune.eps", width=6, height=6, horizontal=F)
par(mar=c(0,4,1,2))
plot(diuron.rpart2.prune, compress=F, branch=0.4, margin=0.1)
text(diuron.rpart2.prune, pretty=T, cex=0.55, use.n=T)
title(main="Diuron Concentration Level")
dev.off()

postscript(file="diuron4models.eps", height=5, width=5, horizontal=F)
par(mar=c(0,4,1,2), mfrow=c(2,2))
plot(diuron.rpart2.prune, compress=F, branch=0.4, margin=0.1)
text(diuron.rpart2.prune, pretty=T, cex=0.55, use.n=T)
title(main="Equal Prior & Infor", cex=0.75)

plot(diuron.rpart3.prune, compress=F, branch=0.4, margin=0.1)
text(diuron.rpart3.prune, pretty=T, cex=0.55, use.n=T)
title(main="Data Prior & Infor", cex=0.75)

plot(diuron.rpart5.prune, compress=F, branch=0.4, margin=0.1)
text(diuron.rpart5.prune, pretty=T, cex=0.55, use.n=T)
title(main="Equal Prior & Gini", cex=0.75)

plot(diuron.rpart4.prune, compress=F, branch=0.4, margin=0.1)
text(diuron.rpart4.prune, pretty=T, cex=0.55, use.n=T)
title(main="Data Prior & Gini", cex=0.75)

dev.off()

### plotting options
postscript(file=paste(base, "diuronPlots1.eps", sep="/"), height=4, width=4, horizontal=F)
# layout.show(nf)
par(mar=c(1,2,2,1))#, mfrow=c(2,2))
plot(diuron.rpart5.prune,margin=0.1,
    main="a. default")
text(diuron.rpart5.prune, cex=0.75)
dev.off()

postscript(file=paste(base, "diuronPlots2.eps", sep="/"), height=4, width=4, horizontal=F)
plot(diuron.rpart5.prune,uniform=T,branch=0.25,
margin=0.1, main="b. uniform with branching")
text(diuron.rpart5.prune,pretty=1,use.n=T, cex=0.75)
dev.off()

postscript(file=paste(base, "diuronPlots3.eps", sep="/"), height=6, width=5, horizontal=F)
plot(diuron.rpart5.prune,uniform=T,branch=0.,
    margin=0.1,main="c. fancy")
text(diuron.rpart5.prune,pretty=1,
    all=T,use.n=T,fancy=T, cex=0.7, fwidth=0.4, fheight=0.8)
dev.off()


#### Poisson regression
## Arsenic in drinking water
As.m1 <- glm(events ~ conc, data=arsenic, family="poisson")
display(As.m1, 4)

As.m2 <- glm(events ~ log(conc+1), data=arsenic, family="poisson")
display(As.m2, 4)

As.m3 <- glm(events ~ conc + gender+type, data=arsenic, family="poisson")
display(As.m3, 4)

trellis.device(postscript, file="Ascancer1.eps", height=4, width=4, horizontal=F)
trellis.par.temp <- trellis.par.get()
trellis.par.temp$add.text$cex=0.5 ## change strip text font size
trellis.par.temp$par.xlab.text$cex=0.5 ## xlab font size
trellis.par.temp$par.ylab.text$cex=0.5
xyplot(events~conc|Type*Gender, xlab="As Concentration (ppb)", ylab="Cancer Deaths", data=arsenic, par.settings=trellis.par.temp)
dev.off()

trellis.device(postscript, file="Ascancer2.eps", height=4, width=4, horizontal=F)
trellis.par.temp <- trellis.par.get()
trellis.par.temp$add.text$cex=0.5 ## change strip text font size
trellis.par.temp$par.xlab.text$cex=0.5 ## xlab font size
trellis.par.temp$par.ylab.text$cex=0.5
xyplot(log(events+1)~log(conc+1)|Type*Gender, xlab="Log As Concentration (ppb)", ylab="Log Cancer Deaths", data=arsenic, par.settings=trellis.par.temp)
dev.off()

trellis.device(postscript, file="Ascancer3.eps", height=4, width=4, horizontal=F)
trellis.par.temp <- trellis.par.get()
trellis.par.temp$add.text$cex=0.5 ## change strip text font size
trellis.par.temp$par.xlab.text$cex=0.5 ## xlab font size
trellis.par.temp$par.ylab.text$cex=0.5
xyplot(log(at.risk)~log(conc+1)|Type*Gender, xlab="Log As Concentration (ppb)", ylab="Log At Risk", data=arsenic, par.settings=trellis.par.temp)
dev.off()

trellis.device(postscript, file="Ascancer4.eps", height=4, width=4, horizontal=F)
trellis.par.temp <- trellis.par.get()
trellis.par.temp$add.text$cex=0.5 ## change strip text font size
trellis.par.temp$par.xlab.text$cex=0.5 ## xlab font size
trellis.par.temp$par.ylab.text$cex=0.5
xyplot((events/at.risk)~log(conc+1)|Type*Gender, xlab="Log As Concentration (ppb)", ylab="Cancer Deaths/At Risk", data=arsenic, par.settings=trellis.par.temp)
dev.off()

As.m4 <- glm(events ~ log(conc+1) + gender + type, data=arsenic, offset=log(at.risk/100000), family="poisson")
display(As.m4, 4)

pred.bush <- predict(As.m4, newdata=data.frame(conc=c(rep(10,4), rep(50,4)), gender=rep(c(0,0,1,1), 2), type=rep(c(0,1), 4), at.risk=rep(100000, 8)),
    type="response")
data.frame(effect=pred.bush, conc=c(rep(10,4), rep(50,4)), gender=rep(c(0,0,1,1), 2), type=rep(c(0,1), 4), at.risk=rep(1, 8))

 matrix(pred.bush[1:4], 2, 2)
 matrix(pred.bush[5:8], 2, 2)

### overdispersion

As.yhat <- predict(As.m4, type="response")
As.z <- (arsenic$events - As.yhat)/sqrt(As.yhat)
overD <- sum(As.z^2)/summary(As.m4)$df[2]
p.value <- 1-pchisq(sum(As.z^2), summary(As.m4)$df[2])

postscript(file="Asm4OverD.eps", width=5, height=3, horizontal=F)
par(mfrow=c(1,2), mar=c(3,3,3,0.25), mgp=c(1.5,0.5,0))
plot(As.yhat, arsenic$events - As.yhat, xlab="Predicted Values", ylab="Residuals", main="Raw Residuals")
plot(As.yhat, As.z, xlab="Predicted Values", ylab="Residuals", main="Standardized Residuals")
abline(h=c(-2,2), lty=2)
dev.off()

As.m5 <- glm(events ~ log(conc+1) + gender + type, data=arsenic,
             offset=log(at.risk), family="quasipoisson")
display(As.m5, 4)

require(MASS)
As.m5nb <- glm.nb(events ~ log(conc+1) + gender + type+offset(log(at.risk)),
             data=arsenic)
summary(As.m5nb)

As.m5.5 <- glm(events ~ conc + gender + type, data=arsenic, offset=log(at.risk), family="quasipoisson")
display(As.m5.5, 4)

As.m6 <- glm(events ~ log(conc+1) * gender  * type, data=arsenic, offset=log(at.risk), family="poisson")
display(As.m6, 4)

As.m6nb<- glm.nb(events~log(conc+1)*gender*type+offset(log(at.risk)),
                 data=arsenic)

As.m7 <- update(As.m6, .~. -log(conc+1):gender:type)
display(As.m7)

As.m7nb <- update(As.m6nb, .~.-log(conc+1):gender:type)
summary(As.m7nb)

As.m8 <- update(As.m7, .~., family="quasipoisson")
display(As.m8, 4)

As.m9 <- update(As.m8, .~.-gender:type)
display(As.m9, 4)

m9.coef <- coef(As.m9)
#        (Intercept)        log(conc + 1)               gender
#          -10.526475             0.469123             0.585474
#                type log(conc + 1):gender   log(conc + 1):type
#            1.478854            -0.101225            -0.187271

postscript(file="AsModel9.eps", width=4, height=3, horizontal=F)
par(mgp=c(1.5,0.5,0), mar=c(3,3,1,0.5))
with(arsenic, {
plot(log(conc+1), 100000*events/at.risk, axes=F,ylim=c(0,90),type="n",
     xlab="As concentration (ppb)", ylab="Cancer Deaths per 100,000")
axis(1, at=log(c(0, 10, 50, 100, 500, 1000)+1), label=c("0","10","50","100","500","1000"))
axis(2)
box()
curve(100000*exp(m9.coef[1]+m9.coef[2]*x), add=T, lty=1)       ##female, baldder
curve(100000*exp(m9.coef[1]+m9.coef[2]*x+m9.coef[3]+m9.coef[5]*x), add=T, lty=2) ## male bladder
curve(100000*exp(m9.coef[1]+m9.coef[2]*x+m9.coef[4]+m9.coef[6]*x), add=T, lty=3) ## female lung
curve(100000*exp(m9.coef[1]+m9.coef[2]*x+m9.coef[3]+m9.coef[4]+m9.coef[5]*x+m9.coef[6]*x), add=T, lty=4) ## male lung
abline(v=log(c(10,50)+1), col="gray", lwd=2)
legend(x=0, y=80, legend=c("female/bladder","male/bladder","female/lung","male/lung"), lty=1:4, cex=0.5)
})
dev.off()

As.pred <- predict(As.m9, type="response")

arsenic$age.c1 <- arsenic$age - mean(arsenic$age)
As.m10<-update(As.m9, .~.+age.c1*gender+age.c1:type)
display(As.m10, 4)

### not used
arsenic$age.c2<-arsenic$age/mean(arsenic$age)
As.m11<-update(As.m9, .~.+log(age.c2)*gender+log(age.c2):type)
display(As.m11, 4)

xyplot(log((events+1)/at.risk)~log(age)|type*gender, data=arsenic)

range(arsenic$age.c1)

pred.data <- data.frame(conc=rep(seq(0, 1000, 10), 4),
                        type=rep(rep(c(0,1), each=101), 2),
                        gender=rep(c(0,1), each=202))
pred.age1 <- predict(As.m10, newdata=data.frame(pred.data, age.c1= rep(-15, 404),
                                                at.risk=rep(100000, 404)), type="response")
pred.age2 <- predict(As.m10, newdata=data.frame(pred.data, age.c1= rep(0  , 404),
                                                at.risk=rep(100000, 404)), type="response")
pred.age3 <- predict(As.m10, newdata=data.frame(pred.data, age.c1= rep( 15, 404),
                                                at.risk=rep(100000, 404)), type="response")
plot.data1 <- data.frame(events=c(pred.age1, pred.age2, pred.age3),
                         rbind(pred.data, pred.data, pred.data),
                         age=rep(c(-15+52.5, 52.5, 52.5+15), each=404))
plot.data1$Type <- "Lung Cancer"
plot.data1$Type[plot.data1$type==0] <- "Bladder Cancer"
plot.data1$Gender <- "Male"
plot.data1$Gender[plot.data1$gender==0] <- "Female"

trellis.device(postscript, file="AsModel10.eps", width=4.5, height=5, horizontal=F)
trellis.par.set(theme = canonical.theme("postscript", col=FALSE))
trellis.par.set(list(fontsize=list(text=8),
                 par.xlab.text=list(cex=1.25),
                     add.text=list(cex=1.25),
                     superpose.symbol=list(cex=1)))
key <- simpleKey(unique(as.character(plot.data1$age)), lines=T, points=F, space = "top", columns=3)
key$text$cex <- 1.25
xyplot(events~log(conc+1)|Type*Gender, data=plot.data1, type="l",
    group=plot.data1$age, key=key, xlab="As concentration (ppb)", ylab="Cancer deaths per 100,000",
    panel=function(x,y,...){
        panel.xyplot(x,y,lwd=1.5,...)
#        panel.abline(v=log(c(10,50)+1), col="gray")
        panel.grid()
    },
    scales=list(x=list(at=log(c(0, 10, 50, 100, 500, 1000)+1), labels=as.character(c(0, 10, 50, 100, 500, 1000))))
    )
dev.off()
As.yhat <- predict(As.m10, type="response")
As.z <- (arsenic$events - As.yhat)/sqrt(As.yhat)
overD <- sum(As.z^2)/summary(As.m10)$df[2]
p.value <- 1-pchisq(sum(As.z^2), summary(As.m10)$df[2])

postscript(file="Asm10OverD.eps", width=5, height=3, horizontal=F)
par(mfrow=c(1,2), mar=c(3,3,3,0.25), mgp=c(1.5,0.5,0))
plot(As.yhat, arsenic$events - As.yhat, xlab="Predicted Values", ylab="Residuals", main="Raw Residuals")
plot(As.yhat, As.z, xlab="Predicted Values", ylab="Residuals", main="Standardized Residuals")
abline(h=c(-2,2), lty=2)
dev.off()

### logit v poisson

HabDen <- function(beta0, beta1, omega, n.sims = 5000, x=seq(0,5,,100)){
  if (omega > 1){
    a <- 1/(omega-1) *exp(beta0 + beta1*x)
    b <- 1/(omega-1)
    lambda <- rgamma(100, a, b)
  } else if (omega==1) {
    lambda <- exp(beta0 + beta1*x)
  } else stop("omega < 1")
  y <- rpois(100,lambda)

## density modeling:
  if(omega>1) denM <- glm(y~x, family=quasipoisson)
  else denM <- glm(y~x, family=poisson)
  display(denM)

## habitat modeling:
  y.hab <- as.numeric(y>0)
  habM <- glm(y.hab ~ x, family=quasibinomial(link="logit"))
  display(habM)

### simulation

  dimX <- length(x)

## density model
  denM.sim <- sim(denM, n.sims)
  betas <- denM.sim$beta
  overD <- denM.sim$sigma^2

  a.sim <- lambda.sim <- y.sim <- probNull.sim <- matrix(0, nrow=n.sims, ncol=dimX)
  b.sim <- 1/(overD-1)
  for (i in 1:dimX){
    if(omega>1){
      a.sim[,i] <- exp(betas[,1] + betas[,2]*x[i])/(overD-1)
      lambda.sim[,i] <- rgamma(n.sims, a.sim[,i], b.sim)
    } else {
      lambda.sim[,i] <- exp(betas[,1] + betas[,2]*x[i])
    }
    probNull.sim[,i] <- exp(-lambda.sim[,i])
#    y.sim[,i] <- rpois(n.sims, lambda.sim[,i])
  }

#y.sim.sum <- apply(y.sim,2,FUN=function(x)return(c(mean(x), quantile(x, prob=c(0.025, 0.25, 0.5,0.75,0.975)))))
  lambda.sum <- apply(lambda.sim,2,FUN=function(x)return(c(mean(x), quantile(x, prob=c(0.025, 0.25, 0.5,0.75,0.975)))))

## Habitat model
  habM.sim <- sim(habM, n.sims)
  betas <- habM.sim$beta
  prob.Hab <- matrix(0, ncol=dimX, nrow=n.sims)
  for (i in 1:dimX){
    prob.Hab[, i] <- invlogit(betas[,1] + betas[,2]*x[i])
  }

  prob.Den.sum <- apply(probNull.sim, 2, FUN=function(x)return(c(mean(1-x), quantile(1-x, prob=c(0.025, 0.25, 0.5,0.75,0.975)))))
  prob.Hab.sum <- apply(prob.Hab, 2, FUN=function(x)return(c(mean(x), quantile(x, prob=c(0.025, 0.25, 0.5,0.75,0.975)))))

## from hab to den

  hab2den.lambda <- -log(1-prob.Hab)
  hab2den.sum <- apply(hab2den.lambda, 2, FUN=function(x)return(c(mean(x), quantile(x, prob=c(0.025, 0.25, 0.5,0.75,0.975)))))
  return(list(x=x, y=y, H2D.sum = hab2den.sum, D2D.sum = lambda.sum))
}


sim.data <- function(data, scen, int = 0.2, slp = 0.12){
  M.p <- glm(data$y~data$x, family="quasipoisson")
  M.b <- glm(I(data$y>0)~data$x, family="binomial")
  plot(data$x, data$y, xlab="x", ylab="counts", type="n")
  curve(exp(coef(M.p)[1]+coef(M.p)[2]*x), add=T)
  curve(-log(1-invlogit(coef(M.b)[1]+coef(M.b)[2]*x)), add=T, lty=2)
  print(predict(M.p, type="response")/(-log(1-predict(M.b, type="response"))))
  curve(exp(int[1]+slp*x), add=T, col="red")
  points(data$x,data$y, cex=0.5)
  plot(data$x,jitter.binary(data$y>0), cex=0.5, xlab="x", ylab="presence (1)/absence (0)")
  curve(1-exp(-exp(coef(M.p)[1]+coef(M.p)[2]*x)), add=T)
  curve(invlogit(coef(M.b)[1]+coef(M.b)[2]*x), add=T, lty=2)
  text(x=0, y=0.5, paste("scenario", scen), cex=0.5)
  invisible()
}

sim.plots <- function(int = 0.2, slp = 0.12, ovD = 2.1, sims=5000, pred=seq(0,5,,100), fig.name=NULL){
  ##simulation
  scenario <- HabDen(beta0=int, beta1=slp, omega=ovD, n.sims=sims, x=pred)
  ##plots
  if (!is.null(fig.name)) postscript(file=fig.name, height=3.5, width=5, horizontal=F)
  plot(scenario$x, scenario$y, ylim=range(c(scenario$y, as.vector(scenario$hab2den.sum))), xlab="x", ylab="y", type="n")
  polygon(x=c(scenario$x,rev(scenario$x)), y=c(scenario$D2D.sum[2,], rev(scenario$D2D.sum[6,])), col=grey(0.8), border=F)
  polygon(x=c(scenario$x,rev(scenario$x)), y=c(scenario$D2D.sum[3,], rev(scenario$D2D.sum[5,])), col=grey(0.7), border=F)
  polygon(x=c(scenario$x,rev(scenario$x)), y=c(scenario$H2D.sum[2,], rev(scenario$H2D.sum[6,])), col=grey(0.5))
  lines(scenario$x, exp(int+slp*scenario$x), col="white")
  points(scenario$x,scenario$y, cex=0.5)
  if (!is.null(fig.name)) dev.off()
  invisible(list(x=scenario$x, y=scenario$y))
}

## scenario 1

scen1.data <- sim.plots (int = 0.2, slp = 0.12, ovD = 2.1, sims=5000, pred=seq(0,5,,100))#, fig.name="logitVpois1.eps")
scen2.data <- sim.plots (int = 0.2, slp = 1.20, ovD = 2.1, sims=5000, pred=seq(0,5,,100), fig.name="logitVpois2.eps")
scen3.data <- sim.plots (int = 0.2, slp = 1.20, ovD = 2.1, sims=5000, pred=seq(0,5,,100), fig.name="logitVpois3.eps")
scen4.data <- sim.plots (int = 0.2, slp = 1.20, ovD = 1.0, sims=5000, pred=seq(0,5,,100), fig.name="logitVpois4.eps")

par(mfrow=c(1,3))
scen1.data <- sim.plots (int = 0., slp = 0.12, ovD = 2.1, sims=5000, pred=seq(0,10,,100))#, fig.name="logitVpois1.eps")
sim.data(scen1.data, scen=1)

sim.data(int = 0.2, slp = 0.12, ovD = 1, x=seq(0,5,,100), scen=2)
sim.data(int = 0.2, slp = 1.2, ovD = 2.1, x=seq(0,5,,100), scen=3)
sim.data(int = 0.2, slp = 1.2, ovD = 1, x=seq(0,5,,100), scen=4)

## simulation
## residual

postscript(file=paste(plotDIR, "residsim.eps", sep="/"), height=2, width=3, horizontal=F)
par(mgp=c(1.2,0.5,0), tck=-0.02, mar=c(3,3,1,1), las=1)
curve(dnorm(x, 0, 0.25), from=-2.5, to=2.5, lty=2, xlab="", ylab="")
curve(dnorm(x,0,1), from=-2.5, to=2.5, add=T)
box()
abline(v=0.5, col="gray", lwd=2)
dev.off()

## Bayesian p-value
#laketrout <- laketrout[laketrout$pcb>exp(-2)&laketrout$length>0,]
#lake.lm1 <- lm(log(pcb) ~ I(year-1974), data=laketrout)
#display(lake.lm1, 4)

require(rv)
setnsims(5000)
lake1.sim <- postsim(lake.lm1)

pred.lake1 <- rvnorm(1, lake1.sim[2]+lake1.sim[3]*((1974:2000) - 1974), lake1.sim[1])

B.pvalue <- list()
for (i in 1974:2000){
 B.pvalue[[i-1973]] <- Pr(pred.lake1[i-1973] >= log(laketrout$pcb[laketrout$year==i]))
}


postscript(paste(plotDIR, "lakesimBPhist.eps", sep="/"),
    height=2.25, width=3, horizontal=F)
par(mgp=c(1.25,0.5,0), tck= -0.02, mar=c(3,3,1,1), las=1)
hist(unlist(B.pvalue), xlab="Tail Area", ylab="", main="")
dev.off()

postscript(paste(plotDIR, "lakesimBPbox.eps", sep="/"), height=2.5, width=4, horizontal=F)
par(mgp=c(1.5,0.5,0), tck= -0.02, mar=c(3,3,1,1), las=1)
boxplot(B.pvalue, names=1974:2000, xlab="Year", ylab="Tail Area")
dev.off()

pred.lake2 <- rvnorm(1, lake1.sim[2]+lake1.sim[3]*(na.omit(laketrout$year) - 1974), lake1.sim[1])

postscript(paste(plotDIR, "lakesimStats.eps", sep="/"), width=4.25, height=4., horizontal=F)
par(mfrow=c(2,2), mar=c(3,3,3,1), mgp=c(1.5,0.5,0), tck= -0.02)
rvhist(quantile(pred.lake2, prob=0.95), xlab="95th percentile", ylab="Frequency", breaks=15,
    main=paste("Tail area: ", round(Pr(quantile(pred.lake2, prob=0.95)>quantile(log(laketrout$pcb), prob=0.95, na.rm=T)), 2)))
abline(v=quantile(log(laketrout$pcb), prob=0.95, na.rm=T), lwd=2)

rvhist(quantile(pred.lake2, prob=0.05), xlab="5th percentile", ylab="Frequancy", breaks=15,
    main=paste("Tail area: ", round(Pr(quantile(pred.lake2, prob=0.05)>quantile(log(laketrout$pcb), prob=0.05, na.rm=T)), 2)))
abline(v=quantile(log(laketrout$pcb), prob=0.05, na.rm=T), lwd=2)

rvhist(mean(pred.lake2), xlab="Mean", ylab="Frequency", breaks=15,
    main=paste("Tail area: ", round(Pr(mean(pred.lake2)>mean(log(laketrout$pcb), na.rm=T)), 2)))
abline(v=mean(log(laketrout$pcb), na.rm=T), lwd=2)

rvhist(median(pred.lake2), xlab="Median", ylab="Frequency", breaks=15,
    main=paste("Tail area: ", round(Pr(median(pred.lake2)>median(log(laketrout$pcb), na.rm=T)), 2)))
abline(v=median(log(laketrout$pcb), na.rm=T), lwd=2)
dev.off()
########################


sparrow <- read.table(paste(dataDIR, "sparrow.txt", sep="/"), header=T)

postscript(file=paste(plotDIR, "cssparrow1.eps", sep="/"), height=2.5, width=3, horizontal=F)
par(mar=c(3,3,1,1), mgp=c(1.5,0.5,0), tck=-0.02)
plot(as.vector(by(sparrow$Bird.Count, sparrow$year, mean)), axes=F, xlab="Year", ylab="Average Bird Counts")
axis(1, at=2:14,labels=sort(unique(sparrow$year))[-1])
axis(2)
box()
dev.off()

spar.glm1 <- glm(Bird.Count ~ factor(year), data=sparrow, family=poisson)
display(spar.glm1)

y <- sparrow$Bird.Count
n <- dim(sparrow)[1]
y.rep <- rpois(n, fitted(spar.glm1))
print(mean(y == 0)) #(0.6929774)
print(mean(y.rep==0)) #(0.5089959)


y.mean <- mean(sparrow$Bird.Count==0)
y.rep.mean <- numeric()
n <- dim(sparrow)[1]
n.sims<-5000
for (i in 1:n.sims){
    y.rep <- rpois(n, predict(spar.glm1,type="response"))
    y.rep.mean [i] <- mean(y.rep==0)
}
postscript(file=paste(plotDIR, "cssparrow2.eps", sep="/"), height=2.25, width=3, horizontal=F)
par(mar=c(3,3,1,1), mgp=c(1.5,0.5,0), tck=-0.02)
hist(y.rep.mean*100, xlab="% zeroes",
    xlim=100*range(c(y.rep.mean, y.mean)),
    main="")
abline(v=y.mean*100, lwd=2, col="gray")
dev.off()


print(mean(sparrow$Bird.Count==0))
print(mean(y.rep==0))



spar.glm2 <- glm(Bird.Count ~ factor(year), data=sparrow, family=quasipoisson)
display(spar.glm2)

for (i in 1:n.sims){
    y.rep <- rpois(n, exp(predict(spar.glm2)))
    y.rep.mean [i] <- mean(y.rep==0)
}
postscript(file=paste(plotDIR, "sparrow3.eps", sep="/"), height=4, width=5.5, horizontal=F)
hist(y.rep.mean*100, xlab="% zeroes",
    xlim=100*range(c(y.rep.mean, y.mean)),
    main="")
abline(v=y.mean*100)
dev.off()

sparrow.sims <- sim (spar.glm1, n.sims)
y.rep.reg <- numeric()
    for (i in 1:n.sims){
    yr <- sample(1:14, size=1000, replace=T)
    mu <- sparrow.sims$beta[i, yr]
    y.rep.reg[i] <-
        mean(rpois(1000, exp(mu))==0)
}

postscript(file=paste(plotDIR, "sparrow3.eps", sep="/"), height=4, width=5.5, horizontal=F)
hist(y.rep.reg*100, xlab="% zeroes",
    xlim=100*range(c(y.rep.reg, y.mean)),
    main="")
abline(v=y.mean*100, col=2)
dev.off()

### multilevel (see c:/users/song/usgs/whymultilevel.r ###

## seaweed grazers
seaweed <- read.csv(paste(dataDIR, "seaweed.csv", sep="/"), header=T)

#seaweed
#   COVER   BLOCK   TREAT

## eda --


postscript(file=paste(plotDIR, "seaweedEDA.eps", sep="/"), height=4, width=5.5, horizontal=F)
par(mfrow=c(1,2), mar=c(3,3,0.5,0.25), mgp=c(1.5,0.5,0), tck=-0.02)
plot.design(seaweed)
boxplot(COVER~TREAT, data=seaweed)
dev.off()

slplot <- function(y, x, Xlab=NULL, Ylab=NULL){
    oo <- !is.na(y) & !is.na(x)
    y<-y[oo]
    x <- x[oo]
    mads.ref <- factor(x)
    oneway.output <- oneway(y ~ factor(x), location=mean, spread=1)
    obj <- xyplot(sqrt(abs(residuals(oneway.output)))~jitter(fitted.values(oneway.output), factor=.5),
        aspect=0.75,
        panel=function(x,y){
            panel.xyplot(x,y)
            srmads <- sqrt(tapply(abs(residuals(oneway.output)),
                mads.ref, median))
            oo <- order(oneway.output$location)
            panel.lines(oneway.output$location[oo],srmads[oo])
        },
        xlab=Xlab,
        ylab=Ylab)
    return(obj)
}

with (seaweed, obj1 <- slplot(COVER, TREAT, "Treatment", "% Recover"))
with (seaweed, obj2 <- slplot(log(COVER), TREAT, "Treatment", "Log Recover"))
with (seaweed, obj3 <- slplot(logit(COVER), TREAT, "Treatment", "Logit Recover"))
with (seaweed, obj4 <- slplot(1/COVER, TREAT, "Treatment", "Inverse Recover"))
postscript(file=paste(plotDIR, "seaweedSLs.eps", sep="/"), height=4, width=5.5, horizontal=F)
print(obj1, position=c(0,0,0.5,0.55), more=T)
print(obj2, position=c(0.5,0,1,0.55), more=T)
print(obj3, position=c(0,0.45,0.5,1), more=T)
print(obj4, position=c(0.5,0.45,1,1), more=F)
dev.off()

seaweed$y <- logit(seaweed$COVER/100)
names(seaweed)[2:3] <- c("Block","Treatment")
seaweed.lm <- lm(y ~ factor(Treatment)-1, data=seaweed)
summary(seaweed.lm)
seaweed.aov <- aov(y ~ Treatment, data=seaweed)
summary(seaweed.aov)
postscript(paste(plotDIR, "seaweedResd.eps", sep="/"), height=4, width=5, horizontal=F)
par(mfrow=c(2,2), tck=-0.02, mgp=c(1.5,.5,0), mar=c(3,3,4,0.25))
 plot(seaweed.aov)
dev.off()


require(arm)
seaweed.lmer <- lmer(y ~ 1+(1|Treatment), data=seaweed)
summary(seaweed.lmer)
ranef(seaweed.lmer)
se.ranef(seaweed.lmer)

line.plots <- function(est, se, Ylabel, Xlab, yaxis=2){
    n <- length(est)
    if(n != length(se))stop("lengths not match")
    plot(1:n, 1:n, xlim=range(c(est+2*se, est-2*se)), ylim=c(0.75, n+0.25), type="n", axes=F, xlab=Xlab, ylab="")
    axis(1)
    axis(yaxis, at=1:n, labels=Ylabel, las=1)
    segments(y0=1:n, y1=1:n, x0=est-2*se, x1=est+2*se)
    segments(y0=1:n, y1=1:n, x0=est-1*se, x1=est+1*se, lwd=2.5)
    points(est, 1:n)
    abline(v=0, col="gray")
    invisible()
}

line.plots.compare <- function(est1, se1, est2, se2, Ylabel, Xlab, yaxis=2, V=NULL){
    n <- length(est1)
    if(n != length(se1) | n !=length(se2) | n != length(est2) )stop("lengths not match")
    plot(1:n, 1:n, xlim=range(c(est1+2*se1, est1-2*se1, est2+2*se2, est2-2*se2)), ylim=c(0.75, n+0.25), type="n", axes=F, xlab=Xlab, ylab="")
    axis(1)
    axis(yaxis, at=1:n, labels=Ylabel, las=1)
    segments(y0=(1:n)-0.125, y1=(1:n)-0.125, x0=est1-2*se1, x1=est1+2*se1)
    segments(y0=(1:n)-0.125, y1=(1:n)-0.125, x0=est1-1*se1, x1=est1+1*se1, lwd=2.5)
    points(est1, (1:n)-0.125, pch=16, cex=0.5)

    segments(y0=(1:n)+0.125, y1=(1:n)+0.125, x0=est2-2*se2, x1=est2+2*se2, col="gray")
    segments(y0=(1:n)+0.125, y1=(1:n)+0.125, x0=est2-1*se2, x1=est2+1*se2, lwd=2.5, col="gray")
    points(est2, (1:n)+0.125, cex=0.5, col="gray")
    if(is.null(V))
        abline(v=0, col="gray")
    else abline(v=V, col="gray")
    invisible()
}


lmer1.int<-as.data.frame(cbind(ranef(seaweed.lmer)[[1]][,1]+fixef(seaweed.lmer)[1],
                               se.ranef(seaweed.lmer)[[1]][,1]))


ls2.int<-as.data.frame(summary(seaweed.aov)$coef[, 1:2])
postscript(file=paste(plotDIR, "seaweed1.eps", sep="/"), width=3, height=2.5, horizontal=F)
par(mar=c(4,5,0.5, 0.75), mgp=c(1.25,0.25,0), tck=-0.02)
line.plots.compare(ls2.int[,1], ls2.int[,2],
                   lmer1.int[,1], lmer1.int[,2],
                   levels(seaweed$Treatment), "Treatment effects",
                   V=fixef(seaweed.lmer)[[1]][1])
dev.off()

seaweed.lmer2 <- lmer(y ~ 1+(1|Treatment)+(1|Block), data=seaweed)
summary(seaweed.lmer2)

ranef(seaweed.lmer2)

seaweed.aov2 <- lm(y~Treatment+Block, data=seaweed)
summary(seaweed.aov2)

sims.M2 <- mcmcsamp(seaweed.lmer2, n=10000, saveb=T)
hist(apply(sims.M2@ranef[1:8, ], 2, sd))


block.mcmc <- sims.M2@ranef[1:8, 5001:10000]
treat.mcmc <- sims.M2@ranef[9:14,5001:10000]

sigma.block <- apply(block.mcmc, 2, sd)
sigma.treat <- apply(treat.mcmc, 2, sd)
sigma <- sims.M2@sigma[5001:10000]

s.sum <- rbind(
               quantile(sigma, prob=c(0.025,0.25,0.5,0.75,0.975)),
               quantile(sigma.treat, prob=c(0.025,0.25,0.5,0.75,0.975)),
               quantile(sigma.block, prob=c(0.025,0.25,0.5,0.75,0.975)))
postscript(file=paste(plotDIR, "seaweedAOV2.eps", sep="/"), width=3.5, height=2.75, horizontal=F)
par(mar=c(3.5, 7, 0.25,0.25), mgp=c(1.5,0.5,0), tck=-0.02)
plot(c(0,1), c(0.75,3.25), xlim=range(s.sum), type="n",
     xlab="standard deviation", ylab="", axes=F)
abline(h=0, col="gray")
segments(x0=s.sum[,1], x1=s.sum[,5], y0=1:3, y1=1:3)
segments(x0=s.sum[,2], x1=s.sum[,4], y0=1:3, y1=1:3, lwd=3)
axis(1)
axis(2, at=1:3, labels=c("Residuals","Treatment","Block"), las=1)
points(x=s.sum[,3], y=1:3, pch=16, cex=1.25)
dev.off()

seaweed.aov3 <- lm(y~Treatment*Block, data=seaweed)

seaweed.lmer3 <- lmer(y~1 + (1|Treatment)+(1|Block)+(1|Treatment:Block), data=seaweed)

sims.M3 <- mcmcsamp(seaweed.lmer3, n=10000, saveb=T)


## 1:48 -- interaction
## 49:56 -- block
## 57:62 -- treatment

## ranef
ranef.int <- sims.M3@ranef[1:48,5001:10000]
ranef.blk <- sims.M3@ranef[48:56,5001:10000]
ranef.trt <- sims.M3@ranef[57:62,5001:10000]

sigma.int <- apply(ranef.int, 2, sd)
sigma.blk <- apply(ranef.blk, 2, sd)
sigma.trt <- apply(ranef.trt, 2, sd)
sigma <- sims.M3@sigma[5001:10000]

s.sum <- rbind(
               quantile(sigma, prob=c(0.025,0.25,0.5,0.75,0.975)),
               quantile(sigma.int, prob=c(0.025,0.25,0.5,0.75,0.975)),
               quantile(sigma.trt, prob=c(0.025,0.25,0.5,0.75,0.975)),
               quantile(sigma.blk, prob=c(0.025,0.25,0.5,0.75,0.975)))
postscript(file=paste(plotDIR, "seaweedAOV3.eps", sep="/"), width=3.5, height=2.75, horizontal=F)
par(mar=c(3.5, 7, 0.25,0.25), mgp=c(1.5,0.5,0), tck=-0.02)
plot(c(0,1), c(0.75,4.25), xlim=range(s.sum), type="n",
     xlab="standard deviation", ylab="", axes=F)
abline(h=0, col="gray")
segments(x0=s.sum[,1], x1=s.sum[,5], y0=1:4, y1=1:4)
segments(x0=s.sum[,2], x1=s.sum[,4], y0=1:4, y1=1:4, lwd=3)
axis(1)
axis(2, at=1:4, labels=c("Residuals","Interaction","Treatment","Block"), las=1)
points(x=s.sum[,3], y=1:4, pch=16, cex=1.25)
dev.off()

sigma.int.plot <- list()
sigma.int.plot$summary <- t(apply(ranef.int, 1, FUN=function(x){
    return(c(mean(x), sd(x), quantile(x, prob=c(0.025,0.25,0.5,0.75,0.975))))
}))

postscript(file=paste(plotDIR, "seaweedInt.eps", sep="/"), width=5, height=3.5, horizontal=F)
par(mgp=c(1.5,0.5,0), tck=-0.02)
summary.plot.Interaction(sigma.int.plot, rows=1:48,
                         treatment = levels(seaweed$Treatment),
                         block=1:8)
dev.off()
summary.plot.Interaction<-
function(bugs.out=bugs.out.S, rows, ylab = NULL, xlab=" ",
         treatment, block, reverse=F, ymar=7, ...){
##
## Graphical presentation of interaction effect from bugs output
## 'bugs.out' is generated by function 'bugs' from linrary(R2WinBUGS)
##
    Plot.data <- bugs.out$summary[rows,]
    plotting.region <- range(Plot.data[,c(3,7)])
#    treatment  <- levels(seaweed$TREAT)
    nt <- length(treatment)
#    block <- paste("Block", 1:8)
    nb <- length(block)
    if(reverse){
    par(mfrow=c(1, nt), oma=c(0.5,ymar,1,1), mar=c(5, 0, 0, 0))
    for (i in 1:nt){
    plot(seq(plotting.region[1], plotting.region[2],,5),
         seq(1-0.1, nb+.1, ,5), type="n",
         xlab=treatment[i], ylab=" ", axes=F, ...)
    axis(1)
    if (i==1)
        axis(2, at=1:nb, labels=block, las=1, outer=T, ...)
    segments(x0=Plot.data[((i-1)*nb+1):(i*nb),3],
             x1=Plot.data[((i-1)*nb+1):(i*nb),7], y0=1:nb, y1=1:nb)
    segments(x0=Plot.data[((i-1)*nb+1):(i*nb),4],
             x1=Plot.data[((i-1)*nb+1):(i*nb),6], y0=1:nb, y1=1:nb, lwd=3)
    abline(v=0, col="gray")
    points(Plot.data[((i-1)*nb+1):(i*nb),1], 1:nb, cex=0.75)
    }
    } else {
    par(mfrow=c(1, nb), oma=c(5,7,4,4), mar=c(3.5, 0, 0, 0))
    for (i in 1:nb){
    plot(seq(plotting.region[1], plotting.region[2],,5),
         seq(1-0.1, nt+.1, ,5), type="n",
        xlab=block[i], ylab=" ", axes=F)
    axis(1)
    if (i==1)
        axis(2, at=1:nt, labels=treatment, las=1, outer=T)
    segments(x0=Plot.data[seq(i,nt*nb,nb),3],
             x1=Plot.data[seq(i,nt*nb,nb),7], y0=1:nt, y1=1:nt)
    segments(x0=Plot.data[seq(i,nt*nb,nb),4],
             x1=Plot.data[seq(i,nt*nb,nb),6], y0=1:nt, y1=1:nt, lwd=3)
    abline(v=0, col="gray")
    points(Plot.data[seq(i,nt*nb,nb),1], 1:nt, cex=0.75)
    }
    }
    mtext("Interaction Effects", side=1, outer=T, line=-.5)
    invisible()
}


seaweed.lmer4 <- lmer(COVER ~ 1 + (1|Treatment)+(1|Block)+(1|Treatment:Block), data=seaweed)

sims.M3 <- mcmcsamp(seaweed.lmer4, n=10000, saveb=T)


## 1:48 -- interaction
## 49:56 -- block
## 57:62 -- treatment

## ranef
ranef.int <- sims.M3@ranef[1:48,5001:10000]
ranef.blk <- sims.M3@ranef[48:56,5001:10000]
ranef.trt <- sims.M3@ranef[57:62,5001:10000]

sigma.int <- apply(ranef.int, 2, sd)
sigma.blk <- apply(ranef.blk, 2, sd)
sigma.trt <- apply(ranef.trt, 2, sd)
sigma <- sims.M3@sigma[5001:10000]

s.sum <- rbind(
               quantile(sigma, prob=c(0.025,0.25,0.5,0.75,0.975)),
               quantile(sigma.int, prob=c(0.025,0.25,0.5,0.75,0.975)),
               quantile(sigma.trt, prob=c(0.025,0.25,0.5,0.75,0.975)),
               quantile(sigma.blk, prob=c(0.025,0.25,0.5,0.75,0.975)))
postscript(file=paste(plotDIR, "seaweedAOV4.eps", sep="/"), width=3.5, height=2.75, horizontal=F)
par(mar=c(3.5, 7, 0.25,0.25), mgp=c(1.5,0.5,0), tck=-0.02)
plot(c(0,1), c(0.75,4.25), xlim=range(s.sum), type="n",
     xlab="standard deviation", ylab="", axes=F)
abline(h=0, col="gray")
segments(x0=s.sum[,1], x1=s.sum[,5], y0=1:4, y1=1:4)
segments(x0=s.sum[,2], x1=s.sum[,4], y0=1:4, y1=1:4, lwd=3)
axis(1)
axis(2, at=1:4, labels=c("Residuals","Interaction","Treatment","Block"), las=1)
points(x=s.sum[,3], y=1:4, pch=16, cex=1.25)
dev.off()

sigma.int.plot <- list()
sigma.int.plot$summary <- t(apply(ranef.int, 1, FUN=function(x){
    return(c(mean(x), sd(x), quantile(x, prob=c(0.025,0.25,0.5,0.75,0.975))))
}))

postscript(file=paste(plotDIR, "seaweedInt2.eps", sep="/"), width=5, height=3.5, horizontal=F)
par(mgp=c(1.5,0.5,0), tck=-0.02)
summary.plot.Interaction(sigma.int.plot, rows=1:48,
                         treatment = levels(seaweed$Treatment),
                         block=1:8)
dev.off()

### The Finnish Lakes example in Chapter 10 Multilevel Regression###
#dataDIR <- "c:/users/Oldfiles/Finn/updating/Data"

summer.All <- read.table(paste(dataDIR, "summerAll.csv", sep="/"), sep=",",header=T)

#names(summer.All)
# [1] "totp"  "chla"  "type"  "lake"  "year"  "totn"  "month" "depth" "surfa"
#[10] "color"

summer.All <- summer.All[log(summer.All$chla) > -20 ,]
#> names(summer.All)
# [1] "totp"  "chla"  "type"  "lake"  "year"  "totn"  "month" "depth" "surfa"
#[10] "color"

summer.All$y <- log(summer.All$chla)
summer.All$lxp<- scale(log(summer.All$totp), scale=F)
summer.All$lxn<- scale(log(summer.All$totn), scale=F)
summer.All$type.lake <- paste(summer.All$type, summer.All$lake)
## lmer
Finn.M1 <- lmer(y ~ lxp + lxn + (1|type), data=summer.All)
ranef(Finn.M1)

Finn.M2 <- lmer(y ~ lxp + lxn + (1+lxp + lxn|type), data=summer.All)

Finn.M3 <- lmer(y ~ lxp+lxn+lxp:lxn+(1+lxp+lxn+lxp:lxn|type), data=summer.All)
summary(Finn.M3)

ranef(Finn.M3)$type
se.ranef(Finn.M3)$type

fixef(Finn.M3)
se.fixef(Finn.M3)

est <- t(fixef(Finn.M3) + t(as.matrix(ranef(Finn.M3)$type)))
se <- sqrt(t(se.fixef(Finn.M3)^2+t(as.matrix(se.ranef(Finn.M3)$type))^2))

line.plots <- function(est, se, Ylabel, Xlab, yaxis=NULL, hline=0, oo=NULL){
    n <- length(est)
    if (!is.null(oo)) {
        est<-est[oo]
        se <-se[oo]
    }
    if(n != length(se))stop("lengths not match")
    plot(1:n, 1:n, xlim=range(c(est+2*se, est-2*se)), ylim=c(0.75, n+0.25),
         type="n", axes=F, xlab=Xlab, ylab="")
    axis(1)
    if (!is.null(yaxis))
      axis(yaxis, at=1:n, labels=Ylabel, las=1)
    segments(y0=1:n, y1=1:n, x0=est-2*se, x1=est+2*se)
    segments(y0=1:n, y1=1:n, x0=est-1*se, x1=est+1*se, lwd=2.5)
    points(est, 1:n)
    abline(v=hline, col="gray")
    invisible()
}

line.plots.compare <- function(est1, se1, est2, se2, Ylabel, Xlab, yaxis=2){
    n <- length(est1)
    if(n != length(se1) | n !=length(se2) | n != length(est2) )stop("lengths not match")
    plot(1:n, 1:n, xlim=range(c(est1+se1, est1-se1, est2+se2, est2-se2)), ylim=c(0.75, n+0.25), type="n", axes=F, xlab=Xlab, ylab="")
    axis(1)
    axis(yaxis, at=1:n, labels=Ylabel, las=1)
#    segments(y0=(1:n)-0.125, y1=(1:n)-0.125, x0=est1-2*se1, x1=est1+2*se1)
    segments(y0=(1:n)-0.125, y1=(1:n)-0.125, x0=est1-1*se1, x1=est1+1*se1, lwd=2)
    points(est1, (1:n)-0.125, pch=16, cex=0.5)

#    segments(y0=(1:n)+0.125, y1=(1:n)+0.125, x0=est2-2*se2, x1=est2+2*se2, lty=2)
    segments(y0=(1:n)+0.125, y1=(1:n)+0.125, x0=est2-1*se2, x1=est2+1*se2, lwd=2, col="gray")
    points(est2, (1:n)+0.125, cex=0.5, col="gray")

    abline(v=0, col="gray")
    invisible()
}

postscript(file=paste(plotDIR, "finnmultcoef.eps", sep="/"),
           width=4.5, height=3, horizontal=F)
par(mfrow=c(1,4), mgp=c(1.5,0.5,0), tck=-0.02)
par(mar=c(3, 3, 0.5,0))
line.plots(est[,1], se[,1], Ylabel=1:9, Xlab=expression(beta[0]),
           yaxis=2, hline=fixef(Finn.M3)[1])
box(col=grey(0.3))
par(mar=c(3, 1.5,0.5,1.5))
line.plots(est[,2], se[,2], Ylabel=1:9, Xlab=expression(beta[1]),
           yaxis=4, hline=fixef(Finn.M3)[2])
box(col=grey(0.3))
line.plots(est[,3], se[,3], Ylabel=1:9, Xlab=expression(beta[2]),
           yaxis=2, hline=fixef(Finn.M3)[3])
box(col=grey(0.3))
par(mar=c(3,0, 0.5, 3))
line.plots(est[,4], se[,4], Ylabel=1:9, Xlab=expression(beta[3]),
           yaxis=4)
box(col=grey(0.3))
dev.off()

lake3 <- summer.All[summer.All$type==1,]
postscript(file=paste(plotDIR, "Finncoplottype11.eps", sep="/"),
           width=4.5, height=4, horizontal=F)
par(mar=c(3.5,3.5,3.5,.25), mgp=c(1.5,0.5,0), tck=-0.02)
given.tn <- co.intervals(lake3$lxn, number=4, overlap=.1)
 coplot(y ~ lxp | lxn, data = lake3, given.v=given.tn, rows=1,
        xlab="log TP", ylab="log Chla")
dev.off()

postscript(file=paste(plotDIR, "Finncoplottype12.eps", sep="/"),
           width=4.5, height=4, horizontal=F)
par(mar=c(3.5,3.5,3.5,.25), mgp=c(1.5,0.5,0), tck=-0.02)
given.tp <- co.intervals(lake3$lxp, number=4, overlap=.1)
 coplot(y ~ lxn | lxp, data = lake3, given.v=given.tp, rows=1,
        xlab="log TN", ylab="log Chla")
dev.off()

lake4 <- summer.All[summer.All$type==2&summer.All$lxn>-2,]
postscript(file=paste(plotDIR, "Finncoplottype21.eps", sep="/"),
           width=4.5, height=4, horizontal=F)
par(mar=c(3.5,3.5,3.5,.25), mgp=c(1.5,0.5,0), tck=-0.02)
given.tn <- co.intervals(lake4$lxn, number=4, overlap=.1)
 coplot(y ~ lxp | lxn, data = lake4, given.v=given.tn, rows=1,
        xlab="log TP", ylab="log Chla")
dev.off()

postscript(file=paste(plotDIR, "Finncoplottype22.eps", sep="/"),
           width=4.5, height=4, horizontal=F)
par(mar=c(3.5,3.5,3.5,.25), mgp=c(1.5,0.5,0), tck=-0.02)
given.tp <- co.intervals(lake4$lxp, number=4, overlap=.1)
 coplot(y ~ lxn | lxp, data = lake4, given.v=given.tp, rows=1,
        xlab="log TN", ylab="log Chla")
dev.off()

lake4 <- summer.All[summer.All$type==3,]
postscript(file=paste(plotDIR, "Finncoplottype31.eps", sep="/"),
           width=4.5, height=4, horizontal=F)
par(mar=c(3.5,3.5,3.5,.25), mgp=c(1.5,0.5,0), tck=-0.02)
given.tn <- co.intervals(lake4$lxn, number=4, overlap=.1)
 coplot(y ~ lxp | lxn, data = lake4, given.v=given.tn, rows=1,
        xlab="log TP", ylab="log Chla")
dev.off()

postscript(file=paste(plotDIR, "Finncoplottype32.eps", sep="/"),
           width=4.5, height=4, horizontal=F)
par(mar=c(3.5,3.5,3.5,.25), mgp=c(1.5,0.5,0), tck=-0.02)
given.tp <- co.intervals(lake4$lxp, number=4, overlap=.1)
 coplot(y ~ lxn | lxp, data = lake4, given.v=given.tp, rows=1,
        xlab="log TN", ylab="log Chla")
dev.off()

lake4 <- summer.All[summer.All$type==6,]
postscript(file=paste(plotDIR, "Finncoplottype61.eps", sep="/"),
           width=4.5, height=4, horizontal=F)
par(mar=c(3.5,3.5,3.5,.25), mgp=c(1.5,0.5,0), tck=-0.02)
given.tn <- co.intervals(lake4$lxn, number=4, overlap=.1)
 coplot(y ~ lxp | lxn, data = lake4, given.v=given.tn, rows=1,
        xlab="log TP", ylab="log Chla")
dev.off()

postscript(file=paste(plotDIR, "Finncoplottype62.eps", sep="/"),
           width=4.5, height=4, horizontal=F)
par(mar=c(3.5,3.5,3.5,.25), mgp=c(1.5,0.5,0), tck=-0.02)
given.tp <- co.intervals(lake4$lxp, number=4, overlap=.1)
 coplot(y ~ lxn | lxp, data = lake4, given.v=given.tp, rows=1,
        xlab="log TN", ylab="log Chla")
dev.off()

plot(lxn~lxp, data=lake4)


### collinearity example ####
lake1 <- summer.All[summer.All$lake==19600 & summer.All$type==2,]
lake1$lxn <- scale(log(lake1$totn), scale=F)
lake1$lxp <- scale(log(lake1$totp), scale=F)
lake2 <- summer.All[summer.All$lake==1070,]
lake2$lxn <- scale(log(lake2$totn), scale=F)
lake2$lxp <- scale(log(lake2$totp), scale=F)


## lake 2 pairs

pairs(log(chla)~log(totn)+log(totp), data=lake2)

postscript(file=paste(plotDIR, "FinnCorr.eps", sep="/"),
           width=3, height=3, horizontal=F)
par(mar=c(3.5,3.5,.5,.25), mgp=c(1.5,0.5,0), tck=-0.02)
plot(totn~totp, data=lake2, log="xy", xlab="TP", ylab="TN", pch=16, cex=0.5)
#title(main="Lake 1070", cex=0.75)
dev.off()

### coplots ###
postscript(file=paste(plotDIR, "Finncoplot1.eps", sep="/"),
           width=4.5, height=4, horizontal=F)
par(mar=c(3.5,3.5,3.5,.25), mgp=c(1.5,0.5,0), tck=-0.02)
given.tn <- co.intervals(lake1$lxn, number=4, overlap=.1)
 coplot(y ~ lxp | lxn, data = lake1, given.v=given.tn, rows=1,
        xlab="log TP", ylab="log Chla",
        panel=panel.smooth, col="gray", col.smooth=1)
dev.off()

postscript(file=paste(plotDIR, "Finncoplot2.eps", sep="/"),
           width=4.5, height=4, horizontal=F)
par(mar=c(3.5,3.5,3.5,.25), mgp=c(1.5,0.5,0), tck=-0.02)
given.tp <- co.intervals(lake1$lxp, number=4, overlap=.1)
 coplot(y ~ lxn | lxp, data = lake1, given.v=given.tp, rows=1,
        xlab="log TN", ylab="log Chla",
        panel=panel.smooth, col="gray", col.smooth=1)
dev.off()


postscript(file=paste(plotDIR, "Finncoplot3.eps", sep="/"),
           width=4.5, height=4, horizontal=F)
par(mar=c(3.5,3.5,3.5,.25), mgp=c(1.5,0.5,0), tck=-0.02)
given.tn <- co.intervals(lake2$lxn, number=4, overlap=.1)
 coplot(y ~ lxp | lxn, data = lake2, given.v=given.tn, rows=1,
        xlab="log TP", ylab="log Chla",
        panel=panel.smooth, col="gray", col.smooth=1)
dev.off()

postscript(file=paste(plotDIR, "Finncoplot4.eps", sep="/"),
           width=4.5, height=4, horizontal=F)
par(mar=c(3.5,3.5,3.5,.25), mgp=c(1.5,0.5,0), tck=-0.02)
given.tp <- co.intervals(lake2$lxp, number=4, overlap=.1)
 coplot(y ~ lxn | lxp, data = lake2, given.v=given.tp, rows=1,
        xlab="log TN", ylab="log Chla",
        panel=panel.smooth, col="gray", col.smooth=1)
dev.off()

two.lakes <- rbind(lake1, lake2)
obj1 <- xyplot(y~lxp|factor(lake), data=two.lakes, panel=function(x, y, ...){
    panel.xyplot(x,y, col="gray",...)
    panel.lmline(x, y,...)
    panel.grid()
}, aspect=1, ylab="log Chla", xlab="log TP")
obj2 <- xyplot(y~lxn|factor(lake), data=two.lakes, panel=function(x, y, ...){
    panel.xyplot(x,y, col="gray", cex=0.5, ...)
    panel.lmline(x, y, cex=0.5, ...)
    panel.grid()
}, aspect=1, ylab="log Chla", xlab="log TN")
postscript(file=paste(plotDIR, "finnlake11.eps", sep="/"),
           height=5, width=5, horizontal = F)
print(obj1, position=c(0,0,1,0.55), more=T)
print(obj2, position=c(0,0.45,1,1), more=F)
dev.off()

lake2PN <- data.frame(tptn = c(lake2$lxp, lake2$lxn),
                      chla=rep(lake2$y, 2),
                      nutrients=rep(c("TP","TN"), each=dim(lake2)[1]))

postscript(file=paste(plotDIR, "finnlake1.eps", sep="/"),
           height=2.5, width=4.5, horizontal=F)
xyplot(chla ~ tptn|nutrients, data=lake2PN, panel=function(x,y,...){
    panel.xyplot(x, y, col="gray", ...)
    panel.lmline(x, y, ...)
    panel.grid()
}, aspect=1,  ylab="log Chla", xlab="log nutrient concentration",
       scales=list(x=list(relation="free")))
dev.off()

Finn.lm1 <- lm(y ~ lxp + lxn, data=lake1)
display(Finn.lm1)

Finn.lm2 <- lm(y ~ lxp + lxn, data=lake2)
display(Finn.lm2)

Finn.lm3 <- lm(y ~ lxp * lxn, data=lake1)
display(Finn.lm3)

Finn.lm4 <- lm(y ~ lxp * lxn, data=lake2)
display(Finn.lm4)

coef.lm3 <- coef(Finn.lm4)
quant.n <- quantile(lake2$lxn, prob=c(0.025, 0.25, 0.5,0.75, 0.975))
quant.p <- quantile(lake2$lxp, prob=c(0.025, 0.25, 0.5,0.75, 0.975))

postscript(file=paste(plotDIR, "finnInt.eps", sep="/"),
           height= 2.75, width=4.5, horizontal=F)
par(mfrow=c(1,2), mgp=c(1.5, 0.5,0), mar=c(3,3,1, 0.25), tck=-0.02)
plot(y~lxp, data=lake2, axes=F, xlab="TP", ylab="Chla", cex=0.5)
axis(1, at=log(c(1, 2, 5, 10,20,50,100,200))-attr(lake2$lxp, which="scaled:center"),
     labels=c(1, 2, 5, 10,20,50,100,200))
axis(2, at=log(c(1,2,5,10,20,50,100)),
     labels=c(1,2,5,10,20,50,100))
box()
curve(coef.lm3[1]+coef.lm3[2]*x+coef.lm3[3]*quant.n[1] +
      coef.lm3[4]*x*quant.n[1], add=T, lty=1)
curve(coef.lm3[1]+coef.lm3[2]*x+coef.lm3[3]*quant.n[2] +
      coef.lm3[4]*x*quant.n[2], add=T, lty=2)
curve(coef.lm3[1]+coef.lm3[2]*x+coef.lm3[3]*quant.n[3] +
      coef.lm3[4]*x*quant.n[3], add=T, lty=3)
curve(coef.lm3[1]+coef.lm3[2]*x+coef.lm3[3]*quant.n[4] +
      coef.lm3[4]*x*quant.n[4], add=T, lty=4)
curve(coef.lm3[1]+coef.lm3[2]*x+coef.lm3[3]*quant.n[5] +
      coef.lm3[4]*x*quant.n[5], add=T, lty=5)
legend(x=log(30)-attr(lake2$lxp, which="scaled:center"),
       y=log(5),
       legend=c("2.5%","25%","50%","75%","97.5%"),
       cex=0.5, lty=1:5, bty="n")
plot(y~lxn, data=lake2, axes=F, xlab="TN", ylab="Chla", cex=0.5)
axis(1, at=log(c(200,500,1000,1500))-attr(lake2$lxn, which="scaled:center"),
     labels=c(200,500,1000,1500))
axis(2, at=log(c(1,2,5,10,20,50,100)),
     labels=c(1,2,5,10,20,50,100))
box()
curve(coef.lm3[1]+coef.lm3[3]*x+coef.lm3[2]*quant.p[1] +
      coef.lm3[4]*x*quant.p[1], add=T, lty=1)
curve(coef.lm3[1]+coef.lm3[3]*x+coef.lm3[2]*quant.p[2] +
      coef.lm3[4]*x*quant.p[2], add=T, lty=2)
curve(coef.lm3[1]+coef.lm3[3]*x+coef.lm3[2]*quant.p[3] +
      coef.lm3[4]*x*quant.p[3], add=T, lty=3)
curve(coef.lm3[1]+coef.lm3[3]*x+coef.lm3[2]*quant.p[4] +
      coef.lm3[4]*x*quant.p[4], add=T, lty=4)
curve(coef.lm3[1]+coef.lm3[3]*x+coef.lm3[2]*quant.p[5] +
      coef.lm3[4]*x*quant.p[5], add=T, lty=5)
dev.off()

lake2 $ rt <- log(lake2$totn/lake2$totp)
Finn.lm5 <- lm(y ~ lxp + lxn + rt, data=lake1)
display(Finn.lm5)

postscript(file=paste(plotDIR, "FinnData.eps", sep="/"),
           height=4, width=4, horizontal=F)
par(mgp=c(1.5,.5,0), tck=-0.02)
pairs(y~lxn+lxp+rt, data=lake2, cex=0.25,
      labels=c("log Chla","log TN","log TP","log N:P"))
dev.off()

## positive interaction,

lake3 <- summer.All[summer.All$lake==14700,]
lake3$lxn <- scale(log(lake3$totn), scale=F)
lake3$lxp <- scale(log(lake3$totp), scale=F)
lake4 <- summer.All[summer.All$lake==21800,]
lake4$lxn <- scale(log(lake4$totn), scale=F)
lake4$lxp <- scale(log(lake4$totp), scale=F)

Finn.lm5 <- lm(y ~ lxp * lxn, data=lake3)
display(Finn.lm5)
##### conditional plot
postscript(file=paste(plotDIR, "Finncoplotlake31.eps", sep="/"),
           width=4.5, height=4, horizontal=F)
par(mar=c(3.5,3.5,3.5,.25), mgp=c(1.5,0.5,0), tck=-0.02)
given.tn <- co.intervals(lake3$lxn, number=4, overlap=.1)
 coplot(y ~ lxp | lxn, data = lake3, given.v=given.tn, rows=1,
        xlab="log TP", ylab="log Chla",
        panel=panel.smooth, col="gray", col.smooth=1)
dev.off()

postscript(file=paste(plotDIR, "Finncoplotlake32.eps", sep="/"),
           width=4.5, height=4, horizontal=F)
par(mar=c(3.5,3.5,3.5,.25), mgp=c(1.5,0.5,0), tck=-0.02)
given.tp <- co.intervals(lake3$lxp, number=4, overlap=.1)
 coplot(y ~ lxn | lxp, data = lake3, given.v=given.tp, rows=1,
        xlab="log TN", ylab="log Chla",
        panel=panel.smooth, col="gray", col.smooth=1)
dev.off()
##### interaction plot

coef.lm3 <- coef(Finn.lm5)
quant.n <- quantile(lake3$lxn, prob=c(0.025, 0.25, 0.5,0.75, 0.975))
quant.p <- quantile(lake3$lxp, prob=c(0.025, 0.25, 0.5,0.75, 0.975))

postscript(file=paste(plotDIR, "finnIntlake3.eps", sep="/"),
           height= 2.75, width=4.5, horizontal=F)
par(mfrow=c(1,2), mgp=c(1.5, 0.5,0), mar=c(3,3,1, 0.25), tck=-0.02)
plot(y~lxp, data=lake3, axes=F, xlab="TP", ylab="Chla", cex=0.5)
axis(1, at=log(c(1, 2, 5, 10,20,50,100,200))-attr(lake3$lxp, which="scaled:center"),
     labels=c(1, 2, 5, 10,20,50,100,200))
axis(2, at=log(c(1,2,5,10,20,50,100)),
     labels=c(1,2,5,10,20,50,100))
box()
curve(coef.lm3[1]+coef.lm3[2]*x+coef.lm3[3]*quant.n[1] +
      coef.lm3[4]*x*quant.n[1], add=T, lty=1)
curve(coef.lm3[1]+coef.lm3[2]*x+coef.lm3[3]*quant.n[2] +
      coef.lm3[4]*x*quant.n[2], add=T, lty=2)
curve(coef.lm3[1]+coef.lm3[2]*x+coef.lm3[3]*quant.n[3] +
      coef.lm3[4]*x*quant.n[3], add=T, lty=3)
curve(coef.lm3[1]+coef.lm3[2]*x+coef.lm3[3]*quant.n[4] +
      coef.lm3[4]*x*quant.n[4], add=T, lty=4)
curve(coef.lm3[1]+coef.lm3[2]*x+coef.lm3[3]*quant.n[5] +
      coef.lm3[4]*x*quant.n[5], add=T, lty=5)
legend(x=log(20)-attr(lake3$lxp, which="scaled:center"),
       y=log(4),
       legend=c("2.5%","25%","50%","75%","97.5%"),
       cex=0.5, lty=1:5, bty="n")
plot(y~lxn, data=lake3, axes=F, xlab="TN", ylab="Chla", cex=0.5)
axis(1, at=log(c(200,500,1000,1500))-attr(lake3$lxn, which="scaled:center"),
     labels=c(200,500,1000,1500))
axis(2, at=log(c(1,2,5,10,20,50,100)),
     labels=c(1,2,5,10,20,50,100))
box()
curve(coef.lm3[1]+coef.lm3[3]*x+coef.lm3[2]*quant.p[1] +
      coef.lm3[4]*x*quant.p[1], add=T, lty=1)
curve(coef.lm3[1]+coef.lm3[3]*x+coef.lm3[2]*quant.p[2] +
      coef.lm3[4]*x*quant.p[2], add=T, lty=2)
curve(coef.lm3[1]+coef.lm3[3]*x+coef.lm3[2]*quant.p[3] +
      coef.lm3[4]*x*quant.p[3], add=T, lty=3)
curve(coef.lm3[1]+coef.lm3[3]*x+coef.lm3[2]*quant.p[4] +
      coef.lm3[4]*x*quant.p[4], add=T, lty=4)
curve(coef.lm3[1]+coef.lm3[3]*x+coef.lm3[2]*quant.p[5] +
      coef.lm3[4]*x*quant.p[5], add=T, lty=5)
dev.off()



## negative interaction
Finn.lm6 <- lm(y ~ lxp * lxn, data=lake4)
display(Finn.lm6)

##### conditional plot

postscript(file=paste(plotDIR, "Finncoplotlake41.eps", sep="/"),
           width=4.5, height=4, horizontal=F)
par(mar=c(3.5,3.5,3.5,.25), mgp=c(1.5,0.5,0), tck=-0.02)
given.tn <- co.intervals(lake4$lxn, number=4, overlap=.1)
 coplot(y ~ lxp | lxn, data = lake4, given.v=given.tn, rows=1,
        xlab="log TP", ylab="log Chla",
        panel=panel.smooth, col="gray", col.smooth=1)
dev.off()

postscript(file=paste(plotDIR, "Finncoplotlake42.eps", sep="/"),
           width=4.5, height=4, horizontal=F)
par(mar=c(3.5,3.5,3.5,.25), mgp=c(1.5,0.5,0), tck=-0.02)
given.tp <- co.intervals(lake4$lxp, number=4, overlap=.1)
 coplot(y ~ lxn | lxp, data = lake4, given.v=given.tn, rows=1,
        xlab="log TN", ylab="log Chla",
        panel=panel.smooth, col="gray", col.smooth=1)
dev.off()
##### interaction plot
coef.lm3 <- coef(Finn.lm6)
quant.n <- quantile(lake4$lxn, prob=c(0.025, 0.25, 0.5,0.75, 0.975))
quant.p <- quantile(lake4$lxp, prob=c(0.025, 0.25, 0.5,0.75, 0.975))

postscript(file=paste(plotDIR, "finnIntlake4.eps", sep="/"),
           height= 2.75, width=4.5, horizontal=F)
par(mfrow=c(1,2), mgp=c(1.5, 0.5,0), mar=c(3,3,1, 0.25), tck=-0.02)
plot(y~lxp, data=lake4, axes=F, xlab="TP", ylab="Chla", cex=0.5)
axis(1, at=log(c(1, 2, 5, 10,20,50,100,200))-attr(lake4$lxp, which="scaled:center"),
     labels=c(1, 2, 5, 10,20,50,100,200))
axis(2, at=log(c(1,2,5,10,20,50,100)),
     labels=c(1,2,5,10,20,50,100))
box()
curve(coef.lm3[1]+coef.lm3[2]*x+coef.lm3[3]*quant.n[1] +
      coef.lm3[4]*x*quant.n[1], add=T, lty=1)
curve(coef.lm3[1]+coef.lm3[2]*x+coef.lm3[3]*quant.n[2] +
      coef.lm3[4]*x*quant.n[2], add=T, lty=2)
curve(coef.lm3[1]+coef.lm3[2]*x+coef.lm3[3]*quant.n[3] +
      coef.lm3[4]*x*quant.n[3], add=T, lty=3)
curve(coef.lm3[1]+coef.lm3[2]*x+coef.lm3[3]*quant.n[4] +
      coef.lm3[4]*x*quant.n[4], add=T, lty=4)
curve(coef.lm3[1]+coef.lm3[2]*x+coef.lm3[3]*quant.n[5] +
      coef.lm3[4]*x*quant.n[5], add=T, lty=5)
legend(x=log(100)-attr(lake4$lxp, which="scaled:center"),
       y=log(10),
       legend=c("2.5%","25%","50%","75%","97.5%"),
       cex=0.5, lty=1:5, bty="n")
plot(y~lxn, data=lake4, axes=F, xlab="TN", ylab="Chla", cex=0.5)
axis(1, at=log(c(200,500,1000,1500))-attr(lake4$lxn, which="scaled:center"),
     labels=c(200,500,1000,1500))
axis(2, at=log(c(1,2,5,10,20,50,100)),
     labels=c(1,2,5,10,20,50,100))
box()
curve(coef.lm3[1]+coef.lm3[3]*x+coef.lm3[2]*quant.p[1] +
      coef.lm3[4]*x*quant.p[1], add=T, lty=1)
curve(coef.lm3[1]+coef.lm3[3]*x+coef.lm3[2]*quant.p[2] +
      coef.lm3[4]*x*quant.p[2], add=T, lty=2)
curve(coef.lm3[1]+coef.lm3[3]*x+coef.lm3[2]*quant.p[3] +
      coef.lm3[4]*x*quant.p[3], add=T, lty=3)
curve(coef.lm3[1]+coef.lm3[3]*x+coef.lm3[2]*quant.p[4] +
      coef.lm3[4]*x*quant.p[4], add=T, lty=4)
curve(coef.lm3[1]+coef.lm3[3]*x+coef.lm3[2]*quant.p[5] +
      coef.lm3[4]*x*quant.p[5], add=T, lty=5)
dev.off()



### Liverpool moth
moths <- read.table(paste(dataDIR, "moths.txt", sep="/"), header=T)
moths$location <- ordered(rep(c("Sefton Park","Eastham Ferry","Hawarden","Loggerheads","Llanbedr","Pwyllglas","Clergy Mawr"), each=2), levels=c("Sefton Park","Eastham Ferry","Hawarden","Loggerheads","Llanbedr","Pwyllglas","Clergy Mawr"))
moths$color <- as.numeric(moths$morph)-1
moth.glm1 <- glm(cbind(removed, placed-removed)~color*distance, data=moths, family=binomial(link="logit"))
moth.glm2 <- glm(cbind(removed, placed-removed)~factor(morph)*distance, data=moths, family=binomial(link="logit"))
moth.glm3 <- glm(cbind(removed, placed-removed)~factor(morph)*factor(distance), data=moths, family=binomial(link="logit"))
summary(moth.glm1)
summary(moth.glm2)

moth.lmer1 <- glmer(cbind(removed, placed-removed) ~ color+(1+color|location),
                   data=moths, family=binomial)

moth1.est <- data.frame(est1=fixef(moth.lmer1)[1]+ranef(moth.lmer1)[[1]][,1],
                        est2=sum(fixef(moth.lmer1))+ranef(moth.lmer1)[[1]][,1]+ranef(moth.lmer1)[[1]][,2])
moth1.se  <- data.frame(se1=se.ranef(moth.lmer1)[[1]][,1],
                        se2=sqrt(ranef(moth.lmer1)[[1]][,1]^2+ranef(moth.lmer1)[[1]][,2]^2))
line.plots.compare (moth1.est[,1], moth1.se[,1], moth1.est[,2], moth1.se[,2], Ylabel=levels(moths$location),
                    Xlab="logit prob", yaxis=2)
line.plots.compare (summary(moth.glm1)$coef[1:7, 1], summary(moth.glm1)$coef[1:7,2],
                    summary(moth.glm1)$coef[1:7, 1]+ summary(moth.glm1)$coef[8:14,1],
                    sqrt(summary(moth.glm1)$coef[1:7,2]^2+summary(moth.glm1)$coef[8:14,2]^2),
                    Ylabel=levels(moths$location), Xlab="Logit Prob")
postscript(file=paste(plotDIR, "mothlogodds1.eps", sep="/"),
           height=3, width=4.5, horizontal=F)
par(mfrow=c(1,2), mar=c(3, 7, 0.5,0.25), mgp=c(1.5, 0.5,0.), tck=-0.02)
line.plots(coef(moth.lmer1)$location[,1], se.coef(moth.lmer1)$location[,1],
           Ylabel=levels(moths$location), Xlab=expression(beta[0]), yaxis=2)

par(mar=c(3,0.25,0.5, 7))
line.plots(coef(moth.lmer1)$location[,2], se.coef(moth.lmer1)$location[,2],
           Ylabel=levels(moths$location), Xlab=expression(beta[1]), yaxis=4)
dev.off()

moth.lmer2 <- glmer(cbind(removed, placed-removed) ~ color*distance+(1+color|location),
                   data=moths, family=binomial)
Dist <- unique(moths$distance)
M2.coef <- coef (moth.lmer2)
a.hat.M2 <- M2.coef[[1]][,1] + M2.coef[[1]][,3]*Dist
b.hat.M2 <- M2.coef[[1]][,2] + M2.coef[[1]][,4]*Dist
a.se.M2 <- se.ranef(moth.lmer2)[[1]][,1]
b.se.M2 <- se.ranef(moth.lmer2)[[1]][,2]

# plot estimated intercepts and slopes

postscript(file=paste(plotDIR, "mothDist.eps", sep="/"), width=4.75, height=3, horizontal=F)
par (mfrow=c(1,2), mar=c(3,3,3,0.25), mgp=c(1.5,0.5,0))
lower <- a.hat.M2 - a.se.M2
upper <- a.hat.M2 + a.se.M2
plot (Dist, a.hat.M2, ylim=range(lower,upper), cex.lab=0.75, cex.axis=0.75,
      xlab="Distance from Liverpool", ylab=expression(beta[0]), pch=20)
curve (fixef(moth.lmer2)[1] + fixef(moth.lmer2)[3]*x, lwd=1, col="black", add=TRUE)
segments (Dist, lower, Dist, upper, lwd=.5, col="gray10")
text(Dist, lower, levels(moths$location), adj=c(.5,1),cex=0.5)

lower <- b.hat.M2 - b.se.M2
upper <- b.hat.M2 + b.se.M2

plot (Dist, b.hat.M2, ylim=range(lower,upper), cex.lab=0.75, cex.axis=0.75,
      xlab="Distance from Liverpool", ylab=expression(beta[1]), pch=20)
curve (fixef(moth.lmer2)[2] + fixef(moth.lmer2)[4]*x, lwd=1, col="black", add=TRUE)
segments (Dist, lower, Dist, upper, lwd=.5, col="gray10")
text(Dist, lower, levels(moths$location), adj=c(.5,1),cex=0.5)

dev.off()

moth.lmer3 <- glmer(cbind(removed, placed-removed) ~ distance+(1+distance|morph),
                   data=moths, family=binomial)

postscript(file=paste(plotDIR, "moth3.eps", sep="/"),
           width=4.5, height=1.5, horizontal=F)
par(mfrow=c(1,2), mar=c(3, 3.5, 0.5,0.5), mgp=c(1.5, 0.5,0.), tck=-0.02)
line.plots(coef(moth.lmer3)$morph[,1], se.coef(moth.lmer3)$morph[,1],
           Ylabel=levels(moths$morph), Xlab=expression(beta[0]), yaxis=2)
box()

par(mar=c(3,0.5,0.5, 3.5))
line.plots(coef(moth.lmer3)$morph[,2], se.coef(moth.lmer3)$morph[,2],
           Ylabel=levels(moths$morph), Xlab=expression(beta[1]), yaxis=4)
box()
dev.off()



#############################################
#### seedling recruitment data from Shen ####
#############################################
transect <- read.csv(paste(dataDIR, "transect2.csv", sep="/"), header=T)
transect.desc <- read.csv(paste(dataDIR, "transectX.csv", sep="/"), header=T)
species.code3 <- read.csv(paste(dataDIR, "species3.csv", sep="/"), header=T)

data.for.glm <- transect[order(transect$Plot),]
temp <- transect.desc[unique(data.for.glm$Plot),]
data.for.glm$Position <- rep(temp$Position, table(data.for.glm$Plot))
data.for.glm$Gap <- rep(temp$Gap, table(data.for.glm$Plot))
data.for.glm$Total.C <- rep(temp$Total.C, table(data.for.glm$Plot))
data.for.glm$ABH <- rep(temp$ABH, table(data.for.glm$Plot))
data.for.glm$Gap <- ifelse(data.for.glm$Gap>1, 1, data.for.glm$Gap)
data.for.glm$gap.center <- data.for.glm$Gap-0.5


transect.glm7 <- glm(Numb ~ factor(type)*Total.C,
                    family=quasipoisson, data=data.for.glm)


icr <- read.table(paste(dataDIR,"CryptoData2.txt",sep="/"), header=T,
        na.string = ".", sep = "\t")

## example of Poisson multilevel model

levels(icr$MSrcCat) -> Lmsrc
levels(icr$M.WTP.Type)->Lwtptype

dcts.data <- icr[icr$MSrcCat==Lmsrc[3] | icr$MSrcCat==Lmsrc[4],]
dcts.data <- dcts.data[dcts.data$M.WTP.Type=="Y"|dcts.data$M.WTP.Type=="N",]
dcts.data$M.WTP.Type <- ordered(as.vector( dcts.data$M.WTP.Type ))
dcts.data$MSrcCat <- ordered(as.vector( dcts.data$MSrcCat ))
dcts.data$ICR.PWSID <- ordered(dcts.data$ICR.PWSID)

icr.glm <- glm(n.cT ~ factor(ICR.PWSID)-1, data=dcts.data,
               family="poisson", offset=log(volume*0.44))

icr.lmer1 <- glmer(n.cT ~ 1+(1|ICR.PWSID),
                   data=dcts.data, family="poisson",
                   offset=log(volume*0.44))

icr.size <- as.vector(table(dcts.data$ICR.PWSID))
size <- icr.size + runif(length(icr.size), -0.1,0.1)

icr.glmCoef <- summary(icr.glm)$coef

postscript(file=paste(plotDIR, "cryptolmer1.eps", sep="/"),
           width=3.5, height=2.5, horizontal=F)
lmer.mean <- fixef(icr.lmer1)[1] + ranef(icr.lmer1)[[1]][,1]
lmer.se <- sqrt(se.fixef(icr.lmer1)[1]^2 + se.ranef(icr.lmer1)[[1]][,1]^2)
lower <- lmer.mean-lmer.se
upper <- lmer.mean+lmer.se

par(mar=c(3,3,0.5,0.5), mgp=c(1.5,0.5,0), tck=-0.02)
plot(size, rnorm(length(size)),type="n", xlab="Sample size",
  ylab="Log Mean", log="x", ylim=range(lower,upper))
abline(h=fixef(icr.lmer1)[[1]][1])
segments(x0=size, x1=size, y0=lower, y1=upper)
points(size, lmer.mean, pch=16,cex=0.5)
dev.off()

icr.lmer2 <- glmer(n.cT ~ 1+(1|ICR.PWSID),
                   data=dcts.data, family="quasipoisson",
                   offset=log(volume*0.44))

cs <- coef(icr.lmer1)[[1]][,1]
n.cs <- length(cs)

postscript(file=paste(plotDIR, "cryptocdf.eps", sep="/"),
           width=3.5, height=2.5, horizontal=F)
par(mar=c(3,3,0.5,0.5), mgp=c(1.5,0.5,0), tck=-0.02)
plot(sort(cs), ((1:n.cs)-0.5)/n.cs, axes=F,
     xlab="Crypto Concentration (oocyst/L)", ylab="CDF",
     type="n")
points(sort(cs), ((1:n.cs)-0.5)/n.cs, pch=1,cex=0.5, col="gray")
curve(pnorm(x, -5.384, 2.08), add=T)
axis(1, at=log(c(0.0001,0.001,0.01,0.1,1,10,100)),
     labels=c("0.0001","0.001","0.01","0.1","1","10","100"))
axis(2)
box()
dev.off()

## simulation fraction of 0s (at system level)
n.sys <- 884
n.sims <- 10000
zeros <- sys.mean <- sys.25<-sys.75<-sys.95 <-
    sys.99 <- numeric()
sys.means <- matrix(0, n.sims, n.sys)
for (i in 1:n.sims){
    zeros[i] <- 0
    for (j in 1:n.sys){
        mu <- rnorm(1, -5.384, 0.103)
        sigma <- 2.08*sqrt((13103-884)/rchisq(1, 13103-884))
        y <- rpois(icr.size[j],
                   0.44*10*exp(rnorm(icr.size[j], mu, sigma)))
        sys.means[i,j] <- mean(y)/10
        zeros[i] <- zeros[i] + (sum(y!=0)==0)/n.sys
    }
}
dcts.sys.mean <- tapply(dcts.data$n.cT/dcts.data$volume,
                        dcts.data$ICR.PWSID,
                        mean)

postscript(file=paste(plotDIR, "cryptoSim.eps", sep="/"),
           height=2.5, width=4.5, horizontal=F)
par(mfrow=c(1,2), mar=c(3,3,0.5,0.5), mgp=c(1.5,0.5,0), tck=-0.02)
hist(zeros*100, xlab="% of all zero systems", main="",
     xlim=c(40,70), cex=0.75)
abline(v=mean(dcts.sys.mean==0)*100, col="gray", lwd=2)
## simulation of the 99th percentile of the system mean

hist(as.vector(apply(sys.means, 1, quantile, prob=0.99)),
     main="", xlab="99th percentile", cex=0.75)
abline(v=quantile(dcts.sys.mean, 0.99), col="gray", lwd=2)
dev.off()




crydat.simple2 <- function(
                    path="n.cT", rab=c(1.44,11.20),
                    ifname = dcts.data,
                    alpha=c(2.0, 2.0),
                    tau  =c(0.2, 0.2)) { ## zero-inflated
  icr <- ifname
  vol  <- icr$volume/100;          # Litres -> Hectolitres stabilizing numeric process in BUGS
  loc  <- as.numeric(ordered(paste(icr$ICR.PWSID, icr$M.WTP.Type)));
  oo <- order(loc)
  ni <- max(loc)
  nc   <- icr$n.cT
  nrec <- length(vol);
  unfiltereds <- unique(loc[icr$M.WTP.Type=="N"])
  filtereds <- unique(loc[icr$M.WTP.Type=="Y"])
  fuf <- rep(1, ni)
  fuf[filtereds] <- 2  ## 1-unfiltereds, 2-filtereds
  Xnc  <- nc;
  Xvol <- vol;

  Inc  <- ini(Xnc,  1);
  Ivol <- ini(Xvol, round(mean(Xvol,na.rm=T),4));
  Irec <- rep(rab[1]/sum(rab), dim(icr)[1]);

  N <- dim(icr)[1]

  bugs.dat <- list(N=N, n.sys=ni, NC=(Xnc),  VOL=(Xvol), TAU=tau, system = loc,
                      ALPHA=alpha, RAB=rab);
  ini1 <- list(NC=ini(Xnc,  rpois(1, 1)), VOL=ini(Xvol, rnorm(1, mean(Xvol,na.rm=T), 0.01)),
               lcbar = rnorm(ni, 0, 0.25), lconc = rnorm(N, 0, 0.25),u=rep(1, N),
               prec = alpha/tau, recov=rbeta(N, rab[1],rab[2]), em=rnorm(1));
  ini2 <- list(NC=ini(Xnc,  rpois(1, 1)), VOL=ini(Xvol, rnorm(1, mean(Xvol,na.rm=T), 0.01)),
               lcbar = rnorm(ni, 0, 0.25), lconc = rnorm(N, 0, 0.25),u=rep(1, N),
               prec = alpha/tau, recov=rbeta(N, rab[1],rab[2]), em=rnorm(1));
  ini3 <- list(NC=ini(Xnc,  rpois(1, 1)), VOL=ini(Xvol, rnorm(1, mean(Xvol,na.rm=T), 0.01)),
               lcbar = rnorm(ni, 0, 0.25), lconc = rnorm(N, 0, 0.25),u=rep(1, N),
               prec = alpha/tau, recov=rbeta(N, rab[1],rab[2]), em=rnorm(1));
  bugs.ini <- list(ini1, ini2, ini3)
  bugs.para <- c("cbar", "mu", "sigma")
  bugs.msw <- list(base=base, recov.ab=rab, dat=ifname);
  return(list(data=bugs.dat, inits=bugs.ini, para=bugs.para, other=list(uf=unfiltereds, f=filtereds),
         path=path, msw=bugs.msw));
}
input.to.bugs <- crydat.simple2 (path = "n.cT", rab = c(1.771, 2.408572266),
    alpha = c(2, 2), tau = c(0.2, 0.2))
## running bugs
bugs.out <- bugs(input.to.bugs$data, input.to.bugs$inits, input.to.bugs$para,
                 model.file=paste(base, "cryptoSimple4.txt", sep="/"),
                 n.chains=3, n.iter=100000, DIC=F, program="openbugs")


####

## US lilac data
USLilac <- read.csv(paste(dataDIR, "NAmlilac.csv", sep="/"))
#> USLilac[1:10,]
#    STID Year Ptype FirstLeaf FirstBloom
#1  20309 1957     2       999         67
#2  20309 1958     2       999         90

USLilac$type <- "Syringa chinensis clone"
USLilac$type[USLilac$Ptype==2] <-"Syringa vulgaris"


USLilac$FirstLeaf[USLilac$FirstLeaf==999] <- NA
USLilac$FirstBloom[USLilac$FirstBloom==999] <- NA

postscript(file=paste(plotDIR,"uslilacsData.eps", sep="/"),
           width=4.5, height=3, horizontal=F)
xyplot(FirstBloom~Year, data=USLilac, panel=function(x,y,...){
    panel.xyplot(x,y, col="gray",...)
    panel.loess(x,y,span=0.5,lwd=3,...)},
    xlab="Year", ylab="First Bloom")
dev.off()

postscript(file="USlilac2.eps", width=5.5, height=3, horizontal=F)
xyplot(FirstBloom~Year|type, data=USLilac, panel=function(x,y,...){
    panel.xyplot(x,y,...)
    panel.loess(x,y,col="red",span=0.5,lwd=3,...)},
    xlab="Year", ylab="First Bloom")
dev.off()

postscript(file="USlilac3.eps", width=4, height=3, horizontal=F)
par(mar=c(3,3,1,1), mgp=c(1.5,.5,0))
plot(1956:2003, table(USLilac$Year), xlab="Year", ylab="Sample Size", type="h", lwd=3)
dev.off()

postscript(file="JPlilacN.eps", width=4, height=3, horizontal=F)
par(mar=c(3,3,1,1), mgp=c(1.5,.5,0))
plot(1996:2006, table(Lilac$Year), xlab="Year", ylab="Sample Size", type="h", lwd=3)
dev.off()

keep <- !is.na(match(USLilac$STID, as.numeric(names(table(USLilac$STID))[table(USLilac$STID)>=30])))
## keep stations with at least 30 years of data
uslilacs <- USLilac[keep,]
stlist <- sort(unique(uslilacs$STID))
for (i in 1:length(stlist)){
    stid <- stlist[i]
    obj <- xyplot(FirstBloom~Year, data=USLilac, panel=function(x,y,...){
        panel.xyplot(x,y,col="gray",...)
        panel.loess(x,y,span=0.75,lwd=2,...)},
        xlab="Year", ylab="First Bloom", subset=STID==stid,
        sub=paste("Station", stid))
   # postscript(file=paste("st",stid,".eps", sep=""), width=4.5, height=3, horizontal=F)
    print(obj)
   # dev.off()
}

stlist2 <- c(354147, 456974, 456624, 426357)
obj2<-list()
for (i in 1:4){
    stid <- stlist2[i]
    obj2[[i]] <- xyplot(FirstBloom~Year, data=USLilac, panel=function(x,y,...){
        panel.xyplot(x,y,col="gray",...)
        panel.loess(x,y,span=0.75,lwd=2,...)},
        xlab=paste("Station", stid), ylab="", subset=STID==stid)
#   postscript(file=paste("st",stid,".eps", sep=""), width=4.5, height=3, horizontal=F)
#   print(obj)
#   dev.off()
}
postscript(paste(plotDIR, "uslilacs1.eps", sep="/"),
           height=5, width=5.5, horizontal=F)
print(obj2[[1]], position=c(0, 0, 0.55, 0.55), more=T)
print(obj2[[2]], position=c(0.45, 0, 1, 0.55), more=T)
print(obj2[[3]], position=c(0, 0.45, 0.55, 1), more=T)
print(obj2[[4]], position=c(0.45, 0.45, 1, 1), more=F)
dev.off()

temp <- USLilac[USLilac$STID==stlist2[1],]
lilacs.lm1 <- nls( FirstBloom ~ hockey(Year, beta0, beta1, delta, theta),
        start=list(beta0=100, beta1=  0,
                delta=-0.1, theta=1980),
        data=temp, na.action=na.omit)
temp <- USLilac[USLilac$STID==stlist2[2],]
lilacs.lm2 <- nls( FirstBloom ~ hockey(Year, beta0, beta1, delta, theta),
        start=list(beta0=150, beta1=  0,
                delta=-0.1, theta=1980),
        data=temp, na.action=na.omit, control=list(maxiter=100))
temp <- USLilac[USLilac$STID==stlist2[3],]
lilacs.lm3 <- nls( FirstBloom ~ hockey(Year, beta0, beta1, delta, theta),
        start=list(beta0=120, beta1=0.1,
                delta=-1, theta=1980),
        data=temp, na.action=na.omit, control=list(maxiter=100))
temp <- USLilac[USLilac$STID==stlist2[4],]
lilacs.lm4 <- nls( FirstBloom ~ hockey(Year, beta0, beta1, delta, theta),
        start=list(beta0=120, beta1=  0,
                delta=-0.5, theta=1980),
        data=temp, na.action=na.omit, control=list(maxiter=100))

uslilacs.ST <- read.csv(paste(dataDIR, "NAmlilacSTID.csv", sep="/"),
                        header=T)
!is.na(match(uslilacs.ST$ID, stlist2))

#354147	IMNAHA	        	OR	45.34	-116.5	564.02
#456974	REPUBLIC		WA	48.39	-118.44	792.68
#456624	PORT ANGELES		WA	48.07	-123.26	60.98
#426357	OAK CITY		UT	39.23	-112.2	1547.26


median.polish.ts <- function(data.ts, ylab=""){
# median polishing for missing value imputation
medpolish(matrix(data.ts, ncol=12, byrow=T), eps=0.001, na.rm=T)->temp.2w
print(names(temp.2w))
year.temp <- rep(seq(start(data.ts)[1], end(data.ts)[1]), each=12)
month.temp <- rep(1:12, length(seq(start(data.ts)[1], end(data.ts)[1])))
# plotting median polishing results
par(mfrow=c(2,1))
plot(seq(start(data.ts)[1], end(data.ts)[1]),
     temp.2w$overall+temp.2w$row, type="l",
     xlab="Year", ylab=ylab, main="De-seasonalized Trend")
plot(seq(1,12), temp.2w$overall+temp.2w$col, type="l",
        xlab="Month", ylab=ylab, main="Seasonal Changes")
data.ts[is.na(data.ts)]<-temp.2w$overall +
                         temp.2w$row[year.temp[is.na(data.ts)]-start(data.ts)[1]+1]+
                         temp.2w$col[month.temp[is.na(data.ts)]]
invisible(data.ts)
}
#### end of median polishing for missing value imputation


co2 <- read.table(paste(dataDIR, "co2.txt", sep="/"),
                  header=T)

## the CO2 data sets needs additional manipulation
##
## the original data file has two extra columns that are not necessary
co2 <- co2[,2:13]  ## keeping only the monthly CO2 data
co2[co2<0] <- NA   ## replacing missing values (coded as -99) with NA

co2 <- ts(as.vector(t(as.matrix(co2))), start=c(1959, 1), end=c(2003,12), freq=12)
## converting the data into a time series
co2<-median.polish.ts(co2)
## imputing missing values.
## running median polish generates two figures -- long term trend and seasonal pattern

## with a time series object, you can plot it using plot:
#postscript("co2ts.eps", height=3.5, width=5, horizontal=F)
postscript(file=paste(plotDIR, "co2HAts.eps", sep="/"),
           height=3.5, width=4.5, horizontal=F)
par(mar=c(3,3,0.25,0.25), mgp=c(1.5,.5,0))  ## set up graphical parameters
                                            ## (margins and locations of ticks and labels)
plot(co2, ylab=expression(CO[2] (ppm)), xlab="Year")
dev.off()

library(rpart)
names(iris.df) <- c("Sepal.L", "Sepal.W", "Petal.L", "Petal.W", "Species")
iris.rpart <- rpart(Species ~ Sepal.L+Sepal.W+Petal.L+Petal.W,
                    data=iris.df, method="class")
postscript(file=paste(plotDIR, "irisCART.eps", sep="/"), height=3, width=3.4,
           horizontal=F)
par(mgp=c(1.5,0.5,0), mar=c(1,1,1,1))
plot(iris.rpart, margin=0.1)
text(iris.rpart)
dev.off()

require(lattice)
postscript(file=paste(plotDIR, "iris2D.eps", sep="/"),
           height=3, width=3, horizontal=F)
trellis.par.set(bw.whitebg())
xyplot(Petal.W~Petal.L,iris.df,groups=Species,
    pch=1:3,col=1,
    panel=function(x,y,groups,...){
     panel.superpose(x,y,groups,...)
     panel.abline(v=2.45,lty=2)
     panel.segments(2.45,1.75,max(x)*2,1.75,lty=2)
#     panel.segments(4.95,min(y)*-2,4.95,1.75,lty=2)
#     panel.segments(2.45,1.65,4.95,1.65,lty=2)
#     panel.segments(4.95,1.55,max(x)*2,1.55,lty=2)
   },xlab="Petal Length",ylab="Petal Width",
  key=list(points=T, columns=3,pch=1:3,col=1,cex=0.5,
    text=list(c("Setosa","Versicolor","Virginica"))))
dev.off()
