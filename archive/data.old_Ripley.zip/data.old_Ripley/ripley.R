data=read.table(file.choose(),header=T)
helX=ppp(data$x,data$y,c(0,3125),c(0,2713))
fix(data)
plot(data)
plot(X)

 data=read.table(".\\data\\A-15_.txt",header=T)
 data
 plot(data$x,data$y)
 X=ppp(data$x,data$y,c(0,300),c(0,300))
 plot(envelope(X))
 K=envelope(X)
 plot(K,sqrt(./pi)-r~r)

## initial
# Enlarge the memory
# memory.limit(2000)
# creat polygon to be used as a window in ppp
library(mgcv)
library(deldir)
library(spatstat)
library(spatial)
# initial data
data=read.table("A+10.txt",header=T)
 data
 plot(data$x,data$y)
 X=ppp(data$x,data$y,c(0,100),c(0,100))
# K function
plot(Lest(X,nlarge=Inf))
Lr<-envelope(X,fun=Lest,r=seq(0,20,0.1),correction=c("none"),nsim=111)
//correction=c("Ripley"),,rank=1,transform=expression(sqrt(./pi))
plot(Lr)

Kr<-envelope(X,fun=Kest,r=seq(0,149,1),nsim=100,correction=c("none"),nlarge=Inf)
plot(Kr)
plot(Kr,sqrt(./pi)-r~r,add=T)

K=Kest(X,correction=c("none"),nlarge=4003)
plot(K,sqrt(./pi)-r)
plot(K)

 K2=envelope(X,nlarge=Inf)
plot(K2)
 plot(envelope(X))

 plot(K2,sqrt(./pi)-r~r)
 plot(K,sqrt(./pi)-r~r)

// Kest Examples
 pp <- runifpoint(50)
 K <- Kest(pp)
 data(cells)
 K <- Kest(cells, correction="isotropic")
 plot(K)
 plot(K, main="K function for cells")
 # plot the L function
 plot(K, sqrt(iso/pi) ~ r)
 plot(K, sqrt(./pi) ~ r, ylab="L(r)", main="L function for cells")


//
 K3=envelope(X,fun=pcf)
 plot(K3)

//
//http://tolstoy.newcastle.edu.au/R/help/06/02/22148.html
library(spatial) 
set.seed(24) 
X <- list(x = runif(100), y = runif(100),

           area = c(xl = 0, xu = 1, yl = 0, xu = 1))

ppregion(X)
plot(Kfn(X, 0.5), type = "b", xlab = "distance", ylab = "L(t)")
set.seed(42)

lims <- Kenvl(0.5, 100, Psim(69)) 
lines(lims$x, lims$l, lty = 2, col = "darkred") 
lines(lims$x, lims$u, lty = 2, col = "darkred")


library(spatstat) 
Y <- ppp(X$x, X$y, X$area[1:2], X$area[3:4]) 
set.seed(42) 
Yenv <- envelope(Y, nsim = 100)
plot(Yenv,sqrt(./pi)-r~r)

//
//envelope(X, correction="translate") runs about 5 times faster than envelope(X)

//
ERip<-envelope(X,fun=Kest,r=seq(0,0.5,0.01),correction=c("Ripley"),nsim=99,rank=1,transform=expression(sqrt(./pi)),global=TRUE) 